<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-05 00:01:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:07:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:08:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:10:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:10:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:17:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:17:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:18:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:18:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 00:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:19:47 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-05 00:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:27:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 00:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:34:41 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-05 00:34:42 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-05 00:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:37:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:40:19 --> 404 Page Not Found: Clientaccesspolicyxml/index
ERROR - 2021-06-05 00:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:47:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 00:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:48:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 00:49:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 00:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:53:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:58:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:58:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 00:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 00:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:00:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:00:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:01:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 01:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:07:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:14:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:14:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 01:15:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:15:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:16:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:16:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 01:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:18:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:19:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:19:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:24:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:24:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:26:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 01:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:32:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 01:34:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 01:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:47:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:47:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:47:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:47:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:47:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:47:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:56:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 01:56:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:57:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 01:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 01:59:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:59:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 01:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:00:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:02:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 02:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:03:00 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-05 02:03:01 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-05 02:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:10:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:12:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:12:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:13:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:14:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:14:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:14:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:14:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:14:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:22:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:28:05 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-05 02:28:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:29:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 02:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:32:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:32:39 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-05 02:34:41 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-05 02:34:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:38:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 02:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:38:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:39:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:40:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:44:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:44:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:45:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 02:45:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:46:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:46:35 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-05 02:46:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 02:48:05 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-05 02:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:48:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:49:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:49:40 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-05 02:49:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:50:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:51:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:51:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 02:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:53:31 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-05 02:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 02:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:00:04 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-05 03:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:01:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:01:36 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-05 03:01:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:02:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:02:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:02:14 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-05 03:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:03:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:05:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:06:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:07:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:07:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:08:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:08:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:09:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:09:52 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-05 03:10:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:11:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:11:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:11:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:11:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:12:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:13:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 03:13:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:13:43 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-05 03:13:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:14:41 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-05 03:14:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:15:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:15:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:16:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:16:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:16:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:17:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:17:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:17:36 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-05 03:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:17:46 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-05 03:17:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:18:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:18:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:19:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:20:35 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-05 03:21:35 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-05 03:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:22:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:23:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:23:40 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-05 03:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:24:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:25:11 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-05 03:25:23 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-05 03:25:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:25:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:26:41 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-05 03:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:27:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:28:13 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-05 03:28:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:29:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:29:45 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-05 03:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:30:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:31:16 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-05 03:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:32:43 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-05 03:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:33:10 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-05 03:34:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:37:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:37:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:38:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:40:08 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 03:41:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:41:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:43:02 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-05 03:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:45:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:46:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:46:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:46:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:47:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:47:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:47:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:48:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:48:32 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-05 03:48:45 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-05 03:49:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:49:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:49:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:49:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:50:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:50:30 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-05 03:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:53:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:53:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:55:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:56:31 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-05 03:56:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:57:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 03:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:58:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 03:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 03:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:00:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 04:00:27 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-05 04:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:01:02 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-05 04:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:03:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 04:04:02 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-05 04:04:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 04:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:11:07 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-05 04:12:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 04:12:46 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-05 04:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:17:30 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-05 04:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:19:33 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-05 04:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:20:43 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-05 04:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:24:30 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-05 04:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:25:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 04:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:29:49 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-05 04:29:51 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 04:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:43:16 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-05 04:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:45:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 04:46:02 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-05 04:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:50:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 04:50:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-05 04:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:53:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 04:54:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 04:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:55:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 04:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:55:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 04:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:56:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 04:57:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 04:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 04:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:00:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 05:00:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 05:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:01:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:01:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-05 05:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:03:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:07:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-05 05:07:39 --> 404 Page Not Found: English/index
ERROR - 2021-06-05 05:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:09:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:20:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:22:16 --> 404 Page Not Found: Company/view
ERROR - 2021-06-05 05:22:18 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-05 05:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:36:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:40:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 05:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:47:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 05:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 05:50:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:51:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:52:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:52:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:52:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 05:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 05:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 06:02:54 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-05 06:02:55 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-05 06:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:09:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 06:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 06:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:14:42 --> 404 Page Not Found: City/index
ERROR - 2021-06-05 06:14:47 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-05 06:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:23:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 06:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:25:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 06:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:42:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 06:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:52:53 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-06-05 06:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 06:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:01:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:04:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:05:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:10:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:10:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:10:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:13:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:13:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:15:51 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-05 07:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:16:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:16:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:17:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:20:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:21:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:21:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:21:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:22:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:22:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:22:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 07:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:23:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:24:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:24:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:26:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 07:26:33 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-05 07:26:34 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-05 07:26:35 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-05 07:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:27:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:30:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 07:43:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 07:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:43:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:43:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:43:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 07:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:46:10 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-05 07:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 07:47:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:48:03 --> 404 Page Not Found: City/2
ERROR - 2021-06-05 07:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:50:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 07:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:54:02 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-05 07:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:56:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 07:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 07:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-05 08:03:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 08:03:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 08:03:10 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 08:03:10 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-05 08:03:10 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-05 08:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:05:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 08:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:22:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 08:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:25:17 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-05 08:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:34:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 08:34:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 08:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:44:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 08:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:47:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 08:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 08:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:51:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 08:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 08:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:06:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 09:08:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 09:08:30 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 09:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:12:39 --> 404 Page Not Found: Config/getuser
ERROR - 2021-06-05 09:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:27:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 09:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:27:34 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-05 09:27:34 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-05 09:27:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 09:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:29:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 09:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:33:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 09:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:36:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 09:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:48:33 --> 404 Page Not Found: City/16
ERROR - 2021-06-05 09:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:52:17 --> 404 Page Not Found: English/index
ERROR - 2021-06-05 09:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 09:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:57:38 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-05 09:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 09:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:03:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 10:03:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 10:03:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 10:03:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 10:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:04:01 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-05 10:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:12:43 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-05 10:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 10:22:51 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 10:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:24:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 10:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 10:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:33:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 10:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 10:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 10:38:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 10:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:42:01 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-06-05 10:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:46:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:46:46 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-05 10:46:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:46:47 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-05 10:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:47:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:47:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:47:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:47:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:47:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:47:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:48:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:49:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:49:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:49:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:54:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:54:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:54:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:54:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 10:54:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 10:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:55:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 10:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:57:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-05 10:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 10:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 10:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:02:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:04:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 11:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:13:51 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 11:14:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 11:14:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:15:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:16:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:18:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:19:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:19:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:27:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 11:27:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 11:27:38 --> 404 Page Not Found: Env/index
ERROR - 2021-06-05 11:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Www20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Wwwxuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Www_xuanhao_net20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Wwwxuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Xuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Xuanhao_net20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Xuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Xuanhao20210603rar/index
ERROR - 2021-06-05 11:32:14 --> 404 Page Not Found: Www20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Wwwxuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Www_xuanhao_net20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Wwwxuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhao_net20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhao20210603targz/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Www20210603zip/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Wwwxuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Www_xuanhao_net20210603zip/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Wwwxuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhao_net20210603zip/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:15 --> 404 Page Not Found: Xuanhao20210603zip/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Www2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Wwwxuanhaonet2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Www_xuanhao_net2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Wwwxuanhaonet2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhaonet2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhao_net2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhaonet2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhao2021-06-03rar/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Www2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Wwwxuanhaonet2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Www_xuanhao_net2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Wwwxuanhaonet2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhaonet2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhao_net2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhaonet2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Xuanhao2021-06-03targz/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Www2021-06-03zip/index
ERROR - 2021-06-05 11:32:16 --> 404 Page Not Found: Wwwxuanhaonet2021-06-03zip/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Www_xuanhao_net2021-06-03zip/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Wwwxuanhaonet2021-06-03zip/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Xuanhaonet2021-06-03zip/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Xuanhao_net2021-06-03zip/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Xuanhaonet2021-06-03zip/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Xuanhao2021-06-03zip/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Www20210603rar/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Wwwxuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Www_xuanhao_net20210603rar/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Wwwxuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:17 --> 404 Page Not Found: Xuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhao_net20210603rar/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhaonet20210603rar/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhao20210603rar/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Www20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Wwwxuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Www_xuanhao_net20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Wwwxuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhao_net20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhaonet20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhao20210603targz/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Www20210603zip/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Wwwxuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Www_xuanhao_net20210603zip/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Wwwxuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhao_net20210603zip/index
ERROR - 2021-06-05 11:32:18 --> 404 Page Not Found: Xuanhaonet20210603zip/index
ERROR - 2021-06-05 11:32:19 --> 404 Page Not Found: Xuanhao20210603zip/index
ERROR - 2021-06-05 11:32:19 --> 404 Page Not Found: 20210603rar/index
ERROR - 2021-06-05 11:32:19 --> 404 Page Not Found: 20210603targz/index
ERROR - 2021-06-05 11:32:19 --> 404 Page Not Found: 20210603zip/index
ERROR - 2021-06-05 11:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:34:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 11:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:35:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 11:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:37:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:38:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 11:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 11:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:44:52 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 11:44:52 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 11:44:52 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 11:44:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-05 11:44:54 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-05 11:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:50:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 11:50:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 11:50:05 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-05 11:50:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 11:50:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 11:50:05 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 11:50:06 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 11:50:07 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-05 11:50:08 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-05 11:50:08 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-05 11:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:53:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 11:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:55:43 --> 404 Page Not Found: City/15
ERROR - 2021-06-05 11:56:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 11:56:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 11:56:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 11:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 11:58:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 11:58:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 11:58:50 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 11:59:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 11:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 11:59:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 11:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:07:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:07:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:08:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:08:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:09:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 12:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:09:53 --> 404 Page Not Found: Images/Nxrs4tAtO
ERROR - 2021-06-05 12:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:11:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:12:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:13:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 12:13:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:14:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:15:44 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-05 12:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:19:13 --> 404 Page Not Found: English/index
ERROR - 2021-06-05 12:19:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:21:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:21:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:24:05 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 12:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:24:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:25:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:25:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:26:03 --> 404 Page Not Found: All/index
ERROR - 2021-06-05 12:26:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:26:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:26:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:27:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:27:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:27:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:28:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:29:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:31:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:32:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:33:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:34:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:34:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:35:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:35:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:37:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 12:38:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:38:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:40:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:41:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:41:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:43:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:44:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 12:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:46:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:46:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:46:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:47:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:47:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 12:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:49:04 --> 404 Page Not Found: Feed/index
ERROR - 2021-06-05 12:49:15 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-06-05 12:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:49:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:49:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 12:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:51:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:52:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:52:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:52:57 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-05 12:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:53:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:53:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 12:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:56:18 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 12:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:56:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:56:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:59:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:59:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 12:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 12:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 13:01:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 13:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:02:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:02:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:02:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:03:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:07:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:07:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:08:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:11:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:11:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:12:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:12:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:13:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:14:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:15:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:15:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:16:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:19:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:19:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:21:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:23:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:23:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:24:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:25:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 13:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:27:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:28:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:30:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:32:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 13:34:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:34:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:35:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:37:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:41:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 13:42:37 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-06-05 13:43:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 13:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:49:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 13:57:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 13:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:05:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:08:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:08:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:09:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:09:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:10:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:10:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:13:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:17:04 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 14:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:20:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 14:20:44 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-05 14:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:22:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:22:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:23:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:23:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:23:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:24:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:25:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:26:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:27:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:27:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:28:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:29:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:29:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:29:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 14:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:32:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 14:40:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:40:49 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 14:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:42:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:42:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 14:42:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 14:43:56 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-05 14:44:01 --> 404 Page Not Found: City/index
ERROR - 2021-06-05 14:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:54:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 14:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 14:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:02:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:05:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:06:55 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-06-05 15:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:12:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:12:11 --> 404 Page Not Found: All/index
ERROR - 2021-06-05 15:12:21 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-05 15:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:14:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:16:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 15:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:16:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 15:16:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 15:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:18:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:22:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:22:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:22:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:22:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:25:52 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 15:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:26:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:31:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:31:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:31:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:32:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:35:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:36:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:36:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:37:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:37:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:37:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:38:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:39:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 15:39:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:40:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:43:45 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 15:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:44:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:45:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:51:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 15:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:52:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 15:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:52:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:53:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:55:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:55:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:55:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:55:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 15:57:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 15:57:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:57:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:57:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 15:58:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 15:58:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:59:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 15:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:00:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:00:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:00:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:01:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:03:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 16:03:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 16:03:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:03:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:04:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:05:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:08:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:08:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:09:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:09:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:10:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:10:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:11:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:11:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:11:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:11:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:12:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:18:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 16:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:21:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:21:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:21:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:22:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:22:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:22:26 --> 404 Page Not Found: 1/all
ERROR - 2021-06-05 16:22:35 --> 404 Page Not Found: City/2
ERROR - 2021-06-05 16:23:14 --> 404 Page Not Found: City/10
ERROR - 2021-06-05 16:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:25:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:27:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:28:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 16:28:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:29:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:29:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:30:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:30:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:30:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:32:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:34:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 16:34:10 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-05 16:34:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 16:35:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 16:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:39:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:39:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:41:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 16:41:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:41:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:48:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:48:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:49:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:51:06 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 16:51:06 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 16:51:06 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 16:51:06 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 16:51:06 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 16:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:51:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:51:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 16:52:29 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-05 16:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 16:59:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 16:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:00:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:01:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:01:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:01:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:05:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:08:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:10:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:10:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 17:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:13:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 17:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:20:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:20:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:20:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:20:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:21:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:21:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:21:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:21:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:21:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:21:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:22:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:22:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:22:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:22:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:22:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:22:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:22:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:25:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:27:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:27:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:29:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:29:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:31:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:31:56 --> 404 Page Not Found: English/index
ERROR - 2021-06-05 17:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:33:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:34:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:39:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 17:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:39:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 17:41:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:41:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:41:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:41:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:41:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:42:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:43:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:43:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 17:43:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:43:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:44:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:44:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:44:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:44:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:48:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 17:48:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:48:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:50:02 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-05 17:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:53:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:54:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:55:18 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-05 17:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:55:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:56:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 17:56:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:56:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:56:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:57:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 17:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 17:59:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:00:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:00:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:01:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:05:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 18:05:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 18:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 18:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:09:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:10:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:11:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:11:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:13:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:17:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:17:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:17:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:19:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:19:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:19:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:19:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:20:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:22:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:22:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:23:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:23:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 18:24:19 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-06-05 18:24:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:25:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:26:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:26:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:27:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:27:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:27:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:27:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:29:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:30:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:31:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 18:31:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:31:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:32:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:32:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 18:32:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:33:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:33:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:36:21 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 18:36:21 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 18:36:22 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 18:36:22 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 18:36:22 --> 404 Page Not Found: City/1
ERROR - 2021-06-05 18:38:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:39:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:39:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:39:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:40:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:40:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:42:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:42:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 18:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:43:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:44:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 18:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:44:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:45:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:45:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:45:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:47:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:49:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:49:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:49:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:49:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:50:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:52:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:52:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:52:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:52:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:54:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:55:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:56:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:58:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 18:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 18:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:00:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:00:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:01:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:01:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:02:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:03:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:03:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:03:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:03:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:05:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:05:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 19:07:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:07:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:07:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:07:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:08:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:08:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:08:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:09:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:10:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:11:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:11:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:12:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:14:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:14:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:14:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:15:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:15:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:19:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:19:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:19:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:20:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:20:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:20:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:21:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:21:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:21:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:22:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:22:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:23:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:23:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 19:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:24:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:25:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:25:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:25:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 19:26:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:26:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:26:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:26:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:26:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:26:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:27:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:27:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:27:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:27:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:28:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:28:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:28:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:29:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:29:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:29:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:30:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:30:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 19:30:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:31:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:31:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:31:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:31:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:31:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:32:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:32:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:32:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:32:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:32:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:32:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:32:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:33:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:33:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:33:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:33:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:33:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:33:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:34:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:34:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:34:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:34:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:34:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:35:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:35:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 19:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:35:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:35:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:36:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:36:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:38:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:39:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:39:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:39:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:39:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:40:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:41:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:41:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:42:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:42:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:43:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:43:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:43:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:43:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:43:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:44:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 19:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:44:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:44:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:44:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:45:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:46:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:46:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:46:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:47:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:47:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:47:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:48:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:49:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:49:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:49:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 19:49:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:49:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:50:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:50:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:50:32 --> 404 Page Not Found: Actuator/health
ERROR - 2021-06-05 19:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:50:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:50:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:51:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:51:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:51:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:51:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:51:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:51:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:52:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:52:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:53:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:53:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:53:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:53:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:53:50 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-05 19:54:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:54:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:54:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:54:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:55:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:57:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:57:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:57:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:57:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:57:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:58:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:58:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:58:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:58:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 19:59:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 19:59:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 19:59:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:00:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:00:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:00:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:00:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:01:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:01:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:01:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:02:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:02:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:02:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:02:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:03:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:03:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:03:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:03:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:03:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:03:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:03:43 --> 404 Page Not Found: Shell/index
ERROR - 2021-06-05 20:03:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 20:03:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:04:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:04:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:04:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:05:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:05:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:05:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:05:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:05:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:08:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:08:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:08:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:08:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:09:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:10:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:11:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:12:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:12:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:12:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:12:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:14:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:14:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:14:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:14:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:15:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:15:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:16:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 20:16:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 20:16:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:16:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:16:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:16:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 20:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:19:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:19:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:19:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:19:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:20:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:21:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:21:36 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-05 20:22:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:22:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:22:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:22:41 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-05 20:22:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:23:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:23:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:23:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:25:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:25:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 20:25:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:26:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:26:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:27:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:28:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:28:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:28:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:29:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:30:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:31:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:31:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:32:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:34:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:34:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:34:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:34:40 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-05 20:34:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:35:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 20:35:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 20:35:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:36:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:36:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:36:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:37:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:39:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:39:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:39:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:40:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:40:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:40:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:41:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:41:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:42:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:42:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:42:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:42:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:43:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:43:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:43:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:43:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:44:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:44:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:44:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 20:44:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:45:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:52:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:52:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:53:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:53:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:54:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:56:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:57:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 20:59:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:59:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:59:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:59:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 20:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:00:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:00:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:00:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:01:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:01:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:02:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:03:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:03:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:04:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:05:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:05:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:06:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:06:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:06:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:06:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-05 21:06:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-05 21:06:39 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-05 21:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:07:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:07:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:07:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:08:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:08:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 21:08:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 21:08:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 21:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:09:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:09:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:09:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:10:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:11:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:12:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:12:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:13:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:15:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:15:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:16:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:16:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-05 21:16:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:19:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:19:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:20:38 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-05 21:20:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:21:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-05 21:21:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:21:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:21:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:22:19 --> 404 Page Not Found: Hudson/index
ERROR - 2021-06-05 21:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:22:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:22:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 21:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:23:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:24:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:24:59 --> 404 Page Not Found: Config/getuser
ERROR - 2021-06-05 21:26:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:26:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:26:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:27:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:27:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:27:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:29:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:29:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:30:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:31:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:32:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:32:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:33:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:33:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:33:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:34:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:35:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:35:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:38:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:38:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:39:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:39:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:39:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:40:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:42:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:47:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:48:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:48:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 21:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:50:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:51:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:51:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:54:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 21:55:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 21:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:57:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 21:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 21:59:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:08:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:08:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:08:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:10:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:17:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:18:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:18:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:18:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:19:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:20:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:20:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:21:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:22:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:25:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 22:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:30:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:30:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:31:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:31:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:31:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:31:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:32:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:33:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:34:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:34:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:37:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:38:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:39:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:39:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:40:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:41:33 --> 404 Page Not Found: English/index
ERROR - 2021-06-05 22:41:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:42:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:45:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:45:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:46:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:46:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:50:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:54:42 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-05 22:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:58:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:58:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 22:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 22:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 22:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:00:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:00:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 23:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:02:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:03:01 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-05 23:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:06:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 23:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:07:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-05 23:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:11:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 23:11:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:13:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 23:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:16:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-05 23:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:19:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:23:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 23:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:28:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:32:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:40:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:40:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:41:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-05 23:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:42:24 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-06-05 23:43:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 23:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:52:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-05 23:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-05 23:59:02 --> 404 Page Not Found: Robotstxt/index
