<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-01 00:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 00:06:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 00:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 00:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 00:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 00:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 00:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 00:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 00:54:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 01:17:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 01:23:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 01:42:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 02:02:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 02:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 02:30:03 --> 404 Page Not Found: M/js
ERROR - 2021-11-01 02:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 02:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 02:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 02:44:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 02:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 02:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 02:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 03:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 03:15:23 --> 404 Page Not Found: Include/calendar
ERROR - 2021-11-01 03:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 03:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 03:27:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 03:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 03:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 03:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 03:50:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 04:01:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 04:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 04:12:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 04:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 04:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 04:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 04:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 04:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 04:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 04:30:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 04:54:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 05:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 05:14:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 05:14:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 05:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 05:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 05:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 05:35:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 05:41:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 05:48:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 05:57:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 06:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 06:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 06:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 06:33:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 06:33:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 06:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 06:42:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 06:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 06:54:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 06:54:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 06:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 07:02:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 07:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 07:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 07:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 07:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 07:35:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 08:00:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 08:00:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 08:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 08:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 08:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 08:28:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 08:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 08:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 08:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 08:45:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 08:50:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 09:07:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 09:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 09:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 09:19:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 09:20:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 09:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 09:34:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 09:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 09:39:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 09:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 09:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 09:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 09:44:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 09:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 10:02:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 10:05:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 10:05:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 10:05:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 10:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 10:06:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 10:06:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 10:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 10:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 10:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 10:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 10:31:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:31:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:31:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:32:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:32:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:33:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:33:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:33:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:33:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:33:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:35:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:40:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:44:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 10:45:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:49:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:54:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 10:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:00:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:03:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 11:03:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:06:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 11:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:07:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 11:16:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 11:16:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:20:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:20:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:20:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:20:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 11:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 11:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 11:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 11:41:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 11:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:06:21 --> 404 Page Not Found: Include/calendar
ERROR - 2021-11-01 12:06:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 12:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:07:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 12:07:12 --> 404 Page Not Found: Api/manyou
ERROR - 2021-11-01 12:07:12 --> 404 Page Not Found: Uc_server/view
ERROR - 2021-11-01 12:07:12 --> 404 Page Not Found: Bbs/api
ERROR - 2021-11-01 12:07:12 --> 404 Page Not Found: Bbs/uc_server
ERROR - 2021-11-01 12:07:13 --> 404 Page Not Found: Form/admin
ERROR - 2021-11-01 12:13:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 12:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:23:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 12:46:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 12:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 12:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 12:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 13:00:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 13:03:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 13:03:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 13:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 13:11:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 13:12:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 13:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 13:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 13:19:01 --> 404 Page Not Found: City/15
ERROR - 2021-11-01 13:29:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 13:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 13:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 13:38:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 13:41:58 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-01 13:47:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 13:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 13:53:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 13:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 14:00:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 14:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:04:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:14:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:15:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 14:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 14:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:32:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:32:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:33:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:34:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:34:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:37:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:37:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:38:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 14:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:38:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:39:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 14:45:02 --> 404 Page Not Found: Include/calendar
ERROR - 2021-11-01 14:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 14:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 14:52:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 14:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 15:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 15:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 15:34:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 15:40:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 15:40:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 15:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 15:46:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 15:52:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 15:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 15:58:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 16:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 16:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 16:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 16:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 16:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 16:09:58 --> 404 Page Not Found: City/10
ERROR - 2021-11-01 16:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 16:13:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 16:15:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 16:19:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 16:23:36 --> 404 Page Not Found: City/1
ERROR - 2021-11-01 16:25:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:26:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 16:27:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 16:27:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:28:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:32:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:33:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:45:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 16:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 16:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:52:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:53:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 16:53:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 16:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 17:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 17:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 17:07:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 17:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 17:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:17:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:22:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 17:22:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 17:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:24:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:40:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:41:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:47:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:47:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:48:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:52:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 17:55:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:56:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 17:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 17:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 18:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 18:31:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 18:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 18:49:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 18:49:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 18:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 18:50:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 18:53:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 19:01:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:02:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:05:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 19:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 19:08:36 --> 404 Page Not Found: Text4041635764916/index
ERROR - 2021-11-01 19:08:36 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-01 19:08:37 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-01 19:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 19:10:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 19:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 19:13:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 19:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 19:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 19:25:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 19:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:32:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 19:33:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 19:37:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 19:50:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 19:55:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 19:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 19:58:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 20:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 20:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 20:03:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 20:08:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 20:09:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 20:13:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 20:13:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Webrar/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Webzip/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-11-01 20:17:50 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-11-01 20:17:51 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-11-01 20:17:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 20:21:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 20:21:35 --> 404 Page Not Found: Scripts/editor
ERROR - 2021-11-01 20:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 20:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 20:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 20:28:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 20:29:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 20:30:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 20:30:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 20:31:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 20:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 20:34:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 20:36:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 20:42:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 20:44:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 20:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 20:49:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 21:06:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:08:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:15:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:17:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 21:22:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:23:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:25:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:30:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:35:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 21:37:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:38:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 21:38:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:39:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-01 21:39:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:41:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 21:41:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:41:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:42:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:42:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 21:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:42:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:42:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:43:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 21:46:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:46:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 21:53:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 21:57:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:57:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:58:03 --> 404 Page Not Found: Page/images
ERROR - 2021-11-01 21:58:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:58:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:58:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:59:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 21:59:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 21:59:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:00:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:00:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:00:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:00:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:00:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:00:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:00:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:01:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:01:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:01:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:01:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:02:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:02:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:02:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 22:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 22:03:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:03:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:03:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:03:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:04:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:04:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:05:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:05:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:05:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:05:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:06:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:07:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:07:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:07:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:07:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:07:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:08:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:08:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:08:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:08:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:08:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:09:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 22:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 22:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 22:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 22:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 22:20:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 22:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:23:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-01 22:23:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 22:26:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 22:38:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 22:49:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-01 22:50:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 22:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:50:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 22:51:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 23:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 23:10:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 23:10:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 23:10:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 23:11:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 23:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-01 23:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 23:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 23:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 23:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 23:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-01 23:45:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-01 23:55:20 --> 404 Page Not Found: Robotstxt/index
