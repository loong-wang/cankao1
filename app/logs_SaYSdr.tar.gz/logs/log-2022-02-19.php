<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-19 00:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 00:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 00:39:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 00:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 00:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 00:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 00:49:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:49:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:51:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:54:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 00:56:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 00:56:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 00:58:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 00:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 00:59:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:03:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:04:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:05:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 01:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:05:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:06:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:06:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 01:09:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2022-02-19 01:09:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2022-02-19 01:09:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2022-02-19 01:09:23 --> 404 Page Not Found: Wwwzip/index
ERROR - 2022-02-19 01:09:23 --> 404 Page Not Found: Webrar/index
ERROR - 2022-02-19 01:09:23 --> 404 Page Not Found: Webzip/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocn_comrar/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocn_comzip/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocnrar/index
ERROR - 2022-02-19 01:09:24 --> 404 Page Not Found: Lianghaocnzip/index
ERROR - 2022-02-19 01:11:55 --> 404 Page Not Found: Xxxxfsfsfsfadsafdafdfdaasffasftxt/index
ERROR - 2022-02-19 01:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 01:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 01:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 01:49:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 01:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 01:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 01:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 01:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 01:57:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 02:02:47 --> 404 Page Not Found: App/views
ERROR - 2022-02-19 02:02:48 --> 404 Page Not Found: App/views
ERROR - 2022-02-19 02:02:48 --> 404 Page Not Found: App/views
ERROR - 2022-02-19 02:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 02:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 02:17:49 --> 404 Page Not Found: Xxxxfsfsfsfadsafdafdfdaasffasftxt/index
ERROR - 2022-02-19 02:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 02:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 02:28:09 --> 404 Page Not Found: Xxxxfsfsfsfadsafdafdfdaasffasftxt/index
ERROR - 2022-02-19 02:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:40:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 02:45:00 --> 404 Page Not Found: Xxxxfsfsfsfadsafdafdfdaasffasftxt/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Webrar/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Webzip/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2022-02-19 02:47:05 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2022-02-19 02:47:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2022-02-19 02:47:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2022-02-19 02:47:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2022-02-19 02:47:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2022-02-19 02:47:06 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2022-02-19 02:47:06 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2022-02-19 02:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 02:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 03:01:41 --> 404 Page Not Found: Xxxxfsfsfsfadsafdafdfdaasffasftxt/index
ERROR - 2022-02-19 03:03:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:05:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:07:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:10:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:22:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 03:36:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 03:36:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 03:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 03:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 03:46:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:52:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 03:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 03:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 03:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 04:01:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 04:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 04:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 04:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 04:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 04:33:14 --> 404 Page Not Found: Xxxxfsfsfsfadsafdafdfdaasffasftxt/index
ERROR - 2022-02-19 04:35:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 04:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 04:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 04:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 04:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:33:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 05:36:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 05:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:38:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 05:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 05:58:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 05:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 06:43:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:43:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:43:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 06:44:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:44:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:45:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:45:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:45:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:45:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:45:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:45:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:45:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 06:50:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 06:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:26:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:26:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:27:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:27:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:29:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:30:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:34:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 07:35:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:35:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:35:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:36:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:36:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 07:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:50:14 --> 404 Page Not Found: Shopasp/index
ERROR - 2022-02-19 07:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 07:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 07:57:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 07:57:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 08:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 08:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 08:27:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 08:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 08:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 08:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 08:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 08:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 08:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:00:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 09:00:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 09:01:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 09:02:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 09:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:13:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:14:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 09:19:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 09:25:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 09:26:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 09:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:28:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:35:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:37:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:37:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 09:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 09:45:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:56:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 09:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 10:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 10:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 10:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 10:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 10:14:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 10:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 10:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 10:41:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 10:41:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 10:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 10:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:01:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:02:37 --> 404 Page Not Found: App/views
ERROR - 2022-02-19 11:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:11:22 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-19 11:11:22 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-19 11:11:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 11:11:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:11:23 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-19 11:11:28 --> 404 Page Not Found: Member/space
ERROR - 2022-02-19 11:11:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 11:11:28 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-19 11:11:29 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-19 11:11:34 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:35 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-19 11:11:35 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:35 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:11:35 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-19 11:11:35 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 11:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:33:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 11:33:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 11:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 11:42:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 11:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 11:48:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Wwwrar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Webrar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Webzip/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2022-02-19 11:53:22 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2022-02-19 11:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 11:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 11:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 11:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 12:00:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 12:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:11:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:12:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:16:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 12:22:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 12:23:48 --> 404 Page Not Found: Html-cn/products--1-1-2-1.html
ERROR - 2022-02-19 12:24:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:25:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:25:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:28:19 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-19 12:28:21 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-19 12:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 12:38:54 --> 404 Page Not Found: Sitemap34600html/index
ERROR - 2022-02-19 12:40:41 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Wwwrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Webrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Webzip/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocn_comrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocn_comzip/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocnrar/index
ERROR - 2022-02-19 12:40:42 --> 404 Page Not Found: Lianghaocnzip/index
ERROR - 2022-02-19 12:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 12:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:51:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 12:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 12:56:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:56:36 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-19 12:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 12:57:33 --> 404 Page Not Found: Previewdo/index
ERROR - 2022-02-19 12:58:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:00:34 --> 404 Page Not Found: Haoma/index
ERROR - 2022-02-19 13:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 13:03:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:03:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 13:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:09:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 13:10:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 13:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 13:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 13:21:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 13:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:27:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 13:32:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 13:36:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 13:36:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 13:39:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 13:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 13:39:50 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2022-02-19 13:40:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 13:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 13:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 13:55:15 --> 404 Page Not Found: Html-cn/new-products--1-1-2-1.html
ERROR - 2022-02-19 13:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 13:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 14:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 14:06:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 14:06:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 14:11:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 14:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:14:51 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-19 14:14:51 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-19 14:18:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 14:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:24:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:26:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 14:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 14:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:33:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:34:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:36:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:36:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 14:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:37:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:38:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 14:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 14:38:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:38:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:39:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:39:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:40:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:40:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:42:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:42:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:43:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:44:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 14:45:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:46:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:46:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:48:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 14:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:49:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:50:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:50:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:50:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:51:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:51:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:52:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 14:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:54:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:54:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:57:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:59:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 14:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 14:59:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 14:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:00:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:01:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:29:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:29:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:32:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:47:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:47:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 15:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 15:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:19:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:22:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:30:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:31:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:32:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:32:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 16:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 16:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 17:04:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:06:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:11:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:11:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:11:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:11:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:14:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:15:41 --> 404 Page Not Found: Haoma/index
ERROR - 2022-02-19 17:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 17:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 17:29:45 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2022-02-19 17:38:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 17:39:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 17:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:46:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:47:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:48:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 17:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:49:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:49:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:50:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:50:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:50:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:51:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:51:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:51:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:51:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:51:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:52:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:53:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:53:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:53:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:53:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:53:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 17:54:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:54:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:55:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 17:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:55:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 17:57:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 18:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 18:06:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:06:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 18:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 18:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:13:52 --> Severity: error --> 11111 test 1
ERROR - 2022-02-19 18:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:24:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 18:43:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:45:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 18:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:47:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 18:54:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 18:55:36 --> 404 Page Not Found: Vnomiblwpxcejdz/index
ERROR - 2022-02-19 18:55:36 --> 404 Page Not Found: admin/Login/look.html
ERROR - 2022-02-19 18:55:37 --> 404 Page Not Found: Info/hide
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Option/coin
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/pc
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Btc/system-user
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/chat
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Web/wap
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Static/wap
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/index
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Backend/index
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Dock/system
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Auth/web
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/zhenren
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/index
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/currency
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: :8088/index
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/config
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: Api/config
ERROR - 2022-02-19 18:55:38 --> 404 Page Not Found: admin/Event/uploadfile
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Pub/getQhDynamic
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Home/tools
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Pc/tools
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Manifestjson/index
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Step3asp/index
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Application/Home
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Api/Game
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: AppApi/NotLoggedInApi
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Api/home
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Xmlb/index
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: V2/start
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Api/user
ERROR - 2022-02-19 18:55:39 --> 404 Page Not Found: Api/v1
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/site
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Notice/unreadMsgCount
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/v2
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/apps
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/user
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/site
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Sys/setting
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Login/index.asp
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: History_codeshtml/index
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/login
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: OpenApi/getHelpInfo
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/shares
ERROR - 2022-02-19 18:55:40 --> 404 Page Not Found: Api/sms
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Js/preload
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Default_drawnoticeshtml/index
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: H5/login
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Shujuku/index.asp
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: En/autonews.html
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Home/login
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Api/product
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Service/index
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Wallet/index
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: User/login.html
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Ws/index
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Api/index
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Api/getapi
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: :8013/index
ERROR - 2022-02-19 18:55:41 --> 404 Page Not Found: Mobile/index.html
ERROR - 2022-02-19 18:55:42 --> 404 Page Not Found: Api/message
ERROR - 2022-02-19 18:55:42 --> 404 Page Not Found: Index/index
ERROR - 2022-02-19 18:55:42 --> 404 Page Not Found: Index/index
ERROR - 2022-02-19 18:55:42 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-19 18:55:42 --> 404 Page Not Found: Fei1asp/index
ERROR - 2022-02-19 18:55:42 --> 404 Page Not Found: Business/t-ec-info
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: admin/Auth/login
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Ajax/index_b_trends
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Index/login
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Platform/passport
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Melody/api
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Index/chat
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Html/wechat
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Api/index
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: V1/management
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Gethmaspx/index
ERROR - 2022-02-19 18:55:43 --> 404 Page Not Found: Native/getStationInfo.do
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Api/nimcc
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: View/game
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Api/exclude
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Template/Home
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Web/api
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Views/bank
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Index/index
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Index/index
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: M/trial.asp
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Jsonpublic/selectAddtion.asp
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Bin-release/update_descriptor_1.xml
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Mobile/loan
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Index/index
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Mobile/index
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Mobile/api
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Resource/ui_config
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Image/delImage
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Login/index
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Loan/SubmitLogin
ERROR - 2022-02-19 18:55:44 --> 404 Page Not Found: Superadmin/lock.lock
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Index/pcpage
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Static/appAdd.jsp
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Api/Index
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Index/index
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Trade/quote
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Index/lotteryHall.do
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: User/Reg
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Wx/ZFpass.asp
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Case/index
ERROR - 2022-02-19 18:55:45 --> 404 Page Not Found: Api/uploads
ERROR - 2022-02-19 18:55:46 --> 404 Page Not Found: Public/1.txt
ERROR - 2022-02-19 18:55:46 --> 404 Page Not Found: _login/in
ERROR - 2022-02-19 18:55:46 --> 404 Page Not Found: Aw010072asp/index
ERROR - 2022-02-19 18:55:46 --> 404 Page Not Found: 11txt/index
ERROR - 2022-02-19 18:55:46 --> 404 Page Not Found: Db/admin_yly.sql
ERROR - 2022-02-19 18:55:46 --> 404 Page Not Found: _vti_pvt/structure.cnf
ERROR - 2022-02-19 18:55:46 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Gov/manager
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: 1asp/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Guanyuhtml/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Detaila/purchaseorder.asp
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Manager/top.asp
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Loginasp/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Submitasp/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Verificationasp/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: %23m%23a%23n%23a%23g%23e%23r_/index.asp
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Control/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Serverhtml/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Dd/order.asp
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Wap/tixing.asp
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Captchaasp/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Ht/top.asp
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Networdasp/index
ERROR - 2022-02-19 18:55:47 --> 404 Page Not Found: Manager/index.asp
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: T3/Account
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Txt_index_dna_cntxt/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Ye1asp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: 123/stat_login.asp
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Submit-tbasp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Onlinerunasp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Erroasp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Vwaitasp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Jiankonghtm/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Instructions/toWait.do
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: S1asp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Error3asp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Postasp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Save2asp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Submitasp/index
ERROR - 2022-02-19 18:55:48 --> 404 Page Not Found: Cxkcasp/index
ERROR - 2022-02-19 18:55:49 --> 404 Page Not Found: Zhucheasp/index
ERROR - 2022-02-19 18:55:49 --> 404 Page Not Found: Code/cxk_xym.asp
ERROR - 2022-02-19 18:55:49 --> 404 Page Not Found: Plus/guestbook
ERROR - 2022-02-19 18:55:49 --> 404 Page Not Found: Admin/Index
ERROR - 2022-02-19 18:55:49 --> 404 Page Not Found: User/step1.asp
ERROR - 2022-02-19 18:55:50 --> 404 Page Not Found: Msky/v1.0
ERROR - 2022-02-19 18:55:51 --> 404 Page Not Found: %E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8Etxt/index
ERROR - 2022-02-19 18:59:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 19:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 19:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 19:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 19:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 19:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 19:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 19:25:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 19:27:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 19:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 19:52:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 19:52:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 19:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 19:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 19:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 19:58:16 --> 404 Page Not Found: App/views
ERROR - 2022-02-19 19:58:16 --> 404 Page Not Found: App/views
ERROR - 2022-02-19 19:58:16 --> 404 Page Not Found: App/views
ERROR - 2022-02-19 20:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:16:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:28:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 20:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:29:03 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-19 20:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:32:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 20:33:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:39:45 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-02-19 20:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:42:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 20:42:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 20:42:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 20:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 20:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 20:54:40 --> 404 Page Not Found: Sitemap50959html/index
ERROR - 2022-02-19 20:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 21:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 21:13:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 21:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 21:22:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:23:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-19 21:23:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-19 21:31:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:40:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:40:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 21:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 21:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 21:50:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 21:50:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 21:50:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 21:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 21:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:02:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 22:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 22:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 22:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 22:54:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 22:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 22:59:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 23:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 23:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 23:24:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:29:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 23:29:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-19 23:38:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:38:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 23:39:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 23:43:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 23:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:43:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-19 23:48:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:51:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:51:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-19 23:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 23:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-19 23:55:38 --> 404 Page Not Found: Robotstxt/index
