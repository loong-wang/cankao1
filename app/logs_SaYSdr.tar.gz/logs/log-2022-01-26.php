<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-26 00:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 00:42:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 00:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 00:58:54 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-26 01:04:24 --> 404 Page Not Found: 404/index.html
ERROR - 2022-01-26 01:04:24 --> 404 Page Not Found: 404/index.html
ERROR - 2022-01-26 01:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 01:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 01:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 01:16:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 01:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 01:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 01:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 01:31:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 01:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 01:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 01:47:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 01:50:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 01:59:57 --> 404 Page Not Found: City/16
ERROR - 2022-01-26 02:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 02:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 02:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 02:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 02:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:08:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Wwwxuanhaonet7z/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Www_xuanhao_net7z/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2022-01-26 03:08:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2022-01-26 03:08:46 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2022-01-26 03:08:46 --> 404 Page Not Found: Wwwxuanhaonet7z/index
ERROR - 2022-01-26 03:08:46 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2022-01-26 03:08:46 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2022-01-26 03:08:46 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2022-01-26 03:08:46 --> 404 Page Not Found: Xuanhaonet7z/index
ERROR - 2022-01-26 03:08:47 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2022-01-26 03:08:47 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2022-01-26 03:08:47 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2022-01-26 03:08:47 --> 404 Page Not Found: Xuanhao7z/index
ERROR - 2022-01-26 03:08:47 --> 404 Page Not Found: Xuanhaowwwzip/index
ERROR - 2022-01-26 03:08:47 --> 404 Page Not Found: Xuanhaowwwrar/index
ERROR - 2022-01-26 03:08:48 --> 404 Page Not Found: Xuanhaowwwtargz/index
ERROR - 2022-01-26 03:08:48 --> 404 Page Not Found: Xuanhaowww7z/index
ERROR - 2022-01-26 03:08:48 --> 404 Page Not Found: Xuanhaowebrar/index
ERROR - 2022-01-26 03:08:48 --> 404 Page Not Found: Xuanhaowebzip/index
ERROR - 2022-01-26 03:08:48 --> 404 Page Not Found: Xuanhaowebtargz/index
ERROR - 2022-01-26 03:08:48 --> 404 Page Not Found: Xuanhaoweb7z/index
ERROR - 2022-01-26 03:08:48 --> 404 Page Not Found: Xuanhaowwwrootzip/index
ERROR - 2022-01-26 03:08:49 --> 404 Page Not Found: Xuanhaowwwrootrar/index
ERROR - 2022-01-26 03:08:49 --> 404 Page Not Found: Xuanhaowwwroottargz/index
ERROR - 2022-01-26 03:08:49 --> 404 Page Not Found: Xuanhaowwwroot7z/index
ERROR - 2022-01-26 03:08:49 --> 404 Page Not Found: Wwwrar/index
ERROR - 2022-01-26 03:08:49 --> 404 Page Not Found: Wwwzip/index
ERROR - 2022-01-26 03:08:50 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2022-01-26 03:08:50 --> 404 Page Not Found: Www7z/index
ERROR - 2022-01-26 03:08:50 --> 404 Page Not Found: Webrar/index
ERROR - 2022-01-26 03:08:50 --> 404 Page Not Found: Webzip/index
ERROR - 2022-01-26 03:08:50 --> 404 Page Not Found: Webtargz/index
ERROR - 2022-01-26 03:08:50 --> 404 Page Not Found: Webtar7z/index
ERROR - 2022-01-26 03:08:51 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2022-01-26 03:08:51 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2022-01-26 03:08:51 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2022-01-26 03:08:51 --> 404 Page Not Found: Wwwroot7z/index
ERROR - 2022-01-26 03:08:51 --> 404 Page Not Found: Websiterar/index
ERROR - 2022-01-26 03:08:51 --> 404 Page Not Found: Websitezip/index
ERROR - 2022-01-26 03:08:52 --> 404 Page Not Found: Websitetargz/index
ERROR - 2022-01-26 03:08:52 --> 404 Page Not Found: Website17z/index
ERROR - 2022-01-26 03:08:52 --> 404 Page Not Found: Website1rar/index
ERROR - 2022-01-26 03:08:52 --> 404 Page Not Found: Website1zip/index
ERROR - 2022-01-26 03:08:52 --> 404 Page Not Found: Website1targz/index
ERROR - 2022-01-26 03:08:52 --> 404 Page Not Found: Website17z/index
ERROR - 2022-01-26 03:08:54 --> 404 Page Not Found: Yuanmazip/index
ERROR - 2022-01-26 03:08:54 --> 404 Page Not Found: Yuanmarar/index
ERROR - 2022-01-26 03:08:54 --> 404 Page Not Found: Yuanmatargz/index
ERROR - 2022-01-26 03:08:54 --> 404 Page Not Found: Yuanma7z/index
ERROR - 2022-01-26 03:08:54 --> 404 Page Not Found: Beifenrar/index
ERROR - 2022-01-26 03:08:54 --> 404 Page Not Found: Beifenzip/index
ERROR - 2022-01-26 03:08:55 --> 404 Page Not Found: Beifentargz/index
ERROR - 2022-01-26 03:08:55 --> 404 Page Not Found: Beifen7z/index
ERROR - 2022-01-26 03:08:55 --> 404 Page Not Found: Backuprar/index
ERROR - 2022-01-26 03:08:55 --> 404 Page Not Found: Backupzip/index
ERROR - 2022-01-26 03:08:55 --> 404 Page Not Found: Backuptargz/index
ERROR - 2022-01-26 03:08:55 --> 404 Page Not Found: Backup7z/index
ERROR - 2022-01-26 03:09:50 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-01-26 03:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:20:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 03:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:51:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 03:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 03:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 04:18:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 04:18:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 04:18:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 04:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 04:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 04:43:00 --> 404 Page Not Found: App/views
ERROR - 2022-01-26 04:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 04:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 04:54:33 --> 404 Page Not Found: Mgmt/shared
ERROR - 2022-01-26 04:54:33 --> 404 Page Not Found: Mgmt/tm
ERROR - 2022-01-26 04:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:11:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 05:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 05:12:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-26 05:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 05:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 05:48:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 05:48:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 05:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 05:48:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 05:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 05:54:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 05:54:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 06:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 06:14:34 --> 404 Page Not Found: City/16
ERROR - 2022-01-26 06:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 06:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 06:34:50 --> 404 Page Not Found: Env/index
ERROR - 2022-01-26 06:40:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 06:40:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 06:42:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 06:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 06:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 07:11:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 07:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 07:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 07:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 07:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 07:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:10:38 --> 404 Page Not Found: Expensesasp/index
ERROR - 2022-01-26 08:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:35:00 --> 404 Page Not Found: City/10
ERROR - 2022-01-26 08:42:49 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-26 08:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:45:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 08:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 08:58:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 08:59:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 09:00:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 09:00:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 09:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:35:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 09:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:40:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:42:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:42:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:43:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:47:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:47:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:50:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 09:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 09:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:02:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:08:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 10:08:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 10:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:12:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 10:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:24:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:25:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:25:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:26:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:26:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:27:33 --> 404 Page Not Found: City/1
ERROR - 2022-01-26 10:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:31:25 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-26 10:31:25 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-26 10:31:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 10:31:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:31:26 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-26 10:31:26 --> 404 Page Not Found: Member/space
ERROR - 2022-01-26 10:31:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 10:31:29 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-26 10:31:29 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-26 10:31:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:30 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-26 10:31:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:31:30 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-26 10:31:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 10:32:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:38:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 10:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 10:41:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:47:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:50:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 10:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 10:58:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:01:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:01:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 11:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:16:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:18:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:18:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:20:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:20:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:28:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:28:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:28:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:29:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:29:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 11:32:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 11:49:21 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-26 11:54:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 11:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 11:55:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 11:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 12:07:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 12:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 12:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 12:34:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-26 12:35:07 --> 404 Page Not Found: Member/space
ERROR - 2022-01-26 12:35:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-26 12:35:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 12:52:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 12:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 13:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 13:05:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 13:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 13:14:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 13:15:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 13:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 13:21:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 13:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 13:41:13 --> 404 Page Not Found: City/1
ERROR - 2022-01-26 13:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 13:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 13:55:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 13:58:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 13:58:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 13:59:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 14:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:11:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 14:40:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:40:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:41:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 14:43:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:50:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 14:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 14:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 14:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 14:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:00:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 15:00:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:02:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:03:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:19:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 15:21:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 15:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 15:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 15:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 15:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 15:53:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 15:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:06:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 16:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 16:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 16:14:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 16:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:16:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 16:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 16:17:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 16:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 16:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:34:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 16:35:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:42:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 16:45:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:45:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 16:45:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:45:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:45:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:45:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:45:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:45:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:45:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 16:47:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 16:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 16:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 16:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:02:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 17:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 17:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 17:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:21:03 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 17:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:32:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 17:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:36:11 --> 404 Page Not Found: City/18
ERROR - 2022-01-26 17:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 17:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:50:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 17:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 17:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 17:59:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 18:03:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:03:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:05:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:06:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:11:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 18:14:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 18:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 18:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 18:26:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-26 18:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 18:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 19:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 19:09:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 19:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 19:15:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 19:18:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 19:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 19:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 19:30:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 19:32:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 19:32:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 19:36:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 19:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 19:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 19:46:39 --> 404 Page Not Found: System/ueditor
ERROR - 2022-01-26 19:47:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 19:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 19:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 20:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 20:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 20:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 20:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 20:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:03:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 21:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 21:14:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 21:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 21:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 21:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:44:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 21:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 21:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:02:43 --> 404 Page Not Found: Index/index
ERROR - 2022-01-26 22:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:17:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:18:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:19:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:27:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:28:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:32:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-26 22:36:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:40:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 22:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 22:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:54:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 22:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:55:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 22:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 23:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 23:28:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 23:28:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:28:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 23:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 23:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-26 23:39:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-26 23:49:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:49:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:50:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:51:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:51:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:51:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:51:55 --> 404 Page Not Found: Index/index
ERROR - 2022-01-26 23:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:52:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-26 23:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
