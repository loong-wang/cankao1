<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-18 00:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:06:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:06:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:08:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:15:12 --> 404 Page Not Found: City/16
ERROR - 2021-08-18 00:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:24:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:28:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 00:28:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 00:28:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 00:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:35:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:36:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 00:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:40:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 00:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:42:48 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-08-18 00:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:44:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:45:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:50:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:50:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:51:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 00:52:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 00:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:52:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:55:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 00:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 00:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:10:46 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-18 01:10:46 --> 404 Page Not Found: admin//index
ERROR - 2021-08-18 01:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 01:10:47 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-18 01:10:47 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-08-18 01:10:47 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-08-18 01:10:48 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-18 01:10:48 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-18 01:10:49 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-08-18 01:10:49 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-08-18 01:10:49 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-08-18 01:10:49 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-18 01:10:49 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-18 01:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:13:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 01:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:13:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 01:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:16:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:16:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 01:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:30:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 01:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:32:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:37:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:39:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:42:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:43:03 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-18 01:43:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:47:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:48:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:49:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 01:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 01:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:01:44 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-18 02:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:03:28 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-18 02:03:28 --> 404 Page Not Found: admin//index
ERROR - 2021-08-18 02:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:03:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 02:03:29 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-18 02:03:29 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-08-18 02:03:29 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-08-18 02:03:30 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-08-18 02:03:30 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-08-18 02:03:30 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-18 02:03:30 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-18 02:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:11:40 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-18 02:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:13:37 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-18 02:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:15:41 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-18 02:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:17:46 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-18 02:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:18:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 02:19:51 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-18 02:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:20:49 --> 404 Page Not Found: Login/index
ERROR - 2021-08-18 02:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:21:55 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-18 02:22:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 02:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:25:45 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-18 02:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:29:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:31:10 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-18 02:31:28 --> 404 Page Not Found: Env/index
ERROR - 2021-08-18 02:32:34 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-18 02:32:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 02:33:27 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-18 02:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:36:01 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-18 02:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:41:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 02:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:48:37 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-18 02:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:53:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 02:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:54:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 02:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:55:46 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 02:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:57:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:57:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:57:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:57:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:58:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 02:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 02:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 03:03:51 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-18 03:03:52 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-18 03:03:53 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-18 03:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:11:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 03:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:11:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 03:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:16:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 03:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:40:26 --> 404 Page Not Found: English/index
ERROR - 2021-08-18 03:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:49:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 03:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:50:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 03:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 03:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-18 04:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:01:20 --> 404 Page Not Found: Haoma/index
ERROR - 2021-08-18 04:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:08:57 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-18 04:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:11:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 04:12:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 04:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:14:49 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-18 04:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:16:41 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-18 04:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:20:08 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-18 04:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:23:57 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-18 04:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:35:32 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 04:35:33 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 04:35:33 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 04:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:36:10 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 04:36:42 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 04:37:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 04:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:48:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 04:48:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 04:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:48:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 04:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:50:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 04:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 04:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:05:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:05:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:05:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:05:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:05:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:05:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:05:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:05:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:06:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:06:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:07:48 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-18 05:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:10:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:15:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 05:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:23:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 05:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:34:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:43:22 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-18 05:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:49:31 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 05:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:50:28 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-18 05:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 05:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 06:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:03:55 --> 404 Page Not Found: City/16
ERROR - 2021-08-18 06:05:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 06:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:05:45 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-18 06:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:12:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 06:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:19:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 06:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:20:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 06:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:21:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 06:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 06:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:23:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 06:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:31:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 06:31:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 06:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:33:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 06:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:39:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 06:40:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 06:40:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 06:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:40:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 06:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:46:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 06:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:48:47 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-18 06:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 06:58:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 07:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:02:28 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-18 07:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:07:23 --> 404 Page Not Found: CloudMarking/index
ERROR - 2021-08-18 07:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:09:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 07:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 07:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:10:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 07:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 07:11:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 07:11:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 07:11:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 07:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:12:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 07:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:13:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 07:13:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 07:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:19:23 --> 404 Page Not Found: 2017/0710
ERROR - 2021-08-18 07:19:49 --> 404 Page Not Found: List/372
ERROR - 2021-08-18 07:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:20:11 --> 404 Page Not Found: 47_47710/index
ERROR - 2021-08-18 07:22:22 --> 404 Page Not Found: Env/index
ERROR - 2021-08-18 07:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:25:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 07:25:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 07:26:00 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-18 07:26:01 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-18 07:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:39:15 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-18 07:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:48:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 07:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:54:12 --> 404 Page Not Found: Index/login
ERROR - 2021-08-18 07:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 07:59:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 08:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:06:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:10:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 08:10:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 08:12:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 08:12:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 08:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:13:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 08:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:16:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:32:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 08:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:34:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:35:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:35:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:35:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:36:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:36:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:38:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:39:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:39:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:39:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:39:57 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-18 08:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:40:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 08:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:51:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 08:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 08:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:08:39 --> 404 Page Not Found: Nmaplowercheck1629248919/index
ERROR - 2021-08-18 09:08:39 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-08-18 09:08:39 --> 404 Page Not Found: Evox/about
ERROR - 2021-08-18 09:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:12:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 09:12:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 09:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:18:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:19:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:21:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:21:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:22:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:25:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:25:40 --> 404 Page Not Found: City/index
ERROR - 2021-08-18 09:25:48 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 09:25:53 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 09:25:57 --> 404 Page Not Found: City/10
ERROR - 2021-08-18 09:26:02 --> 404 Page Not Found: City/15
ERROR - 2021-08-18 09:26:11 --> 404 Page Not Found: City/16
ERROR - 2021-08-18 09:26:17 --> 404 Page Not Found: City/2
ERROR - 2021-08-18 09:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:27:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 09:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:44:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 09:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:46:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:48:25 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-18 09:48:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:48:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:49:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:49:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:49:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:49:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:50:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:50:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:50:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:51:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:51:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:51:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:51:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:53:33 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-18 09:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:55:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 09:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 09:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:57:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:57:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:57:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:57:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:57:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:57:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:57:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:57:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 09:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 09:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:10:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 10:11:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:11:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:12:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 10:12:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 10:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:15:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 10:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:20:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:20:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:23:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:25:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:26:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:28:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 10:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:30:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:31:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:35:15 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-18 10:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:37:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:42:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 10:42:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 10:42:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 10:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:55:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 10:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:58:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 10:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 10:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:00:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:01:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:13:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:19:07 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-18 11:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:20:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 11:20:11 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-18 11:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:21:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:21:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:21:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-18 11:21:21 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-18 11:21:55 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-18 11:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:23:21 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-18 11:23:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:23:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:23:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:23:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:23:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:21 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:21 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:24:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:25:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:25:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:26:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:26:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:26:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:26:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:27:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:27:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 11:28:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:28:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:29:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:29:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:29:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:29:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:29:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:29:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:30:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:30:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:30:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:30:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:31:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:31:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:31:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:31:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:31:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:34:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:34:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:34:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:08 --> 404 Page Not Found: City/index
ERROR - 2021-08-18 11:35:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:35:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:35:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:35:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:35:44 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 11:35:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:36:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 11:37:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:38:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 11:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:39:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:39:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:39:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:40:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:41:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 11:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:42:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:42:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:42:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:42:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:42:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 11:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:43:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 11:43:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:45:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:46:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:47:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:47:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:47:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:47:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:47:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:49:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:49:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 11:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:50:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:50:59 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-18 11:51:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 11:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:56:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 11:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 11:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:02:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:03:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:03:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:03:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:03:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:04:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:06:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:09:14 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-18 12:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:10:57 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-18 12:11:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:11:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:12:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:12:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:12:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:12:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-18 12:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:14:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 12:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:14:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:19:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 12:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:20:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:21:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:21:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:23:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 12:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:29:17 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-08-18 12:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:29:59 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-08-18 12:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 12:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:02:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:03:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:06:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into `fox_haoma` (hao_city,hao_type,hao_pinpai,hao_title,hao_jiage,hao_huafei,hao_heyue,hao_beizhu,hao_user,hao_time) values 
ERROR - 2021-08-18 13:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:08:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 13:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:20:29 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-18 13:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:35:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:35:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:36:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:37:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 13:37:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:39:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 13:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:39:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:40:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:41:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 13:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:44:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 13:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:50:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:50:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 13:51:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 13:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 13:59:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:07:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 14:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:10:53 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-08-18 14:10:53 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-18 14:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:17:27 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-18 14:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 14:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:22:52 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-18 14:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:26:25 --> 404 Page Not Found: City/15
ERROR - 2021-08-18 14:26:34 --> 404 Page Not Found: City/15
ERROR - 2021-08-18 14:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:36:32 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-18 14:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:39:10 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-18 14:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 14:42:23 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-18 14:42:24 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-18 14:42:25 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-18 14:42:25 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 14:42:25 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 14:42:25 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 14:42:25 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-18 14:42:25 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-18 14:42:25 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-18 14:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 14:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:46:09 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-18 14:46:40 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-18 14:47:08 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-18 14:47:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 14:47:43 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-18 14:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:48:17 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-18 14:48:50 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-18 14:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:49:24 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-18 14:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:50:00 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-18 14:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 14:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:53:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 14:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:56:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 14:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:57:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 14:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 14:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 14:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:07:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:13:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 15:14:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 15:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:20:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 15:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:30:24 --> 404 Page Not Found: User/index
ERROR - 2021-08-18 15:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:47:53 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-18 15:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:53:00 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-18 15:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:54:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 15:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:56:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:58:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:58:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 15:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 15:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:07:29 --> 404 Page Not Found: City/10
ERROR - 2021-08-18 16:08:18 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-18 16:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:09:54 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-18 16:10:10 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-18 16:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:15:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 16:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:17:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 16:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:21:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 16:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:24:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 16:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:32:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:34:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:34:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:37:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 16:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:40:07 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-18 16:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:41:58 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-18 16:42:04 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-18 16:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:43:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 16:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:48:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 16:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:54:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 16:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 16:59:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 16:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:03:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:04:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:09:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:10:59 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 17:11:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:18:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:20:45 --> 404 Page Not Found: English/index
ERROR - 2021-08-18 17:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:25:50 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-18 17:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:26:15 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-18 17:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:26:57 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-18 17:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:30:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:43:23 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-18 17:43:56 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-18 17:45:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 17:45:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 17:45:25 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-18 17:45:26 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-18 17:45:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:45:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:46:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 17:46:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:46:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:48:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 17:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:50:09 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-18 17:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:51:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 17:51:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 17:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:51:44 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-18 17:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:56:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 17:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 17:59:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 18:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 18:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:00:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 18:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:04:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 18:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:06:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 18:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:23:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 18:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:27:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 18:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:28:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 18:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:39:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:43:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 18:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:43:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:44:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:45:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:50:21 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-18 18:50:22 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-08-18 18:50:22 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-08-18 18:50:22 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-08-18 18:50:23 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-08-18 18:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:52:27 --> 404 Page Not Found: City/1
ERROR - 2021-08-18 18:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:54:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 18:54:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 18:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:55:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 18:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:57:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 18:57:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 18:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 18:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:02:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 19:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 19:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:13:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 19:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:24:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 19:24:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 19:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 19:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 19:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 19:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 19:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 19:58:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 19:59:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 19:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:02:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:05:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:08:23 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-18 20:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:12:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 20:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:15:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 20:16:09 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-18 20:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:22:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 20:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:23:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:24:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 20:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:36:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 20:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:44:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 20:44:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:44:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:51:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-18 20:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 20:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:52:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 20:53:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 20:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 20:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:03:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:05:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:05:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:05:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:06:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:06:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:09:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 21:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:12:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 21:13:24 --> 404 Page Not Found: Adverts/add
ERROR - 2021-08-18 21:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:14:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 21:15:11 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-18 21:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:19:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 21:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:27:57 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-18 21:27:58 --> 404 Page Not Found: Administrator/index
ERROR - 2021-08-18 21:27:59 --> 404 Page Not Found: User/index
ERROR - 2021-08-18 21:27:59 --> 404 Page Not Found: admin//index
ERROR - 2021-08-18 21:28:04 --> 404 Page Not Found: admin/Users/login_do
ERROR - 2021-08-18 21:28:06 --> 404 Page Not Found: Manager/index
ERROR - 2021-08-18 21:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:35:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:36:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 21:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:36:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:46:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 21:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:48:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 21:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:49:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 21:49:27 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-18 21:50:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 21:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 21:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:58:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 21:58:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 21:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 21:59:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 22:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:02:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 22:02:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:04:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:05:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:06:16 --> 404 Page Not Found: Env/index
ERROR - 2021-08-18 22:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:09:33 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-18 22:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:13:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:13:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:21:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 22:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:28:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 22:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:31:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 22:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:32:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:33:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 22:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:41:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:46:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-18 22:49:20 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-18 22:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:52:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 22:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:54:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 22:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 22:58:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:58:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:58:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:58:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:58:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:58:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:58:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 22:59:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 22:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:13:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 23:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:13:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 23:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:25:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 23:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:28:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 23:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:30:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-18 23:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:31:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-18 23:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:34:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:34:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:34:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-18 23:36:44 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-18 23:36:45 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-18 23:36:46 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-18 23:36:46 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-18 23:36:46 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-18 23:36:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-18 23:36:46 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-18 23:36:46 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-18 23:36:46 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-18 23:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:40:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:43:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:43:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 23:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:43:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:45:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:47:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:48:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:48:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:49:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:49:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:50:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:50:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:51:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-18 23:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:52:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:52:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:53:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:53:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-18 23:54:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:56:47 --> 404 Page Not Found: English/index
ERROR - 2021-08-18 23:57:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:57:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:58:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-18 23:59:53 --> 404 Page Not Found: Robotstxt/index
