<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-26 00:03:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:04:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 00:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:07:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:10:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:13:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 00:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 00:55:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 01:05:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 01:19:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 01:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 01:25:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 01:25:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 01:25:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 01:25:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 01:35:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 01:43:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 01:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 01:53:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 01:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 02:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 02:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 02:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 02:09:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 02:11:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 02:18:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 02:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 02:27:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 02:28:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 02:29:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 02:30:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 02:46:27 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2021-10-26 02:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 02:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 02:57:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 02:58:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 03:04:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 03:13:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 03:14:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 03:19:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 03:26:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 03:26:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 03:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 03:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 03:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 03:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 03:45:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-26 04:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 04:30:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 04:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 04:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 05:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 05:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 05:28:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 05:53:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 05:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 05:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 06:15:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 06:15:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 06:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 06:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 06:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 06:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 06:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 06:49:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 07:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 07:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 07:48:49 --> 404 Page Not Found: App/views
ERROR - 2021-10-26 07:48:52 --> 404 Page Not Found: App/views
ERROR - 2021-10-26 07:48:52 --> 404 Page Not Found: App/views
ERROR - 2021-10-26 07:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 08:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 08:23:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 08:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 08:39:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 08:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 08:57:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 08:57:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 09:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 09:06:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 09:09:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 09:12:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 09:15:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 09:18:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 09:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 09:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 09:29:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 09:35:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 09:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 09:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 09:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 09:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 10:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 10:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 10:13:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:17:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 10:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:18:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:19:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:21:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 10:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 10:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 10:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:49:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 10:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 11:04:53 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-10-26 11:09:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 11:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:14:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 11:15:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 11:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:19:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:19:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 11:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 11:19:50 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-26 11:20:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:20:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:21:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:29:44 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-10-26 11:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 11:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 11:31:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 11:32:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 11:39:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 11:40:42 --> 404 Page Not Found: Index/login
ERROR - 2021-10-26 11:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 11:42:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 11:44:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 11:58:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 12:00:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 12:05:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 12:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 12:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 12:07:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 12:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 12:10:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 12:12:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 12:14:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 12:15:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 12:23:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 12:30:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 12:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 12:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 12:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 12:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 12:54:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 12:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 12:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 12:59:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 13:20:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 13:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 13:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:35:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:35:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:36:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:36:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 13:37:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:37:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:37:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:38:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:39:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:39:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:40:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:40:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:42:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 13:46:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 13:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 13:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 13:56:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:56:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 13:56:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 14:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:01:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:08:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:08:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:10:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 14:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:13:45 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-10-26 14:25:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:27:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:44:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 14:44:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 14:44:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 14:44:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 14:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 15:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 15:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 15:02:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:02:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:03:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:06:56 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-10-26 15:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 15:16:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:18:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 15:22:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 15:22:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 15:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 15:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 15:22:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 15:25:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:29:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 15:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 15:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 15:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:40:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:41:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:45:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 15:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 15:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 15:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 16:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:02:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 16:02:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 16:02:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 16:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 16:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 16:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 16:21:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 16:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 16:39:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 16:41:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:52:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:52:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:53:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 16:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 16:56:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:58:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 16:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 17:11:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 17:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 17:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 17:27:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 17:27:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 17:27:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 17:27:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 17:28:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 17:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 17:32:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 17:43:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 17:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:02:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 18:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:16:25 --> 404 Page Not Found: 404/index.html
ERROR - 2021-10-26 18:16:25 --> 404 Page Not Found: 404/index.html
ERROR - 2021-10-26 18:16:31 --> 404 Page Not Found: Page/images
ERROR - 2021-10-26 18:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 18:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:24:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 18:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 18:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 18:53:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 18:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 19:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 19:07:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 19:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 19:19:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 19:22:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:26:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 19:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 19:35:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 19:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 19:50:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:53:54 --> 404 Page Not Found: Edit/net
ERROR - 2021-10-26 19:55:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:55:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:55:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:55:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:55:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:55:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:55:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 19:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 20:12:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 20:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 20:35:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 20:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 21:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 21:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 21:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 21:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 21:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 21:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:45:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-26 21:47:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 21:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 21:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 21:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 21:55:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 21:56:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 21:57:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:00:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 22:07:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 22:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:13:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:13:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:13:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:14:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:19:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:31:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 22:31:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 22:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 22:44:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 22:46:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:46:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-26 22:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 22:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 23:03:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:10:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:12:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 23:12:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 23:19:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 23:19:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 23:19:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-26 23:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 23:24:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:24:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:24:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:24:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-26 23:31:38 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-10-26 23:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-26 23:44:25 --> 404 Page Not Found: Data/admin
