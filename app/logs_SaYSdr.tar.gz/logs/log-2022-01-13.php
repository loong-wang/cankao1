<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-13 00:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 00:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:20:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 00:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:50:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 00:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 00:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 01:03:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:08:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:12:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 01:13:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:14:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 01:14:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:15:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:18:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:27:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 01:44:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:48:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:49:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:49:37 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-01-13 01:50:04 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2022-01-13 01:50:18 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-13 01:50:40 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2022-01-13 01:51:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:51:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:51:43 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-01-13 01:52:18 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2022-01-13 01:52:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 01:53:07 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-01-13 01:54:07 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-01-13 01:54:58 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2022-01-13 02:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 02:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 02:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 02:05:00 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-5html/index
ERROR - 2022-01-13 02:18:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 02:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 02:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 02:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 02:59:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 03:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 03:06:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 03:09:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 03:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 03:29:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 03:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 03:47:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 03:48:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 03:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 03:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 03:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 04:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 04:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 04:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 04:23:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 04:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 04:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 04:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 05:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 05:27:27 --> 404 Page Not Found: City/10
ERROR - 2022-01-13 05:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 05:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 05:39:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 05:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 05:54:01 --> 404 Page Not Found: City/15
ERROR - 2022-01-13 06:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:08:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 06:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:22:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 06:22:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 06:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 06:46:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 06:50:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 06:50:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 07:01:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 07:08:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 07:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 07:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 07:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 07:23:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 07:23:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 07:23:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 07:23:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 07:26:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 07:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 07:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 07:54:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 08:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 08:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 08:26:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 08:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 08:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 08:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:09:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 09:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:16:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 09:28:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:32:22 --> 404 Page Not Found: App/views
ERROR - 2022-01-13 09:32:22 --> 404 Page Not Found: App/views
ERROR - 2022-01-13 09:32:22 --> 404 Page Not Found: App/views
ERROR - 2022-01-13 09:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 09:59:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 09:59:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:04:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 10:05:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 10:06:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 10:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 10:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 10:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 10:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 10:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 10:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 10:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 10:23:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 10:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 10:26:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:27:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 10:27:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 10:27:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 10:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 10:53:16 --> 404 Page Not Found: City/18
ERROR - 2022-01-13 11:01:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 11:04:37 --> 404 Page Not Found: City/16
ERROR - 2022-01-13 11:04:43 --> 404 Page Not Found: City/16
ERROR - 2022-01-13 11:04:43 --> 404 Page Not Found: City/16
ERROR - 2022-01-13 11:05:40 --> 404 Page Not Found: City/16
ERROR - 2022-01-13 11:06:18 --> 404 Page Not Found: City/16
ERROR - 2022-01-13 11:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 11:16:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:16:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:16:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:16:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:17:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 11:23:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 11:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 11:25:52 --> 404 Page Not Found: Login/index
ERROR - 2022-01-13 11:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 11:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 12:02:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:02:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:03:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:03:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 12:06:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 12:10:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 12:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 12:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 13:02:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:03:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 13:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 13:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 13:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 13:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 13:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 13:38:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 13:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 13:50:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:51:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 13:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 13:59:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 14:08:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 14:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 14:18:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 14:18:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 14:18:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 14:25:39 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2022-01-13 14:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 14:40:05 --> 404 Page Not Found: App/views
ERROR - 2022-01-13 14:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 14:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:02:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 15:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:15:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 15:16:15 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-13 15:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:34:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 15:42:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 15:44:46 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2022-01-13 15:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 15:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 16:09:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 16:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 16:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 16:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 16:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 16:13:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 16:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 16:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 16:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 16:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 16:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 16:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 17:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 17:06:33 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 17:15:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 17:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 17:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 17:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 17:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 17:50:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 17:50:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 17:51:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 17:51:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 18:01:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 18:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 18:04:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 18:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 18:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 18:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 18:19:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:19:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:20:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:20:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:21:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:24:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:31:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:32:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:36:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 18:48:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 18:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 18:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 18:52:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 18:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 19:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 19:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 19:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 19:22:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 19:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 19:30:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 19:30:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 19:39:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 19:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 19:44:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 19:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 19:45:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 19:46:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 19:48:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 19:53:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 19:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:10:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:23:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:24:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:25:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:30:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 20:30:40 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-13 20:30:40 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-13 20:30:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 20:30:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:30:41 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-13 20:30:41 --> 404 Page Not Found: Member/space
ERROR - 2022-01-13 20:30:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 20:30:42 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 20:30:42 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 20:30:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:43 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-13 20:30:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:30:44 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 20:30:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 20:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 20:52:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 21:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:04:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 21:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 21:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 21:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:23:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 21:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:30:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:33:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:34:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 21:34:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 21:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 21:59:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 21:59:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 21:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 22:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:09:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 22:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 22:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 22:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 22:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 22:35:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 22:40:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 22:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 22:48:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 22:58:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:31 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-13 23:03:31 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-13 23:03:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 23:03:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 23:03:36 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-13 23:03:36 --> 404 Page Not Found: Member/space
ERROR - 2022-01-13 23:03:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 23:03:41 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:03:41 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:03:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:41 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-13 23:03:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:45 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:03:45 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:03:45 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:08:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:09:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Member/space
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:11:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:13:50 --> 404 Page Not Found: Shell/index
ERROR - 2022-01-13 23:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 23:19:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 23:25:22 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-13 23:25:22 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-13 23:25:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 23:25:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 23:25:23 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-13 23:25:24 --> 404 Page Not Found: Member/space
ERROR - 2022-01-13 23:25:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 23:25:24 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:25:24 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:25:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:25 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-13 23:25:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:25:26 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-13 23:25:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:32:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:33:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-13 23:38:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 23:41:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:42:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 23:47:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-13 23:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-13 23:53:58 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-13 23:55:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-13 23:55:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-13 23:55:48 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-13 23:58:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
