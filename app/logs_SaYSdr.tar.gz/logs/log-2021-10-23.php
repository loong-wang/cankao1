<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-23 00:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 00:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:05:43 --> 404 Page Not Found: Text4041634918743/index
ERROR - 2021-10-23 00:05:43 --> 404 Page Not Found: Evox/about
ERROR - 2021-10-23 00:05:43 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-10-23 00:05:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 00:08:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:12:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 00:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 00:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:22:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 00:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:33:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:33:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:36:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:36:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:36:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:40:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:42:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 00:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:44:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:44:40 --> 404 Page Not Found: App/views
ERROR - 2021-10-23 00:44:40 --> 404 Page Not Found: App/views
ERROR - 2021-10-23 00:44:41 --> 404 Page Not Found: App/views
ERROR - 2021-10-23 00:45:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:46:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 00:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 01:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 01:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 01:37:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 01:37:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 01:37:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 01:38:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 01:44:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 01:50:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 01:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 02:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 02:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 02:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 02:30:19 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-10-23 02:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 02:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 02:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 03:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 03:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 03:45:15 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-10-23 03:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 03:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 04:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 04:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 04:47:33 --> 404 Page Not Found: City/1
ERROR - 2021-10-23 04:52:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:52:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 04:52:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:53:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 04:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 04:56:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 05:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 05:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:28:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 05:31:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 05:31:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 05:32:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 05:39:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 05:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 05:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 06:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 06:08:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 06:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 06:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 06:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 06:19:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 06:22:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 06:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 06:24:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 06:25:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 06:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 06:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 06:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 07:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 07:08:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 07:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 07:13:58 --> 404 Page Not Found: Plain/229
ERROR - 2021-10-23 07:14:53 --> 404 Page Not Found: M/gmwxq
ERROR - 2021-10-23 07:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 07:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 07:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 07:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 08:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 08:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 08:39:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 08:41:43 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-23 08:41:44 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-23 08:41:56 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-23 08:41:56 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-23 08:50:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 08:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 08:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 08:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 09:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 09:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 09:15:30 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-10-23 09:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 09:19:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 09:25:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 09:26:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:35:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 09:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 09:42:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 09:51:37 --> 404 Page Not Found: Index/login
ERROR - 2021-10-23 09:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 09:59:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 10:03:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:03:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:04:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:04:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:05:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:05:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:07:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:08:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:12:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:13:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:13:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:13:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:13:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:14:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:15:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:15:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:16:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 10:16:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:16:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:19:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:19:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:20:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:20:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:26:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:29:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:30:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 10:45:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:47:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 10:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 10:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 11:05:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:06:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:08:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:10:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 11:11:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:12:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:18:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 11:18:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 11:18:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 11:19:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 11:19:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 11:26:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 11:28:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 11:28:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 11:29:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 11:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 11:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 11:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 12:07:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:08:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:08:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 12:09:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 12:09:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 12:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 12:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 12:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 12:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 12:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 12:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 13:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 13:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 13:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 13:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 13:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 14:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 14:18:10 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-10-23 14:26:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 14:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 14:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 14:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 14:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 14:42:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 14:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 14:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 14:43:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 14:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 14:44:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 14:59:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 15:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:16:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:16:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:21:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 15:22:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 15:29:47 --> 404 Page Not Found: CurrentTime/index
ERROR - 2021-10-23 15:33:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 15:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:40:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:41:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 15:41:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:43:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 15:45:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 15:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 15:50:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 15:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:52:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:58:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 15:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:03:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 16:05:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 16:08:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 16:11:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 16:15:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 16:15:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 16:16:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:20:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 16:25:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 16:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 16:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 16:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:48:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:49:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 16:55:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:57:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 16:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 16:57:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 17:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 17:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 17:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 17:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 17:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 17:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 17:36:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 17:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 17:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:05:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 18:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:15:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 18:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:37:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 18:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 18:52:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 18:54:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 18:57:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 19:10:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 19:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 19:19:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 19:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 19:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:33:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 19:33:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 19:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 19:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:41:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:41:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:43:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:46:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 19:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 20:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 20:19:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 20:19:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 20:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 20:23:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 20:25:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 20:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 20:30:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 20:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 20:45:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:46:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:49:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:49:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:50:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:50:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:52:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 20:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 20:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 20:58:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 20:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 21:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 21:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 21:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 21:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 21:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:15:58 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-23 21:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 21:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 21:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:45:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 21:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 21:52:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-23 22:35:52 --> 404 Page Not Found: City/15
ERROR - 2021-10-23 22:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 22:39:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 22:39:29 --> 404 Page Not Found: Api/manyou
ERROR - 2021-10-23 22:39:29 --> 404 Page Not Found: Uc_server/view
ERROR - 2021-10-23 22:39:29 --> 404 Page Not Found: Bbs/api
ERROR - 2021-10-23 22:39:29 --> 404 Page Not Found: Bbs/uc_server
ERROR - 2021-10-23 22:39:29 --> 404 Page Not Found: Application/Home
ERROR - 2021-10-23 22:39:29 --> 404 Page Not Found: Application/Admin
ERROR - 2021-10-23 22:42:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-23 22:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 22:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 23:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 23:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 23:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 23:38:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-23 23:39:25 --> 404 Page Not Found: City/16
ERROR - 2021-10-23 23:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 23:46:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-23 23:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-23 23:53:39 --> 404 Page Not Found: Robotstxt/index
