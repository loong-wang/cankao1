<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-06 00:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:06:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:08:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:08:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:13:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:26:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:26:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:48:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:48:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:50:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 00:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 00:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 00:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:00:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:00:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:01:26 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-06 01:01:26 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-06 01:01:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Member/space
ERROR - 2022-02-06 01:01:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 01:01:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 01:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:21:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:26:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:39:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:39:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:39:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:39:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 01:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:54:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:56:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 01:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 01:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 02:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 02:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:17:12 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-06 02:17:12 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-06 02:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 02:17:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:17:14 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-06 02:17:14 --> 404 Page Not Found: Member/space
ERROR - 2022-02-06 02:17:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 02:17:17 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 02:17:17 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 02:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:20 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-06 02:17:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:17:20 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 02:17:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 02:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:44:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 02:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 02:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 03:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 03:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 03:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 03:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 03:55:13 --> 404 Page Not Found: English/index
ERROR - 2022-02-06 04:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 04:12:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 04:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 04:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 04:44:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 04:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 04:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 04:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 04:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 05:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 05:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 05:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 05:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 05:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:09:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-06 06:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:38:47 --> 404 Page Not Found: Spxx/index
ERROR - 2022-02-06 06:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 06:58:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 07:20:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 07:23:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-06 07:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 07:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 07:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 07:35:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 07:35:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 07:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 07:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 07:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 07:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 07:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 08:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 08:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 08:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 08:17:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-06 08:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 08:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 08:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 08:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 08:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 08:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 08:54:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-06 09:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 09:01:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 09:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:18:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 09:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 09:25:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 09:25:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 09:30:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 09:30:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 09:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:38:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 09:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:46:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:50:55 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-02-06 09:57:23 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-06 09:57:24 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-06 09:57:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 09:57:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 09:57:25 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-06 09:57:25 --> 404 Page Not Found: Member/space
ERROR - 2022-02-06 09:57:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 09:57:26 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 09:57:26 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 09:57:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:27 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-06 09:57:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:57:27 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 09:57:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 09:58:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 09:58:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 09:59:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 10:03:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 10:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:12:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:13:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 10:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 10:42:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 10:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 10:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 10:52:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 10:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 10:55:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 11:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 11:15:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 11:31:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 11:35:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 11:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 11:39:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 11:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 11:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 11:47:56 --> 404 Page Not Found: City/1
ERROR - 2022-02-06 11:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 11:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 12:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:06:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 12:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 12:10:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 12:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 12:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 12:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:46:23 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-06 12:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 12:46:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 13:13:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 13:13:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:13:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 13:26:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 13:35:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:38:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:38:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:40:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:40:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:41:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:41:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:42:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:44:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:45:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:46:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:46:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:46:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 13:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 13:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:05:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 14:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 14:08:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 14:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 14:10:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Member/space
ERROR - 2022-02-06 14:13:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 14:13:11 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 14:13:11 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 14:13:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:11 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-06 14:13:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:13:12 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-06 14:13:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 14:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:46:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 14:46:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 14:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:50:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 14:52:52 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2022-02-06 14:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 14:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 15:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 15:11:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:24:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 15:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 15:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 15:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:32:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:33:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:34:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 15:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 15:49:13 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-02-06 15:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 15:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 15:53:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 15:53:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 15:53:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 15:57:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 15:59:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 16:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 16:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 16:25:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 16:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 16:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 16:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 16:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 16:34:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 16:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 16:37:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 16:37:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 16:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 16:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 16:48:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 16:48:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 16:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 16:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 16:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 16:55:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:12:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 17:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 17:13:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 17:13:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 17:14:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 17:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 17:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 17:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 17:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 17:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:25:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 17:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:36:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:39:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 17:46:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-06 17:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 17:50:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 17:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 18:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 18:05:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 18:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 18:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 18:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 18:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 18:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 18:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 18:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 18:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 19:00:47 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-06 19:05:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 19:08:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:08:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:08:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:11:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:12:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:13:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:14:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 19:15:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:17:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 19:17:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 19:18:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 19:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:23:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 19:30:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 19:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 19:40:35 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-02-06 19:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 19:44:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 19:45:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:50:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 19:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 20:05:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 20:05:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 20:06:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 20:12:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 20:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 20:15:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 20:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 20:31:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 20:31:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 20:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 20:45:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-06 20:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 20:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 20:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:02:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:02:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:03:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:03:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:03:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:09:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:10:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:10:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:10:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:13:36 --> 404 Page Not Found: PhpMyAdmin485/index
ERROR - 2022-02-06 21:13:38 --> 404 Page Not Found: PhpMyAdmin485/index
ERROR - 2022-02-06 21:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:16:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:16:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:17:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:21:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:21:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:21:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:21:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:32:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:32:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:32:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:32:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 21:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:50:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 21:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 21:58:34 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-02-06 22:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 22:07:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-06 22:11:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-06 22:12:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 22:13:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 22:19:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 22:32:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 22:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 22:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 22:45:27 --> 404 Page Not Found: Ipquery/index
ERROR - 2022-02-06 22:45:27 --> 404 Page Not Found: Ipquery/index
ERROR - 2022-02-06 22:53:17 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-02-06 22:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 23:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:06:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:06:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 23:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 23:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 23:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:34:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:37:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:38:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:39:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 23:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-06 23:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 23:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-06 23:55:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 23:55:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 23:56:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 23:56:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 23:56:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-06 23:57:08 --> 404 Page Not Found: Robotstxt/index
