<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-15 00:06:49 --> 404 Page Not Found: admin/Sdfgasp/index
ERROR - 2021-12-15 00:07:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 00:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 00:09:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 00:11:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 00:12:52 --> 404 Page Not Found: Assets/global
ERROR - 2021-12-15 00:17:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 00:17:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 00:17:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 00:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 00:24:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 00:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 00:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 00:41:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 00:41:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 00:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 00:56:25 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-12-15 01:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 01:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 01:20:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 01:22:04 --> 404 Page Not Found: Company/ueditor
ERROR - 2021-12-15 01:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 01:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 01:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 01:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 01:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 01:39:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 01:43:00 --> 404 Page Not Found: admin/Images/cache.asp
ERROR - 2021-12-15 01:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 01:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 01:56:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 02:02:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 02:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 02:04:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 02:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 02:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 02:29:28 --> 404 Page Not Found: admin/Images/cache.asp
ERROR - 2021-12-15 02:40:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 02:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 02:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 02:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:13:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 03:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:20:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 03:20:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 03:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:22:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 03:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:28:26 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-12-15 03:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:35:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 03:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 03:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 03:50:14 --> 404 Page Not Found: Content/ueditor
ERROR - 2021-12-15 03:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:11:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:13:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:17:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:18:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:20:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:20:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:20:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:23:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:24:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:27:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:28:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:29:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:30:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:31:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:31:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:32:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:32:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:33:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:34:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:36:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:37:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:38:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:39:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:39:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:40:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:42:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:44:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 04:44:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:45:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:45:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:46:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:49:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:50:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:52:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 04:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 04:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 05:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 05:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 05:39:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-15 05:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:34:47 --> 404 Page Not Found: Inc/dzx.asp
ERROR - 2021-12-15 06:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 06:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:03:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 07:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:39:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 07:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:57:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 07:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 07:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 08:05:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 08:05:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 08:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 08:10:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 08:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 08:28:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 08:32:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 08:32:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 08:39:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 08:39:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 08:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 08:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 08:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 08:48:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 08:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 08:52:42 --> 404 Page Not Found: Adm1n/md5.asp
ERROR - 2021-12-15 08:57:10 --> 404 Page Not Found: 1111jsp/index
ERROR - 2021-12-15 08:57:10 --> 404 Page Not Found: 1111jsp/index
ERROR - 2021-12-15 08:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 09:02:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 09:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 09:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 09:22:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 09:33:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 09:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 09:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 09:51:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 09:53:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 09:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:00:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 10:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:06:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 10:06:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 10:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:12:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 10:12:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 10:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:21:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 10:21:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 10:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 10:26:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 10:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 10:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:38:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 10:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:39:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 10:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 10:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 10:56:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 10:58:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 10:58:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:00:05 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-15 11:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 11:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 11:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 11:03:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-15 11:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 11:05:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 11:05:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:07:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:07:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 11:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:08:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 11:10:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 11:18:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 11:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 11:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:22:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 11:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:23:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 11:27:11 --> 404 Page Not Found: Images/Album
ERROR - 2021-12-15 11:27:34 --> 404 Page Not Found: App/views
ERROR - 2021-12-15 11:37:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 11:38:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 11:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 11:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:04:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 12:04:43 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-15 12:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:06:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:12:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 12:13:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 12:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:31:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 12:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:32:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 12:32:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 12:34:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 12:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 12:44:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 12:44:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 12:45:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 12:50:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 12:52:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 12:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:02:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 13:03:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 13:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 13:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 13:06:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 13:06:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 13:06:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 13:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 13:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 13:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 13:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:25:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 13:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:33:19 --> 404 Page Not Found: Webadmin/lib
ERROR - 2021-12-15 13:37:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-15 13:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:40:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 13:40:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 13:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:48:33 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2021-12-15 13:53:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 13:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 13:57:56 --> 404 Page Not Found: Yjhasp/index
ERROR - 2021-12-15 14:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:20:48 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-15 14:22:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 14:22:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 14:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:31:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 14:31:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:32:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 14:32:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 14:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:32:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:34:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:37:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:38:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:38:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:40:53 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-15 14:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 14:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:42:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:46:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:47:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:47:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:48:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:48:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:48:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:49:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 14:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 14:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:15:45 --> 404 Page Not Found: Css/css.asp
ERROR - 2021-12-15 15:16:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 15:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:33:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 15:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:49:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 15:49:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 15:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 15:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 15:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:19:27 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-15 16:19:27 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-15 16:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:27:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:27:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 16:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 16:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 16:57:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 16:57:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 17:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 17:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 17:04:45 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-12-15 17:05:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 17:05:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 17:09:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 17:16:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 17:18:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 17:20:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 17:27:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:27:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 17:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:38:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 17:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 17:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:40:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:40:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:46:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 17:51:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-15 17:52:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 17:57:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 17:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:18:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 18:21:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 18:26:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 18:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 18:28:25 --> 404 Page Not Found: Layer/ueditor
ERROR - 2021-12-15 18:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 18:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 18:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:35:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 18:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:47:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 18:53:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 18:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 18:57:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 18:57:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 18:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 19:01:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 19:06:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 19:06:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 19:06:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 19:06:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 19:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 19:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 19:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 19:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:21:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 19:28:11 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-12-15 19:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:31:13 --> 404 Page Not Found: Manager/ueditor
ERROR - 2021-12-15 19:31:27 --> 404 Page Not Found: Plugins/ueditor
ERROR - 2021-12-15 19:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 19:43:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 19:47:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 19:47:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 19:49:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 19:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 19:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 20:00:59 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-15 20:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 20:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 20:05:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 20:09:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 20:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:11:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 20:21:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-15 20:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:30:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 20:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 20:40:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:42:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 20:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:44:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:44:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 20:46:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 20:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:46:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 20:47:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 20:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 20:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 20:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:05:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 21:05:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 21:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:15:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 21:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 21:16:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 21:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:29:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 21:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:31:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:32:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:32:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:32:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:32:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:33:53 --> 404 Page Not Found: Plugins/ueditor
ERROR - 2021-12-15 21:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:35:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:40:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:41:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 21:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 21:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:45:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 21:45:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 21:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 21:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:00:56 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-15 22:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:08:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 22:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:20:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 22:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:22:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:25:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:26:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:28:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 22:29:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 22:35:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 22:35:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 22:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:48:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 22:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:51:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:51:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:51:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:53:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 22:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 23:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 23:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 23:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 23:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 23:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-15 23:25:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 23:25:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-15 23:33:52 --> 404 Page Not Found: Manage/ueditor
ERROR - 2021-12-15 23:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-15 23:50:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-15 23:52:09 --> 404 Page Not Found: Robotstxt/index
