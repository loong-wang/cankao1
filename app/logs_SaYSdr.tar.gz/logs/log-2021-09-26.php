<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-26 00:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:02:44 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-26 00:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:06:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 00:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:06:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:06:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:06:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:06:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:08:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:08:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:08:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:08:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:09:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 00:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:11:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:11:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:11:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:11:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 00:11:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:11:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:13:46 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-26 00:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:23:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 00:24:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:25:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:26:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:27:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:32:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:32:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:34:47 --> 404 Page Not Found: Ewebeditor/asp
ERROR - 2021-09-26 00:34:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 00:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:45:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 00:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:47:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 00:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:50:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 00:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:54:13 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-26 00:54:24 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-26 00:54:27 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-26 00:54:28 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-26 00:54:28 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-26 00:54:32 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-26 00:54:32 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-26 00:54:33 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-09-26 00:54:34 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-26 00:54:34 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-26 00:54:35 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-26 00:54:36 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-26 00:54:37 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-26 00:54:37 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-26 00:54:38 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-26 00:54:39 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-26 00:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:56:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 00:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 00:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:01:42 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-26 01:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:05:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:24:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:25:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:29:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:30:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:31:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:33:08 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-26 01:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:41:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:42:52 --> 404 Page Not Found: City/9
ERROR - 2021-09-26 01:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:43:24 --> 404 Page Not Found: English/index
ERROR - 2021-09-26 01:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:48:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 01:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:50:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:50:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 01:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:51:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:54:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 01:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:54:28 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-26 01:54:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:54:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:54:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:54:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:54:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:54:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:01 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:01 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:13 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-26 01:55:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:21 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:21 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 01:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:58:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:58:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 01:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:58:34 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-26 01:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 01:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 02:05:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 02:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:06:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 02:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 02:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:16:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 02:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:22:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 02:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:41:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-26 02:41:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-26 02:41:38 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-26 02:41:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-26 02:41:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-26 02:41:38 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-26 02:41:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-26 02:41:39 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-26 02:41:40 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-26 02:41:40 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-26 02:41:40 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-26 02:41:40 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-26 02:41:40 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-26 02:41:40 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-26 02:41:41 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-26 02:41:41 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-26 02:41:41 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-26 02:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:48:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 02:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:54:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 02:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:57:58 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-26 02:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:59:34 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-26 02:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 02:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:21:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 03:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:31:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 03:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:36:30 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-26 03:36:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 03:36:49 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-26 03:36:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 03:37:03 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-09-26 03:37:12 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-26 03:37:16 --> 404 Page Not Found: City/10
ERROR - 2021-09-26 03:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:38:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 03:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:45:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 03:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 03:58:48 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-26 03:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-09-26 04:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:02:17 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-26 04:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:15:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 04:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:19:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 04:19:36 --> 404 Page Not Found: City/1
ERROR - 2021-09-26 04:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:22:26 --> 404 Page Not Found: City/10
ERROR - 2021-09-26 04:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:31:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 04:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:41:29 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-26 04:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:46:12 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-26 04:46:52 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-26 04:46:57 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-26 04:48:46 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-26 04:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:52:17 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-26 04:52:32 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-26 04:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:53:41 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-26 04:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:54:55 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-26 04:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:55:29 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-26 04:56:09 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-26 04:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:57:14 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-26 04:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:58:20 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-26 04:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:59:16 --> 404 Page Not Found: C/index
ERROR - 2021-09-26 04:59:17 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-09-26 04:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 04:59:48 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-26 04:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:01:10 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-26 05:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:03:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 05:05:19 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-26 05:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:08:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 05:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:10:10 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-26 05:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:15:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 05:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:15:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 05:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 05:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:22:34 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-26 05:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:23:54 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-26 05:25:02 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-26 05:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:45:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 05:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:55:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 05:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 05:58:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 05:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:07:34 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-26 06:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:09:10 --> 404 Page Not Found: City/1
ERROR - 2021-09-26 06:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:31:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 06:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:38:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 06:38:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 06:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:45:49 --> 404 Page Not Found: Env/index
ERROR - 2021-09-26 06:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:49:24 --> 404 Page Not Found: Include/fckeditor
ERROR - 2021-09-26 06:49:24 --> 404 Page Not Found: Js/fckeditor
ERROR - 2021-09-26 06:49:24 --> 404 Page Not Found: admin/Fckeditor/editor
ERROR - 2021-09-26 06:49:24 --> 404 Page Not Found: Sites/all
ERROR - 2021-09-26 06:49:24 --> 404 Page Not Found: FCKeditor/editor
ERROR - 2021-09-26 06:49:24 --> 404 Page Not Found: Sites/all
ERROR - 2021-09-26 06:49:24 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-09-26 06:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 06:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:10:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:11:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:17:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:17:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:17:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:17:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:17:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:17:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:17:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:17:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:18:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:18:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:18:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:18:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:18:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:18:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 07:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:21:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:21:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:22:16 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-26 07:22:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:22:19 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-26 07:22:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:23:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:23:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 07:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:25:48 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-26 07:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:29:48 --> 404 Page Not Found: Env/index
ERROR - 2021-09-26 07:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:31:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:32:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:38:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:39:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:40:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:40:05 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-26 07:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:41:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:42:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:51:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 07:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:53:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 07:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 07:58:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 07:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:02:13 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-26 08:03:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 08:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:10:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 08:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:18:25 --> 404 Page Not Found: City/1
ERROR - 2021-09-26 08:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:25:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 08:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 08:25:46 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-26 08:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:26:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 08:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:26:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 08:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:32:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 08:32:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 08:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:33:47 --> 404 Page Not Found: Bag2/index
ERROR - 2021-09-26 08:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-26 08:41:48 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-26 08:41:49 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-26 08:41:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-26 08:41:50 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-26 08:41:50 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-26 08:41:50 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-26 08:41:50 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-26 08:41:50 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-26 08:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 08:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 08:45:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 08:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:51:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 08:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:53:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 08:53:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 08:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 08:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:01:26 --> 404 Page Not Found: Nmaplowercheck1632618052/index
ERROR - 2021-09-26 09:01:26 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-26 09:01:26 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-26 09:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:01:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 09:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:04:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 09:04:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 09:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:12:00 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-26 09:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:13:26 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-26 09:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:13:59 --> 404 Page Not Found: English/index
ERROR - 2021-09-26 09:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:34:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 09:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:39:35 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-26 09:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:49:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 09:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:50:03 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-09-26 09:50:22 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/cityt170): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 279
ERROR - 2021-09-26 09:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:50:55 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-26 09:50:57 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-26 09:50:58 --> 404 Page Not Found: Wzrar/index
ERROR - 2021-09-26 09:50:58 --> 404 Page Not Found: Sqlrar/index
ERROR - 2021-09-26 09:51:00 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-26 09:51:01 --> 404 Page Not Found: Indexrar/index
ERROR - 2021-09-26 09:51:03 --> 404 Page Not Found: Oldrar/index
ERROR - 2021-09-26 09:51:04 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-26 09:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:51:05 --> 404 Page Not Found: Databaserar/index
ERROR - 2021-09-26 09:51:06 --> 404 Page Not Found: Uploadrar/index
ERROR - 2021-09-26 09:51:08 --> 404 Page Not Found: Websiterar/index
ERROR - 2021-09-26 09:51:09 --> 404 Page Not Found: Wangzhanrar/index
ERROR - 2021-09-26 09:51:10 --> 404 Page Not Found: Packagerar/index
ERROR - 2021-09-26 09:51:12 --> 404 Page Not Found: Testrar/index
ERROR - 2021-09-26 09:51:12 --> 404 Page Not Found: Binrar/index
ERROR - 2021-09-26 09:51:13 --> 404 Page Not Found: Ftprar/index
ERROR - 2021-09-26 09:51:14 --> 404 Page Not Found: Outputrar/index
ERROR - 2021-09-26 09:51:14 --> 404 Page Not Found: Configrar/index
ERROR - 2021-09-26 09:51:15 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDrar/index
ERROR - 2021-09-26 09:51:16 --> 404 Page Not Found: %E7%BD%91%E7%AB%99rar/index
ERROR - 2021-09-26 09:51:17 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93rar/index
ERROR - 2021-09-26 09:51:17 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDrar/index
ERROR - 2021-09-26 09:51:19 --> 404 Page Not Found: Sjkrar/index
ERROR - 2021-09-26 09:51:19 --> 404 Page Not Found: Shujukurar/index
ERROR - 2021-09-26 09:51:20 --> 404 Page Not Found: Backuprar/index
ERROR - 2021-09-26 09:51:21 --> 404 Page Not Found: Faisunziprar/index
ERROR - 2021-09-26 09:51:22 --> 404 Page Not Found: 1rar/index
ERROR - 2021-09-26 09:51:23 --> 404 Page Not Found: __zep__/js.rar
ERROR - 2021-09-26 09:51:24 --> 404 Page Not Found: Adminrar/index
ERROR - 2021-09-26 09:51:24 --> 404 Page Not Found: Dbrar/index
ERROR - 2021-09-26 09:51:25 --> 404 Page Not Found: Testrar/index
ERROR - 2021-09-26 09:51:25 --> 404 Page Not Found: 123rar/index
ERROR - 2021-09-26 09:51:27 --> 404 Page Not Found: Adminrar/index
ERROR - 2021-09-26 09:51:28 --> 404 Page Not Found: Rootrar/index
ERROR - 2021-09-26 09:51:29 --> 404 Page Not Found: Datarar/index
ERROR - 2021-09-26 09:51:29 --> 404 Page Not Found: 666rar/index
ERROR - 2021-09-26 09:51:31 --> 404 Page Not Found: 111rar/index
ERROR - 2021-09-26 09:51:32 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-09-26 09:51:33 --> 404 Page Not Found: Temprar/index
ERROR - 2021-09-26 09:51:33 --> 404 Page Not Found: Tmprar/index
ERROR - 2021-09-26 09:51:35 --> 404 Page Not Found: Bfrar/index
ERROR - 2021-09-26 09:51:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-26 09:51:37 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-26 09:51:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-26 09:51:39 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-26 09:51:39 --> 404 Page Not Found: Wwwxuanhaonetbak/index
ERROR - 2021-09-26 09:51:40 --> 404 Page Not Found: Wwwxuanhaonetbak/index
ERROR - 2021-09-26 09:51:41 --> 404 Page Not Found: Wzbak/index
ERROR - 2021-09-26 09:51:42 --> 404 Page Not Found: Sqlbak/index
ERROR - 2021-09-26 09:51:43 --> 404 Page Not Found: Wwwrootbak/index
ERROR - 2021-09-26 09:51:44 --> 404 Page Not Found: Indexbak/index
ERROR - 2021-09-26 09:51:44 --> 404 Page Not Found: Oldbak/index
ERROR - 2021-09-26 09:51:45 --> 404 Page Not Found: Webbak/index
ERROR - 2021-09-26 09:51:46 --> 404 Page Not Found: Databasebak/index
ERROR - 2021-09-26 09:51:48 --> 404 Page Not Found: Uploadbak/index
ERROR - 2021-09-26 09:51:48 --> 404 Page Not Found: Websitebak/index
ERROR - 2021-09-26 09:51:49 --> 404 Page Not Found: Wangzhanbak/index
ERROR - 2021-09-26 09:51:50 --> 404 Page Not Found: Packagebak/index
ERROR - 2021-09-26 09:51:53 --> 404 Page Not Found: Testbak/index
ERROR - 2021-09-26 09:51:54 --> 404 Page Not Found: Binbak/index
ERROR - 2021-09-26 09:51:55 --> 404 Page Not Found: Ftpbak/index
ERROR - 2021-09-26 09:51:56 --> 404 Page Not Found: Outputbak/index
ERROR - 2021-09-26 09:51:58 --> 404 Page Not Found: Configbak/index
ERROR - 2021-09-26 09:51:59 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDbak/index
ERROR - 2021-09-26 09:52:00 --> 404 Page Not Found: %E7%BD%91%E7%AB%99bak/index
ERROR - 2021-09-26 09:52:00 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93bak/index
ERROR - 2021-09-26 09:52:01 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDbak/index
ERROR - 2021-09-26 09:52:02 --> 404 Page Not Found: Sjkbak/index
ERROR - 2021-09-26 09:52:03 --> 404 Page Not Found: Shujukubak/index
ERROR - 2021-09-26 09:52:03 --> 404 Page Not Found: Backupbak/index
ERROR - 2021-09-26 09:52:04 --> 404 Page Not Found: Faisunzipbak/index
ERROR - 2021-09-26 09:52:05 --> 404 Page Not Found: 1bak/index
ERROR - 2021-09-26 09:52:05 --> 404 Page Not Found: __zep__/js.bak
ERROR - 2021-09-26 09:52:06 --> 404 Page Not Found: Adminbak/index
ERROR - 2021-09-26 09:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:52:07 --> 404 Page Not Found: Dbbak/index
ERROR - 2021-09-26 09:52:07 --> 404 Page Not Found: Testbak/index
ERROR - 2021-09-26 09:52:08 --> 404 Page Not Found: 123bak/index
ERROR - 2021-09-26 09:52:08 --> 404 Page Not Found: Adminbak/index
ERROR - 2021-09-26 09:52:09 --> 404 Page Not Found: Rootbak/index
ERROR - 2021-09-26 09:52:10 --> 404 Page Not Found: Databak/index
ERROR - 2021-09-26 09:52:11 --> 404 Page Not Found: 666bak/index
ERROR - 2021-09-26 09:52:11 --> 404 Page Not Found: 111bak/index
ERROR - 2021-09-26 09:52:12 --> 404 Page Not Found: Beifenbak/index
ERROR - 2021-09-26 09:52:12 --> 404 Page Not Found: Tempbak/index
ERROR - 2021-09-26 09:52:13 --> 404 Page Not Found: Tmpbak/index
ERROR - 2021-09-26 09:52:13 --> 404 Page Not Found: Bfbak/index
ERROR - 2021-09-26 09:52:14 --> 404 Page Not Found: Xuanhaonetbak/index
ERROR - 2021-09-26 09:52:14 --> 404 Page Not Found: Xuanhaonetbak/index
ERROR - 2021-09-26 09:52:15 --> 404 Page Not Found: Wwwbak/index
ERROR - 2021-09-26 09:52:16 --> 404 Page Not Found: Xuanhaobak/index
ERROR - 2021-09-26 09:52:16 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-26 09:52:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-26 09:52:18 --> 404 Page Not Found: Wzzip/index
ERROR - 2021-09-26 09:52:19 --> 404 Page Not Found: Sqlzip/index
ERROR - 2021-09-26 09:52:20 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-26 09:52:22 --> 404 Page Not Found: Indexzip/index
ERROR - 2021-09-26 09:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:52:23 --> 404 Page Not Found: Oldzip/index
ERROR - 2021-09-26 09:52:25 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-26 09:52:26 --> 404 Page Not Found: Databasezip/index
ERROR - 2021-09-26 09:52:26 --> 404 Page Not Found: Uploadzip/index
ERROR - 2021-09-26 09:52:26 --> 404 Page Not Found: Websitezip/index
ERROR - 2021-09-26 09:52:29 --> 404 Page Not Found: Wangzhanzip/index
ERROR - 2021-09-26 09:52:30 --> 404 Page Not Found: Packagezip/index
ERROR - 2021-09-26 09:52:30 --> 404 Page Not Found: Testzip/index
ERROR - 2021-09-26 09:52:32 --> 404 Page Not Found: Binzip/index
ERROR - 2021-09-26 09:52:33 --> 404 Page Not Found: Ftpzip/index
ERROR - 2021-09-26 09:52:35 --> 404 Page Not Found: Outputzip/index
ERROR - 2021-09-26 09:52:38 --> 404 Page Not Found: Configzip/index
ERROR - 2021-09-26 09:52:39 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDzip/index
ERROR - 2021-09-26 09:52:40 --> 404 Page Not Found: %E7%BD%91%E7%AB%99zip/index
ERROR - 2021-09-26 09:52:41 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93zip/index
ERROR - 2021-09-26 09:52:42 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDzip/index
ERROR - 2021-09-26 09:52:43 --> 404 Page Not Found: Sjkzip/index
ERROR - 2021-09-26 09:52:44 --> 404 Page Not Found: Shujukuzip/index
ERROR - 2021-09-26 09:52:45 --> 404 Page Not Found: Backupzip/index
ERROR - 2021-09-26 09:52:47 --> 404 Page Not Found: Faisunzipzip/index
ERROR - 2021-09-26 09:52:47 --> 404 Page Not Found: 1zip/index
ERROR - 2021-09-26 09:52:48 --> 404 Page Not Found: __zep__/js.zip
ERROR - 2021-09-26 09:52:49 --> 404 Page Not Found: Adminzip/index
ERROR - 2021-09-26 09:52:50 --> 404 Page Not Found: Dbzip/index
ERROR - 2021-09-26 09:52:51 --> 404 Page Not Found: Testzip/index
ERROR - 2021-09-26 09:52:51 --> 404 Page Not Found: 123zip/index
ERROR - 2021-09-26 09:52:52 --> 404 Page Not Found: Adminzip/index
ERROR - 2021-09-26 09:52:52 --> 404 Page Not Found: Rootzip/index
ERROR - 2021-09-26 09:52:53 --> 404 Page Not Found: Datazip/index
ERROR - 2021-09-26 09:52:55 --> 404 Page Not Found: 666zip/index
ERROR - 2021-09-26 09:52:56 --> 404 Page Not Found: 111zip/index
ERROR - 2021-09-26 09:52:57 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-09-26 09:52:57 --> 404 Page Not Found: Tempzip/index
ERROR - 2021-09-26 09:52:58 --> 404 Page Not Found: Tmpzip/index
ERROR - 2021-09-26 09:52:58 --> 404 Page Not Found: Bfzip/index
ERROR - 2021-09-26 09:52:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-26 09:53:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-26 09:53:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-26 09:53:02 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-26 09:53:04 --> 404 Page Not Found: Wwwxuanhaonetgz/index
ERROR - 2021-09-26 09:53:05 --> 404 Page Not Found: Wwwxuanhaonetgz/index
ERROR - 2021-09-26 09:53:05 --> 404 Page Not Found: Wzgz/index
ERROR - 2021-09-26 09:53:06 --> 404 Page Not Found: Sqlgz/index
ERROR - 2021-09-26 09:53:07 --> 404 Page Not Found: Wwwrootgz/index
ERROR - 2021-09-26 09:53:08 --> 404 Page Not Found: Indexgz/index
ERROR - 2021-09-26 09:53:09 --> 404 Page Not Found: Oldgz/index
ERROR - 2021-09-26 09:53:10 --> 404 Page Not Found: Webgz/index
ERROR - 2021-09-26 09:53:10 --> 404 Page Not Found: Databasegz/index
ERROR - 2021-09-26 09:53:11 --> 404 Page Not Found: Uploadgz/index
ERROR - 2021-09-26 09:53:13 --> 404 Page Not Found: Websitegz/index
ERROR - 2021-09-26 09:53:14 --> 404 Page Not Found: Wangzhangz/index
ERROR - 2021-09-26 09:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:53:14 --> 404 Page Not Found: Packagegz/index
ERROR - 2021-09-26 09:53:15 --> 404 Page Not Found: Testgz/index
ERROR - 2021-09-26 09:53:15 --> 404 Page Not Found: Bingz/index
ERROR - 2021-09-26 09:53:16 --> 404 Page Not Found: Ftpgz/index
ERROR - 2021-09-26 09:53:17 --> 404 Page Not Found: Outputgz/index
ERROR - 2021-09-26 09:53:18 --> 404 Page Not Found: Configgz/index
ERROR - 2021-09-26 09:53:18 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDgz/index
ERROR - 2021-09-26 09:53:19 --> 404 Page Not Found: %E7%BD%91%E7%AB%99gz/index
ERROR - 2021-09-26 09:53:20 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93gz/index
ERROR - 2021-09-26 09:53:20 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDgz/index
ERROR - 2021-09-26 09:53:21 --> 404 Page Not Found: Sjkgz/index
ERROR - 2021-09-26 09:53:22 --> 404 Page Not Found: Shujukugz/index
ERROR - 2021-09-26 09:53:23 --> 404 Page Not Found: Backupgz/index
ERROR - 2021-09-26 09:53:24 --> 404 Page Not Found: Faisunzipgz/index
ERROR - 2021-09-26 09:53:25 --> 404 Page Not Found: 1gz/index
ERROR - 2021-09-26 09:53:25 --> 404 Page Not Found: __zep__/js.gz
ERROR - 2021-09-26 09:53:26 --> 404 Page Not Found: Admingz/index
ERROR - 2021-09-26 09:53:27 --> 404 Page Not Found: Dbgz/index
ERROR - 2021-09-26 09:53:28 --> 404 Page Not Found: Testgz/index
ERROR - 2021-09-26 09:53:29 --> 404 Page Not Found: 123gz/index
ERROR - 2021-09-26 09:53:30 --> 404 Page Not Found: Admingz/index
ERROR - 2021-09-26 09:53:30 --> 404 Page Not Found: Rootgz/index
ERROR - 2021-09-26 09:53:31 --> 404 Page Not Found: Datagz/index
ERROR - 2021-09-26 09:53:31 --> 404 Page Not Found: 666gz/index
ERROR - 2021-09-26 09:53:32 --> 404 Page Not Found: 111gz/index
ERROR - 2021-09-26 09:53:34 --> 404 Page Not Found: Beifengz/index
ERROR - 2021-09-26 09:53:35 --> 404 Page Not Found: Tempgz/index
ERROR - 2021-09-26 09:53:35 --> 404 Page Not Found: Tmpgz/index
ERROR - 2021-09-26 09:53:36 --> 404 Page Not Found: Bfgz/index
ERROR - 2021-09-26 09:53:37 --> 404 Page Not Found: Xuanhaonetgz/index
ERROR - 2021-09-26 09:53:39 --> 404 Page Not Found: Xuanhaonetgz/index
ERROR - 2021-09-26 09:53:40 --> 404 Page Not Found: Wwwgz/index
ERROR - 2021-09-26 09:53:41 --> 404 Page Not Found: Xuanhaogz/index
ERROR - 2021-09-26 09:53:42 --> 404 Page Not Found: Wwwxuanhaonetsqlgz/index
ERROR - 2021-09-26 09:53:43 --> 404 Page Not Found: Wwwxuanhaonetsqlgz/index
ERROR - 2021-09-26 09:53:44 --> 404 Page Not Found: Wzsqlgz/index
ERROR - 2021-09-26 09:53:44 --> 404 Page Not Found: Sqlsqlgz/index
ERROR - 2021-09-26 09:53:45 --> 404 Page Not Found: Wwwrootsqlgz/index
ERROR - 2021-09-26 09:53:46 --> 404 Page Not Found: Indexsqlgz/index
ERROR - 2021-09-26 09:53:46 --> 404 Page Not Found: Oldsqlgz/index
ERROR - 2021-09-26 09:53:47 --> 404 Page Not Found: Websqlgz/index
ERROR - 2021-09-26 09:53:48 --> 404 Page Not Found: Databasesqlgz/index
ERROR - 2021-09-26 09:53:48 --> 404 Page Not Found: Uploadsqlgz/index
ERROR - 2021-09-26 09:53:50 --> 404 Page Not Found: Websitesqlgz/index
ERROR - 2021-09-26 09:53:51 --> 404 Page Not Found: Wangzhansqlgz/index
ERROR - 2021-09-26 09:53:52 --> 404 Page Not Found: Packagesqlgz/index
ERROR - 2021-09-26 09:53:52 --> 404 Page Not Found: Testsqlgz/index
ERROR - 2021-09-26 09:53:53 --> 404 Page Not Found: Binsqlgz/index
ERROR - 2021-09-26 09:53:53 --> 404 Page Not Found: Ftpsqlgz/index
ERROR - 2021-09-26 09:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:53:54 --> 404 Page Not Found: Outputsqlgz/index
ERROR - 2021-09-26 09:53:55 --> 404 Page Not Found: Configsqlgz/index
ERROR - 2021-09-26 09:53:55 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDsqlgz/index
ERROR - 2021-09-26 09:53:56 --> 404 Page Not Found: %E7%BD%91%E7%AB%99sqlgz/index
ERROR - 2021-09-26 09:53:56 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93sqlgz/index
ERROR - 2021-09-26 09:53:57 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDsqlgz/index
ERROR - 2021-09-26 09:53:58 --> 404 Page Not Found: Sjksqlgz/index
ERROR - 2021-09-26 09:53:58 --> 404 Page Not Found: Shujukusqlgz/index
ERROR - 2021-09-26 09:53:59 --> 404 Page Not Found: Backupsqlgz/index
ERROR - 2021-09-26 09:54:00 --> 404 Page Not Found: Faisunzipsqlgz/index
ERROR - 2021-09-26 09:54:03 --> 404 Page Not Found: 1sqlgz/index
ERROR - 2021-09-26 09:54:04 --> 404 Page Not Found: __zep__/js.sql.gz
ERROR - 2021-09-26 09:54:05 --> 404 Page Not Found: Adminsqlgz/index
ERROR - 2021-09-26 09:54:06 --> 404 Page Not Found: Dbsqlgz/index
ERROR - 2021-09-26 09:54:06 --> 404 Page Not Found: Testsqlgz/index
ERROR - 2021-09-26 09:54:10 --> 404 Page Not Found: 123sqlgz/index
ERROR - 2021-09-26 09:54:11 --> 404 Page Not Found: Adminsqlgz/index
ERROR - 2021-09-26 09:54:12 --> 404 Page Not Found: Rootsqlgz/index
ERROR - 2021-09-26 09:54:12 --> 404 Page Not Found: Datasqlgz/index
ERROR - 2021-09-26 09:54:13 --> 404 Page Not Found: 666sqlgz/index
ERROR - 2021-09-26 09:54:13 --> 404 Page Not Found: 111sqlgz/index
ERROR - 2021-09-26 09:54:14 --> 404 Page Not Found: Beifensqlgz/index
ERROR - 2021-09-26 09:54:15 --> 404 Page Not Found: Tempsqlgz/index
ERROR - 2021-09-26 09:54:17 --> 404 Page Not Found: Tmpsqlgz/index
ERROR - 2021-09-26 09:54:18 --> 404 Page Not Found: Bfsqlgz/index
ERROR - 2021-09-26 09:54:19 --> 404 Page Not Found: Xuanhaonetsqlgz/index
ERROR - 2021-09-26 09:54:21 --> 404 Page Not Found: Xuanhaonetsqlgz/index
ERROR - 2021-09-26 09:54:22 --> 404 Page Not Found: Wwwsqlgz/index
ERROR - 2021-09-26 09:54:22 --> 404 Page Not Found: Xuanhaosqlgz/index
ERROR - 2021-09-26 09:54:24 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-26 09:54:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-26 09:54:26 --> 404 Page Not Found: Wztargz/index
ERROR - 2021-09-26 09:54:26 --> 404 Page Not Found: Sqltargz/index
ERROR - 2021-09-26 09:54:27 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-26 09:54:28 --> 404 Page Not Found: Indextargz/index
ERROR - 2021-09-26 09:54:29 --> 404 Page Not Found: Oldtargz/index
ERROR - 2021-09-26 09:54:29 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-26 09:54:30 --> 404 Page Not Found: Databasetargz/index
ERROR - 2021-09-26 09:54:31 --> 404 Page Not Found: Uploadtargz/index
ERROR - 2021-09-26 09:54:32 --> 404 Page Not Found: Websitetargz/index
ERROR - 2021-09-26 09:54:32 --> 404 Page Not Found: Wangzhantargz/index
ERROR - 2021-09-26 09:54:34 --> 404 Page Not Found: Packagetargz/index
ERROR - 2021-09-26 09:54:34 --> 404 Page Not Found: Testtargz/index
ERROR - 2021-09-26 09:54:35 --> 404 Page Not Found: Bintargz/index
ERROR - 2021-09-26 09:54:36 --> 404 Page Not Found: Ftptargz/index
ERROR - 2021-09-26 09:54:38 --> 404 Page Not Found: Outputtargz/index
ERROR - 2021-09-26 09:54:38 --> 404 Page Not Found: Configtargz/index
ERROR - 2021-09-26 09:54:40 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDtargz/index
ERROR - 2021-09-26 09:54:41 --> 404 Page Not Found: %E7%BD%91%E7%AB%99targz/index
ERROR - 2021-09-26 09:54:41 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93targz/index
ERROR - 2021-09-26 09:54:42 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDtargz/index
ERROR - 2021-09-26 09:54:43 --> 404 Page Not Found: Sjktargz/index
ERROR - 2021-09-26 09:54:43 --> 404 Page Not Found: Shujukutargz/index
ERROR - 2021-09-26 09:54:44 --> 404 Page Not Found: Backuptargz/index
ERROR - 2021-09-26 09:54:44 --> 404 Page Not Found: Faisunziptargz/index
ERROR - 2021-09-26 09:54:45 --> 404 Page Not Found: 1targz/index
ERROR - 2021-09-26 09:54:45 --> 404 Page Not Found: __zep__/js.tar.gz
ERROR - 2021-09-26 09:54:46 --> 404 Page Not Found: Admintargz/index
ERROR - 2021-09-26 09:54:47 --> 404 Page Not Found: Dbtargz/index
ERROR - 2021-09-26 09:54:47 --> 404 Page Not Found: Testtargz/index
ERROR - 2021-09-26 09:54:48 --> 404 Page Not Found: 123targz/index
ERROR - 2021-09-26 09:54:49 --> 404 Page Not Found: Admintargz/index
ERROR - 2021-09-26 09:54:51 --> 404 Page Not Found: Roottargz/index
ERROR - 2021-09-26 09:54:51 --> 404 Page Not Found: Datatargz/index
ERROR - 2021-09-26 09:54:52 --> 404 Page Not Found: 666targz/index
ERROR - 2021-09-26 09:54:53 --> 404 Page Not Found: 111targz/index
ERROR - 2021-09-26 09:54:55 --> 404 Page Not Found: Beifentargz/index
ERROR - 2021-09-26 09:54:56 --> 404 Page Not Found: Temptargz/index
ERROR - 2021-09-26 09:54:57 --> 404 Page Not Found: Tmptargz/index
ERROR - 2021-09-26 09:54:57 --> 404 Page Not Found: Bftargz/index
ERROR - 2021-09-26 09:54:58 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-26 09:54:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-26 09:55:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-26 09:55:00 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-26 09:55:01 --> 404 Page Not Found: Wwwxuanhaonetsql/index
ERROR - 2021-09-26 09:55:02 --> 404 Page Not Found: Wwwxuanhaonetsql/index
ERROR - 2021-09-26 09:55:02 --> 404 Page Not Found: Wzsql/index
ERROR - 2021-09-26 09:55:03 --> 404 Page Not Found: Sqlsql/index
ERROR - 2021-09-26 09:55:04 --> 404 Page Not Found: Wwwrootsql/index
ERROR - 2021-09-26 09:55:06 --> 404 Page Not Found: Indexsql/index
ERROR - 2021-09-26 09:55:07 --> 404 Page Not Found: Oldsql/index
ERROR - 2021-09-26 09:55:07 --> 404 Page Not Found: Websql/index
ERROR - 2021-09-26 09:55:08 --> 404 Page Not Found: Databasesql/index
ERROR - 2021-09-26 09:55:09 --> 404 Page Not Found: Uploadsql/index
ERROR - 2021-09-26 09:55:09 --> 404 Page Not Found: Websitesql/index
ERROR - 2021-09-26 09:55:10 --> 404 Page Not Found: Wangzhansql/index
ERROR - 2021-09-26 09:55:11 --> 404 Page Not Found: Packagesql/index
ERROR - 2021-09-26 09:55:12 --> 404 Page Not Found: Testsql/index
ERROR - 2021-09-26 09:55:13 --> 404 Page Not Found: Binsql/index
ERROR - 2021-09-26 09:55:13 --> 404 Page Not Found: Ftpsql/index
ERROR - 2021-09-26 09:55:14 --> 404 Page Not Found: Outputsql/index
ERROR - 2021-09-26 09:55:15 --> 404 Page Not Found: Configsql/index
ERROR - 2021-09-26 09:55:16 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDsql/index
ERROR - 2021-09-26 09:55:16 --> 404 Page Not Found: %E7%BD%91%E7%AB%99sql/index
ERROR - 2021-09-26 09:55:17 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93sql/index
ERROR - 2021-09-26 09:55:17 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDsql/index
ERROR - 2021-09-26 09:55:18 --> 404 Page Not Found: Sjksql/index
ERROR - 2021-09-26 09:55:19 --> 404 Page Not Found: Shujukusql/index
ERROR - 2021-09-26 09:55:19 --> 404 Page Not Found: Backupsql/index
ERROR - 2021-09-26 09:55:20 --> 404 Page Not Found: Faisunzipsql/index
ERROR - 2021-09-26 09:55:21 --> 404 Page Not Found: 1sql/index
ERROR - 2021-09-26 09:55:21 --> 404 Page Not Found: __zep__/js.sql
ERROR - 2021-09-26 09:55:22 --> 404 Page Not Found: Adminsql/index
ERROR - 2021-09-26 09:55:22 --> 404 Page Not Found: Dbsql/index
ERROR - 2021-09-26 09:55:23 --> 404 Page Not Found: Testsql/index
ERROR - 2021-09-26 09:55:23 --> 404 Page Not Found: 123sql/index
ERROR - 2021-09-26 09:55:24 --> 404 Page Not Found: Adminsql/index
ERROR - 2021-09-26 09:55:25 --> 404 Page Not Found: Rootsql/index
ERROR - 2021-09-26 09:55:25 --> 404 Page Not Found: Datasql/index
ERROR - 2021-09-26 09:55:26 --> 404 Page Not Found: 666sql/index
ERROR - 2021-09-26 09:55:26 --> 404 Page Not Found: 111sql/index
ERROR - 2021-09-26 09:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:55:27 --> 404 Page Not Found: Beifensql/index
ERROR - 2021-09-26 09:55:28 --> 404 Page Not Found: Tempsql/index
ERROR - 2021-09-26 09:55:29 --> 404 Page Not Found: Tmpsql/index
ERROR - 2021-09-26 09:55:29 --> 404 Page Not Found: Bfsql/index
ERROR - 2021-09-26 09:55:30 --> 404 Page Not Found: Xuanhaonetsql/index
ERROR - 2021-09-26 09:55:32 --> 404 Page Not Found: Xuanhaonetsql/index
ERROR - 2021-09-26 09:55:32 --> 404 Page Not Found: Wwwsql/index
ERROR - 2021-09-26 09:55:33 --> 404 Page Not Found: Xuanhaosql/index
ERROR - 2021-09-26 09:55:33 --> 404 Page Not Found: Wwwxuanhaonetmdb/index
ERROR - 2021-09-26 09:55:34 --> 404 Page Not Found: Wwwxuanhaonetmdb/index
ERROR - 2021-09-26 09:55:36 --> 404 Page Not Found: Wzmdb/index
ERROR - 2021-09-26 09:55:36 --> 404 Page Not Found: Sqlmdb/index
ERROR - 2021-09-26 09:55:37 --> 404 Page Not Found: Wwwrootmdb/index
ERROR - 2021-09-26 09:55:38 --> 404 Page Not Found: Indexmdb/index
ERROR - 2021-09-26 09:55:38 --> 404 Page Not Found: Oldmdb/index
ERROR - 2021-09-26 09:55:39 --> 404 Page Not Found: Webmdb/index
ERROR - 2021-09-26 09:55:41 --> 404 Page Not Found: Databasemdb/index
ERROR - 2021-09-26 09:55:41 --> 404 Page Not Found: Uploadmdb/index
ERROR - 2021-09-26 09:55:43 --> 404 Page Not Found: Websitemdb/index
ERROR - 2021-09-26 09:55:44 --> 404 Page Not Found: Wangzhanmdb/index
ERROR - 2021-09-26 09:55:46 --> 404 Page Not Found: Packagemdb/index
ERROR - 2021-09-26 09:55:46 --> 404 Page Not Found: Testmdb/index
ERROR - 2021-09-26 09:55:47 --> 404 Page Not Found: Binmdb/index
ERROR - 2021-09-26 09:55:48 --> 404 Page Not Found: Ftpmdb/index
ERROR - 2021-09-26 09:55:48 --> 404 Page Not Found: Outputmdb/index
ERROR - 2021-09-26 09:55:51 --> 404 Page Not Found: Configmdb/index
ERROR - 2021-09-26 09:55:52 --> 404 Page Not Found: %E7%BD%91%E7%AB%99%E5%A4%87%E4%BB%BDmdb/index
ERROR - 2021-09-26 09:55:52 --> 404 Page Not Found: %E7%BD%91%E7%AB%99mdb/index
ERROR - 2021-09-26 09:55:53 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93mdb/index
ERROR - 2021-09-26 09:55:54 --> 404 Page Not Found: %E6%95%B0%E6%8D%AE%E5%BA%93%E5%A4%87%E4%BB%BDmdb/index
ERROR - 2021-09-26 09:55:54 --> 404 Page Not Found: Sjkmdb/index
ERROR - 2021-09-26 09:55:54 --> 404 Page Not Found: Shujukumdb/index
ERROR - 2021-09-26 09:55:55 --> 404 Page Not Found: Backupmdb/index
ERROR - 2021-09-26 09:55:56 --> 404 Page Not Found: Faisunzipmdb/index
ERROR - 2021-09-26 09:55:57 --> 404 Page Not Found: 1mdb/index
ERROR - 2021-09-26 09:56:02 --> 404 Page Not Found: __zep__/js.mdb
ERROR - 2021-09-26 09:56:03 --> 404 Page Not Found: Adminmdb/index
ERROR - 2021-09-26 09:56:05 --> 404 Page Not Found: Dbmdb/index
ERROR - 2021-09-26 09:56:05 --> 404 Page Not Found: Testmdb/index
ERROR - 2021-09-26 09:56:06 --> 404 Page Not Found: 123mdb/index
ERROR - 2021-09-26 09:56:07 --> 404 Page Not Found: Adminmdb/index
ERROR - 2021-09-26 09:56:08 --> 404 Page Not Found: Rootmdb/index
ERROR - 2021-09-26 09:56:08 --> 404 Page Not Found: Datamdb/index
ERROR - 2021-09-26 09:56:09 --> 404 Page Not Found: 666mdb/index
ERROR - 2021-09-26 09:56:09 --> 404 Page Not Found: 111mdb/index
ERROR - 2021-09-26 09:56:10 --> 404 Page Not Found: Beifenmdb/index
ERROR - 2021-09-26 09:56:11 --> 404 Page Not Found: Tempmdb/index
ERROR - 2021-09-26 09:56:12 --> 404 Page Not Found: Tmpmdb/index
ERROR - 2021-09-26 09:56:13 --> 404 Page Not Found: Bfmdb/index
ERROR - 2021-09-26 09:56:14 --> 404 Page Not Found: Xuanhaonetmdb/index
ERROR - 2021-09-26 09:56:16 --> 404 Page Not Found: Xuanhaonetmdb/index
ERROR - 2021-09-26 09:56:16 --> 404 Page Not Found: Wwwmdb/index
ERROR - 2021-09-26 09:56:17 --> 404 Page Not Found: Xuanhaomdb/index
ERROR - 2021-09-26 09:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 09:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:00:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 10:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:10:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:10:37 --> 404 Page Not Found: Ewebeditor/asp
ERROR - 2021-09-26 10:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:15:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:15:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:15:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:16:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:16:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:18:16 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-26 10:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:18:37 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-26 10:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:18:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 10:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:20:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:30:06 --> 404 Page Not Found: City/index
ERROR - 2021-09-26 10:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:33:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:33:24 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-26 10:33:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 10:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:46:12 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-26 10:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:51:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 10:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:59:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 10:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 10:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:01:27 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-26 11:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:05:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:05:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:06:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:06:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:06:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 11:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:07:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:08:28 --> 404 Page Not Found: Order/index
ERROR - 2021-09-26 11:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:15:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 11:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:21:36 --> 404 Page Not Found: Index/login
ERROR - 2021-09-26 11:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:35:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:37:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 11:38:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 11:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:46:54 --> 404 Page Not Found: Web/index
ERROR - 2021-09-26 11:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:50:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 11:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:52:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 11:53:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 11:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 11:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:01:25 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-26 12:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:09:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 12:09:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:09:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:10:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:11:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:11:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:01 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:01 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:31 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:31 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:58 --> 404 Page Not Found: English/index
ERROR - 2021-09-26 12:12:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:12:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:33 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-09-26 12:13:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:36 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:36 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:13:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:13 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-26 12:14:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:14:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:14:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:14:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 12:15:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 12:15:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:31 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:31 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:36 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:36 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:15:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:16:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:16:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:16:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 12:17:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:20 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-09-26 12:17:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 12:17:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:17:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 12:19:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:19:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:20:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:20:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:21:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:21:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:22:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:22:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:23:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:23:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:24:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:24:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:25:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:25:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:26:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:26:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:27:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:27:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:28:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:28:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:29:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:29:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:30:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:30:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:30:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 12:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:31:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:31:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:32:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:32:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:33:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:33:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:34:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:34:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-26 12:34:40 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-26 12:35:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:35:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:35:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 12:36:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:36:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:37:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 12:37:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:37:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:37:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:37:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 12:37:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:37:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:38:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:38:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:39:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:39:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:39:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 12:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:39:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:39:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:40:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:40:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:41:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:41:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:42:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:42:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:43:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:43:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:31 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:31 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:44:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:01 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:01 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:45:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:21 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:21 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:46:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:46:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:46:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:14 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-26 12:47:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:47:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:47:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:47:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:21 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:21 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:48:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:49:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:49:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:49:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:49:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:50:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:50:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:50:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:50:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:51:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:51:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:51:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:51:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:52:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:52:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:52:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:52:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:53:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:53:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:53:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:53:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:54:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:54:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:54:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:54:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:55:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:55:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:55:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:55:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:55:42 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-26 12:56:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:56:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:56:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:56:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:56:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 12:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:56:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 12:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:57:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:57:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:57:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:57:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:58:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:58:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:58:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:58:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:59:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:59:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:59:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:59:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 12:59:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 12:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 12:59:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 12:59:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 13:00:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 13:00:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:00:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 13:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:01:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:49 --> 404 Page Not Found: Page/images
ERROR - 2021-09-26 13:01:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:01:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 13:02:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:02:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:03:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:03:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:56 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-26 13:03:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:03:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:04:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 13:04:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 13:04:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:04:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:05:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:05:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:05:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:05:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:05:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:05:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:05:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 13:06:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:06:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:06:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:06:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:07:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:07:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:07:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:07:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:08:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:08:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:08:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:08:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:09:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:09:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:09:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:09:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:10:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:10:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:10:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:10:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:11:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:11:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:11:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:11:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 13:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:13:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 13:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: UPDATE `fox_question` SET `q_llcs` = 4
WHERE `id` = '125086'
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): MySQL server has gone away /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Error reading result set's header /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: MySQL server has gone away - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = 1
AND `hao_lock` <=0
AND `hao_type` = 1
AND  `hao_title` LIKE '170%' ESCAPE '!'
AND (`hao_jiage` >= 77 and `hao_jiage` <= 385)
AND (substr(substr(hao_title,-6),1,1)=substr(substr(hao_title,-5),1,1) && substr(substr(hao_title,-5),1,1)=substr(substr(hao_title,-4),1,1) && substr(substr(hao_title,-3),1,1)=substr(substr(hao_title,-2),1,1) && substr(substr(hao_title,-2),1,1)=substr(hao_title,-1) && substr(substr(hao_title,-4),1,1)!=substr(substr(hao_title,-3),1,1))
AND (`hao_heyue` is null or LENGTH(hao_heyue) < 2)
AND (MOD(RIGHT(hao_title, 4)+1-1,81) = 15)
AND `hao_dig` = '3'
 LIMIT 60
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
AND `q_reuserid` >0
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = '1'
AND `hao_lock` <=0
AND `hao_type` = 1
AND  `hao_title` LIKE '131%' ESCAPE '!'
AND (`hao_jiage` >= 84 and `hao_jiage` <= 417)
AND `hao_title` not like "%7%"
AND (MOD(RIGHT(hao_title, 4)+1-1,81) = 8)
 LIMIT 60
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
AND `q_reuserid` >0
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = 1
AND `hao_lock` <=0
AND `hao_type` = 1
AND (`hao_jiage` >= 77 and `hao_jiage` <= 385)
AND (substr(substr(hao_title,-4),1,2)=substr(hao_title,-2) && substr(substr(hao_title,-2),1,1)!=substr(hao_title,-1))
AND (`hao_title` not like "%4%" and `hao_title` not like "%7%")
 LIMIT 60
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
AND `q_reuserid` >0
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
AND `q_reuserid` >0
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
AND `q_reuserid` >0
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
AND `q_reuserid` >0
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = 1
AND `hao_lock` <=0
AND `hao_type` = 1
AND  `hao_title` LIKE '170%' ESCAPE '!'
AND (`hao_jiage` >= 77 and `hao_jiage` <= 385)
AND ((length(hao_title)-length(replace(hao_title,'3',''))) > 4)
AND (`hao_heyue` is null or LENGTH(hao_heyue) < 2)
AND (MOD(RIGHT(hao_title, 4)+1-1,81) = 16)
AND `hao_dig` = '3'
 LIMIT 60
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = 1
AND `hao_type` = 1
AND `hao_lock` <=0
ORDER BY `hao_time` DESC
 LIMIT 24
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 974
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `fox_question`
WHERE `q_type` = 1
AND `q_city` = 1
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/system/database/DB_query_builder.php 1391
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = 1
AND `hao_lock` <=0
AND `hao_type` = 1
AND  `hao_title` LIKE '185%' ESCAPE '!'
AND (`hao_jiage` >= 77 and `hao_jiage` <= 385)
AND (substr(substr(hao_title,-6),1,1)=substr(substr(hao_title,-5),1,1) && substr(substr(hao_title,-5),1,1)=substr(substr(hao_title,-4),1,1) && substr(substr(hao_title,-3),1,1)=substr(substr(hao_title,-2),1,1) && substr(substr(hao_title,-2),1,1)=substr(hao_title,-1) && substr(substr(hao_title,-4),1,1)!=substr(substr(hao_title,-3),1,1))
AND (`hao_heyue` is null or LENGTH(hao_heyue) < 2)
AND (MOD(RIGHT(hao_title, 4)+1-1,81) = 16)
AND `hao_dig` = '3'
 LIMIT 60
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:28 --> Severity: Warning --> mysql_query(): Unable to save result set /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:28 --> Query error: Sort aborted: Query execution was interrupted - Invalid query: SELECT *
FROM `fox_question`
WHERE `q_city` = '1'
ORDER BY `q_time` DESC
 LIMIT 15
ERROR - 2021-09-26 13:14:28 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Page_m.php 35
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:48 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:48 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:48 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:49 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:49 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:49 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:49 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:49 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:49 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): [2002] Connection refused (trying to connect via tcp://127.0.0.1:3306) /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_connect(): Connection refused /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-26 13:14:49 --> Unable to select database: xuanhao_net
ERROR - 2021-09-26 13:14:49 --> Unable to connect to the database
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-26 13:14:49 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-26 13:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:19:20 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-26 13:19:21 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-26 13:19:23 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-26 13:19:23 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-26 13:19:24 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-26 13:19:25 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-26 13:19:26 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-09-26 13:19:27 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-26 13:19:33 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-26 13:19:34 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-26 13:19:34 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-09-26 13:19:35 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-26 13:19:35 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-26 13:19:36 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-26 13:19:36 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-26 13:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:20:46 --> 404 Page Not Found: Ewebeditor/asp
ERROR - 2021-09-26 13:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:22:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 13:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:25:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 13:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Openam/ccversion
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Api/settings
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Api/settings
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Sys/search
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Xxlfhtxt/index
ERROR - 2021-09-26 13:26:30 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Xxlfhtxt/index
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: WebReport/ReportServer
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Report/ReportServer
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: NCFindWeb/index
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: WebReport/ReportServer
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Report/ReportServer
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Status/index
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:31 --> 404 Page Not Found: Solr/None
ERROR - 2021-09-26 13:26:32 --> 404 Page Not Found: EemAdminService/EemAdmin
ERROR - 2021-09-26 13:26:32 --> 404 Page Not Found: Jobmanager/logs
ERROR - 2021-09-26 13:26:32 --> 404 Page Not Found: Apisix/admin
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Examples/websocket
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Xxl-job-admin/index
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Run/index
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Seeyon/1.txt
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Console/bea-helpsets
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Api/admin
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Eam/vib
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Eam/vib
ERROR - 2021-09-26 13:26:37 --> 404 Page Not Found: Menu/stc
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Pcidss/report
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Api/systeminfo
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Mobile/DBConfigReader.jsp
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Api/systeminfo
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Mailsms/s
ERROR - 2021-09-26 13:26:38 --> 404 Page Not Found: Seeyon/test123456.jsp
ERROR - 2021-09-26 13:26:40 --> 404 Page Not Found: Sys/search
ERROR - 2021-09-26 13:26:42 --> 404 Page Not Found: Seeyon/1.txt
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Foo/default
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Foo/default
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: SecurityRealm/user
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Actuator/index
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Beans/index
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Version/index
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: %24%7b439871%2b3333%7d/index.action
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Api/beans
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: %24%7b439871%2b3333%7d/index.do
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Jolokia/list
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Manage/index
ERROR - 2021-09-26 13:26:49 --> 404 Page Not Found: Jolokia/list
ERROR - 2021-09-26 13:26:51 --> 404 Page Not Found: App/timelion
ERROR - 2021-09-26 13:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:39:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 13:39:48 --> 404 Page Not Found: Api/settings
ERROR - 2021-09-26 13:39:48 --> 404 Page Not Found: Api/settings
ERROR - 2021-09-26 13:39:48 --> 404 Page Not Found: Sys/search
ERROR - 2021-09-26 13:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:39:50 --> 404 Page Not Found: Openam/ccversion
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Ybvwptxt/index
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: WebReport/ReportServer
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Js/hrm
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Ybvwptxt/index
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Report/ReportServer
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: NCFindWeb/index
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: WebReport/ReportServer
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Report/ReportServer
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Status/index
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: Solr/None
ERROR - 2021-09-26 13:39:51 --> 404 Page Not Found: EemAdminService/EemAdmin
ERROR - 2021-09-26 13:39:52 --> 404 Page Not Found: Jobmanager/logs
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Apisix/admin
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Examples/websocket
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Run/index
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Xxl-job-admin/index
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Console/bea-helpsets
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Api/admin
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Eam/vib
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:39:55 --> 404 Page Not Found: Eam/vib
ERROR - 2021-09-26 13:39:57 --> 404 Page Not Found: Seeyon/1.txt
ERROR - 2021-09-26 13:39:58 --> 404 Page Not Found: Sys/search
ERROR - 2021-09-26 13:40:02 --> 404 Page Not Found: Seeyon/1.txt
ERROR - 2021-09-26 13:40:05 --> 404 Page Not Found: Menu/stc
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Pcidss/report
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Api/systeminfo
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Mobile/DBConfigReader.jsp
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Api/systeminfo
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Solr/admin
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Mailsms/s
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Seeyon/test123456.jsp
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Foo/default
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Foo/default
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Actuator/index
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: SecurityRealm/user
ERROR - 2021-09-26 13:40:06 --> 404 Page Not Found: Beans/index
ERROR - 2021-09-26 13:40:07 --> 404 Page Not Found: Api/beans
ERROR - 2021-09-26 13:40:07 --> 404 Page Not Found: Version/index
ERROR - 2021-09-26 13:40:07 --> 404 Page Not Found: Jolokia/list
ERROR - 2021-09-26 13:40:07 --> 404 Page Not Found: Jolokia/list
ERROR - 2021-09-26 13:40:07 --> 404 Page Not Found: Manage/index
ERROR - 2021-09-26 13:40:07 --> 404 Page Not Found: %24%7b439871%2b3333%7d/index.action
ERROR - 2021-09-26 13:40:07 --> 404 Page Not Found: %24%7b439871%2b3333%7d/index.do
ERROR - 2021-09-26 13:40:12 --> 404 Page Not Found: App/timelion
ERROR - 2021-09-26 13:40:49 --> 404 Page Not Found: Env/index
ERROR - 2021-09-26 13:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:49:05 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-26 13:49:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-26 13:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:56:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 13:56:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 13:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 13:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:58:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 13:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 13:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 13:59:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 14:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:00:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:00:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:01:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:01:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 14:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:03:54 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-26 14:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:04:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 14:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:08:52 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-26 14:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 14:13:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:16:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:35:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 14:40:31 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:31 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 14:40:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:40:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:41:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:42:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:43:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:43:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:43:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:14 --> 404 Page Not Found: Ewebeditor/asp
ERROR - 2021-09-26 14:44:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:44:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:45:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:46:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:46:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:46:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:47:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:47:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:47:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:47:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:47:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:48:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:48:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:48:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:49:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:49:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:49:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:50:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:50:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:51:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 14:51:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:51:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:52:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:52:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:53:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:53:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:54:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:54:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:55:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:55:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:56:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:56:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:57:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:57:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:58:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:58:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 14:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 14:59:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 14:59:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:00:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:00:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:01:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:01:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:02:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:02:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:03:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:03:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:04:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:04:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:05:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:05:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:06:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:06:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:07:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:07:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:08:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:08:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:09:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:09:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:10:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:10:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:11:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:11:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:12:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 15:12:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:12:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:13:51 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-26 15:13:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:13:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:14:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:14:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:15:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 15:15:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:15:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:16:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:16:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:17:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:17:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:18:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:18:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:19:01 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-09-26 15:19:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:19:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:20:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:20:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:21:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:21:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 15:22:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:22:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:23:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:23:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:24:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:24:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 15:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 15:25:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 15:25:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:25:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:26:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:26:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:27:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:27:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:28:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:28:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:29:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:29:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:30:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 15:30:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:30:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:31:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:31:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:32:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:32:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:33:05 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/uploads/ads/20191210142918_77206.jpg): No such file or directory /www/wwwroot/www.xuanhao.net/app/controllers/admin/Ads.php 182
ERROR - 2021-09-26 15:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 15:33:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:33:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:34:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 15:34:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:34:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:35:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:35:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:36:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:36:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:37:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:37:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:38:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:38:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:39:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:39:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:40:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:40:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:41:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:41:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:42:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:42:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:43:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:43:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:44:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:44:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:45:14 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-09-26 15:45:14 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-09-26 15:45:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:45:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:46:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:46:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:47:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:47:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:48:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:48:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:49:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:49:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:50:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:50:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:51:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:51:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:52:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:52:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:53:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:53:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:54:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:54:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:55:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:55:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:56:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:56:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:57:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:57:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 15:58:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:58:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:59:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 15:59:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:00:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:00:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:01:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:01:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:02:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:02:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:03:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 16:03:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:03:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:04:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:04:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:05:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 16:05:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:05:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 16:06:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:06:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:07:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:07:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:08:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:08:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 16:09:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:09:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 16:10:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:10:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:11:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 16:11:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:11:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:12:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:12:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:13:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:13:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:14:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:14:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:15:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:15:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:16:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:16:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:17:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:17:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:18:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:18:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 16:19:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:19:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:20:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:20:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:21:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:21:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:22:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:22:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:23:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:23:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:24:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:24:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:25:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:25:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:26:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:26:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:27:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:27:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:28:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:28:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:29:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:29:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:30:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:30:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:31:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:31:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:32:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 16:32:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:32:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:33:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:33:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:34:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:34:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:35:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:35:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:36:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:36:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:37:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:37:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:38:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:38:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:39:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:39:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:40:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:40:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:41:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:41:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 16:42:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:42:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:43:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:43:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:44:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:44:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:45:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:45:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:46:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:46:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:47:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:47:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:48:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:48:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:49:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:49:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 16:50:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:50:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:51:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:51:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:52:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:52:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:53:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:53:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:54:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:54:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:55:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:55:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:56:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:56:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:57:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:57:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:58:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:58:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:59:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 16:59:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:00:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:00:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:01:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:01:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:02:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:02:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:03:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:03:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:04:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:04:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:05:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:05:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:06:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:06:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:07:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:07:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:08:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:08:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 17:09:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:09:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:10:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:10:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:11:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:11:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:12:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 17:12:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:12:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:13:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:13:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 17:14:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:14:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:15:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:15:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:16:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:16:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:17:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:17:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:18:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:18:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:19:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:19:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:20:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:20:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:21:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:21:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-26 17:27:42 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-26 17:34:08 --> 404 Page Not Found: City/16
ERROR - 2021-09-26 17:37:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 17:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 17:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 17:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:05:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:11:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:12:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:12:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:13:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:13:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:13:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:13:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:14:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 18:14:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 18:14:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:14:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:15:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:15:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:15:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 18:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:18:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:18:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:19:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:19:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:19:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:20:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:21:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:22:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:23:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 18:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:23:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:25:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:28:03 --> 404 Page Not Found: City/10
ERROR - 2021-09-26 18:28:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:28:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:29:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:29:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:30:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:33:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:33:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:33:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:34:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:34:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:34:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:35:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:35:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:36:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:36:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:36:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:36:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:36:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:37:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:38:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:38:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:40:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:41:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:43:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 18:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:43:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:43:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:44:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:44:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 18:45:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 18:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:46:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:46:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:46:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:47:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:47:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:47:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:48:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:48:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:49:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:49:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:50:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:50:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 18:51:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:52:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:52:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:52:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:52:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:53:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:54:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:56:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:57:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:57:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:58:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:58:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:58:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 18:59:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:59:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 18:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:00:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:00:38 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-26 19:00:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 19:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:01:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:01:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:02:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:02:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:02:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:12:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 19:12:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 19:45:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 19:48:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 19:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:08:25 --> 404 Page Not Found: City/15
ERROR - 2021-09-26 20:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:14:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 20:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:37:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 20:38:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-26 20:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:42:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:45:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:45:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:46:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:46:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:49:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 20:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 20:55:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 21:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 21:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:20:49 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-26 21:23:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 21:28:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 21:28:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 21:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 21:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:47:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 21:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:52:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 21:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 21:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 21:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 21:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 22:04:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 22:08:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 22:09:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 22:09:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 22:10:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 22:11:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-26 22:15:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:30:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 22:30:26 --> 404 Page Not Found: Tagasp/index
ERROR - 2021-09-26 22:30:26 --> 404 Page Not Found: Plus/index
ERROR - 2021-09-26 22:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:38:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 22:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:46:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-26 22:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:50:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:50:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:50:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-26 22:52:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 22:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 23:29:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 23:29:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 23:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 23:32:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-26 23:40:46 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-26 23:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 23:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 23:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-26 23:58:33 --> 404 Page Not Found: Robotstxt/index
