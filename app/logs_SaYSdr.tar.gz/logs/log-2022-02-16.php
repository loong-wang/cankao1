<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-16 00:00:15 --> 404 Page Not Found: App/views
ERROR - 2022-02-16 00:00:15 --> 404 Page Not Found: App/views
ERROR - 2022-02-16 00:00:15 --> 404 Page Not Found: App/views
ERROR - 2022-02-16 00:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 00:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:08:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 00:14:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 00:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 00:22:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 00:25:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 00:43:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 00:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 00:44:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:45:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:45:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:46:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 00:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:02:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:08:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:13:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:15:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 01:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:33:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:43:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:44:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:45:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:46:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:46:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:46:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:48:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 01:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:51:28 --> 404 Page Not Found: City/1
ERROR - 2022-02-16 01:51:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:54:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:55:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:55:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:56:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:56:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 01:58:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 01:58:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 01:59:18 --> 404 Page Not Found: City/2
ERROR - 2022-02-16 01:59:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:00:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:02:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:02:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:04:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:05:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:06:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:07:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:07:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:08:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:08:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:09:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:10:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:10:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:11:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:12:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:12:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:12:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:12:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:12:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:14:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:14:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:14:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:14:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:14:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:15:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:15:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:17:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:17:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:18:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:18:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:18:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:18:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:18:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:18:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:18:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:19:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:19:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:19:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:19:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:19:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 02:19:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:19:46 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-02-16 02:19:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:19:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:20:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:20:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 02:20:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:20:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:21:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:21:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:21:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:21:57 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-16 02:22:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:23:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:23:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:23:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:23:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:24:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:25:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:27:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:29:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:29:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:33:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 02:42:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 02:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:33:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 03:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:36:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 03:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:53:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 03:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 03:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:01:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:01:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:01:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:02:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:02:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:02:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:03:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:03:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:04:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:04:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:08:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:09:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:13:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:16:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:16:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:17:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:23:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:24:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:24:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:29:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:38:33 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 04:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:39:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:44:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 04:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:50:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 04:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 05:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 05:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 05:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 05:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 05:20:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 05:20:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 05:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 05:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 05:21:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 05:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 05:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 05:35:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 05:56:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 06:05:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 06:10:05 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-02-16 06:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 06:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 06:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 06:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 06:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 06:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 06:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 06:40:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 06:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 07:07:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 07:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:24:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:25:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:26:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:28:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 07:40:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 07:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 07:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 07:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 07:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 08:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 08:09:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 08:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 08:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 08:32:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 08:46:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 08:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 08:47:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 08:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 08:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 08:56:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 08:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 08:58:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 08:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 08:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:01:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:01:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:01:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:03:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:03:56 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-16 09:04:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:05:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:05:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:06:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:06:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:06:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:07:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:07:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:16:45 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-02-16 09:17:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:20:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 09:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:20:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 09:21:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:25:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 09:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:29:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 09:29:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 09:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:30:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:34:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:34:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:35:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:35:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:35:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:38:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 09:39:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:40:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:41:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:49:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:50:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:51:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 09:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:52:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:53:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 09:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:55:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 09:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 10:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 10:00:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 10:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 10:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 10:21:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 10:25:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 10:26:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 10:26:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 10:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 10:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 10:33:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:35:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:36:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:36:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 10:44:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 10:44:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 10:44:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:44:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 10:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:26:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 11:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:28:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:33:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 11:37:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 11:41:21 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2022-02-16 11:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 11:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:51:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:52:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 11:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:01:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 12:03:28 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-16 12:03:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:04:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 12:05:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:10:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 12:10:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:10:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:11:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 12:12:19 --> Severity: error --> 11111 test 1
ERROR - 2022-02-16 12:17:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 12:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:49:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 12:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 12:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:04:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:06:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 13:07:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 13:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:16:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 13:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 13:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:35:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:41:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 13:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 13:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 13:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 13:51:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 13:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 13:57:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 13:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:00:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:03:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:03:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:21:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:22:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:23:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:27:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:31:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:32:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:38:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:38:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:39:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:40:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:40:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 14:57:36 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-16 14:57:37 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-16 14:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 14:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 15:01:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:02:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:03:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 15:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:11:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 15:13:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:14:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:14:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:14:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 15:14:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 15:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:22:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:24:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 15:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 15:31:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 15:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:42:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:48:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 15:48:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:48:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 15:49:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:50:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:54:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:55:44 --> 404 Page Not Found: City/1
ERROR - 2022-02-16 15:55:45 --> 404 Page Not Found: City/1
ERROR - 2022-02-16 15:55:45 --> 404 Page Not Found: City/1
ERROR - 2022-02-16 15:55:45 --> 404 Page Not Found: City/1
ERROR - 2022-02-16 15:55:45 --> 404 Page Not Found: City/1
ERROR - 2022-02-16 15:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:58:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 15:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:02:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 16:02:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:04:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 16:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 16:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 16:15:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 16:19:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 16:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 16:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 16:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:38:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:38:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:40:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 16:47:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:48:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:48:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 16:53:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:53:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 16:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 17:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 17:13:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 17:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 17:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 17:39:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 17:44:07 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-02-16 17:44:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 17:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 17:58:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:58:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 17:58:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:59:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:59:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 17:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:03:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:03:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:12:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:14:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:18:40 --> 404 Page Not Found: Ipquery/index
ERROR - 2022-02-16 18:18:40 --> 404 Page Not Found: Ipquery/index
ERROR - 2022-02-16 18:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:26:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 18:26:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 18:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:33:35 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2022-02-16 18:33:46 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-02-16 18:33:53 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2022-02-16 18:33:59 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-02-16 18:34:19 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2022-02-16 18:34:30 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-02-16 18:34:37 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2022-02-16 18:34:54 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2022-02-16 18:35:25 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-02-16 18:35:44 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-02-16 18:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:44:37 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 18:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 18:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 18:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 18:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 19:09:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 19:12:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-16 19:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 19:19:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 19:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 19:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 19:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 19:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 19:48:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 19:49:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 19:56:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 19:59:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 20:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 20:03:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 20:06:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:07:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:07:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:10:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:10:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:13:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 20:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:14:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 20:15:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 20:15:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 20:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 20:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 20:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 20:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 20:39:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 20:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 20:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:43:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 20:46:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:51:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:53:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:53:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:54:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 20:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:02:54 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-16 21:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:05:17 --> 404 Page Not Found: Text4041645016717/index
ERROR - 2022-02-16 21:05:17 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-02-16 21:05:17 --> 404 Page Not Found: Evox/about
ERROR - 2022-02-16 21:05:17 --> 404 Page Not Found: Sdk/index
ERROR - 2022-02-16 21:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:07:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:13:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:13:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 21:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 21:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:29:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 21:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:30:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:31:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:31:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:31:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:34:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:35:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:37:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 21:41:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:44:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 21:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 21:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:55:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 21:56:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 21:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 21:58:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 21:59:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-16 22:05:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:06:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:06:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 22:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 22:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:11:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 22:49:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 22:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:06:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:06:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:08:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:08:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:08:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:08:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:09:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:09:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:20:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:21:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 23:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:35:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:39:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:43:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:45:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:45:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:45:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-16 23:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:50:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:51:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-16 23:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-16 23:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
