<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-02 00:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:04:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 00:15:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:16:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 00:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 00:22:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 00:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:24:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:30:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 00:35:38 --> 404 Page Not Found: City/1
ERROR - 2021-12-02 00:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 01:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 01:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 01:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 01:08:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 01:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 01:11:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 01:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 01:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 01:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 01:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 01:55:59 --> 404 Page Not Found: City/1
ERROR - 2021-12-02 02:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 02:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 02:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 02:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 02:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 02:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 02:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 03:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 03:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 03:20:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 03:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 03:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 03:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 03:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:00:25 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-12-02 04:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:55:00 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 04:55:00 --> 404 Page Not Found: admin//index
ERROR - 2021-12-02 04:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 04:55:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 04:55:02 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 04:55:02 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-12-02 04:55:02 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-12-02 04:55:03 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-12-02 04:55:03 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-02 04:55:03 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-12-02 04:55:03 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-02 04:55:04 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-02 04:55:04 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-02 04:55:04 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-02 04:55:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 05:14:18 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 05:14:18 --> 404 Page Not Found: admin//index
ERROR - 2021-12-02 05:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 05:14:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 05:14:19 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 05:14:19 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-12-02 05:14:19 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-12-02 05:14:21 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-12-02 05:14:21 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-02 05:14:21 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-12-02 05:14:21 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-02 05:14:21 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-02 05:14:21 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-02 05:14:21 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-02 05:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 05:33:43 --> 404 Page Not Found: City/18
ERROR - 2021-12-02 05:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 05:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 05:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 05:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 05:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 06:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 06:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 06:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 06:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 06:32:52 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-12-02 06:34:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-02 06:36:13 --> 404 Page Not Found: City/10
ERROR - 2021-12-02 06:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 06:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 06:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 06:54:52 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-12-02 07:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 07:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 07:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 07:35:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-02 07:42:37 --> 404 Page Not Found: Source/13f135855aa54a2688dd45d4fd43eed9_4
ERROR - 2021-12-02 07:43:20 --> 404 Page Not Found: V2/article
ERROR - 2021-12-02 07:59:33 --> 404 Page Not Found: City/1
ERROR - 2021-12-02 08:00:40 --> 404 Page Not Found: City/10
ERROR - 2021-12-02 08:01:03 --> 404 Page Not Found: City/2
ERROR - 2021-12-02 08:01:08 --> 404 Page Not Found: City/index
ERROR - 2021-12-02 08:01:09 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-12-02 08:01:11 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-12-02 08:01:13 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-12-02 08:01:15 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-12-02 08:01:25 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-12-02 08:01:26 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-12-02 08:01:26 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-12-02 08:01:32 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-12-02 08:01:33 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-12-02 08:01:36 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-12-02 08:01:36 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-12-02 08:01:38 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-12-02 08:01:40 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-02 08:01:40 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-12-02 08:01:42 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-12-02 08:01:43 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-02 08:01:44 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-02 08:01:45 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-12-02 08:01:45 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-12-02 08:02:01 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-02 08:02:07 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-12-02 08:02:07 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-12-02 08:02:08 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-02 08:02:08 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-12-02 08:02:16 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-12-02 08:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 08:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 08:30:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 09:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:12:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 09:12:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 09:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:26:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 09:29:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 09:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 09:37:40 --> 404 Page Not Found: City/16
ERROR - 2021-12-02 09:37:43 --> 404 Page Not Found: City/16
ERROR - 2021-12-02 09:37:44 --> 404 Page Not Found: City/16
ERROR - 2021-12-02 09:38:26 --> 404 Page Not Found: City/16
ERROR - 2021-12-02 09:39:03 --> 404 Page Not Found: City/16
ERROR - 2021-12-02 09:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:42:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 09:43:14 --> 404 Page Not Found: City/1
ERROR - 2021-12-02 09:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:56:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 09:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 09:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 10:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 10:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 10:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 10:18:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 10:18:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 10:18:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-02 10:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 10:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 10:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 10:38:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-02 10:46:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 10:46:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 10:47:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 10:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 10:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 10:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 10:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 10:55:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 10:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:00:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:00:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:00:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:02:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 11:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 11:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:05:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:06:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 11:13:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:14:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:16:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 11:21:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:35:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 11:41:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:44:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:44:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:46:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:48:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 11:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:23:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 12:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:35:47 --> 404 Page Not Found: Install/templates
ERROR - 2021-12-02 12:35:47 --> 404 Page Not Found: Templets/default
ERROR - 2021-12-02 12:35:47 --> 404 Page Not Found: Templets/plus
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/plus
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/plus
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/plus
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/plus
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/plus
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/default
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/default
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Templets/default
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Member/templets
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Member/templets
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Member/templets
ERROR - 2021-12-02 12:35:48 --> 404 Page Not Found: Member/templets
ERROR - 2021-12-02 12:35:49 --> 404 Page Not Found: Member/templets
ERROR - 2021-12-02 12:35:49 --> 404 Page Not Found: Member/templets
ERROR - 2021-12-02 12:35:49 --> 404 Page Not Found: Install/sql-dfdata.txt
ERROR - 2021-12-02 12:35:49 --> 404 Page Not Found: Templets/default
ERROR - 2021-12-02 12:35:49 --> 404 Page Not Found: Templets/default
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:50 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:51 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:52 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:53 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:54 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-02 12:35:56 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-02 12:35:57 --> 404 Page Not Found: Templets/system
ERROR - 2021-12-02 12:35:57 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:57 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:57 --> 404 Page Not Found: Member/space
ERROR - 2021-12-02 12:35:57 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-12-02 12:35:57 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-12-02 12:35:57 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-02 12:35:59 --> 404 Page Not Found: Install/templates
ERROR - 2021-12-02 12:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 12:52:49 --> 404 Page Not Found: Dasp/index
ERROR - 2021-12-02 12:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 12:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 12:57:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:09:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 13:15:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:16:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:18:27 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-02 13:18:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 13:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:27:19 --> 404 Page Not Found: City/17
ERROR - 2021-12-02 13:30:56 --> 404 Page Not Found: City/1
ERROR - 2021-12-02 13:33:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 13:36:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:40:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:40:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:43:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 13:45:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 13:59:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:00:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 14:01:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 14:02:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 14:08:02 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-02 14:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 14:11:14 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-02 14:11:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:11:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 14:14:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:14:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:18:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 14:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 14:21:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 14:34:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:34:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 14:35:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:35:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 14:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 14:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:15:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:15:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:21:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:33:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 15:34:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 15:38:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 15:38:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 15:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 15:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:55:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 15:56:19 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-12-02 16:01:13 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 277
ERROR - 2021-12-02 16:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 16:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 16:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 16:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 16:40:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:40:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:42:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:44:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:47:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 16:47:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 16:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:48:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:48:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:54:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 16:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 16:57:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 17:05:18 --> 404 Page Not Found: Sitewebasp/index
ERROR - 2021-12-02 17:06:12 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-12-02 17:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 17:19:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 17:21:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 17:29:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 17:30:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 17:34:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 17:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 17:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 17:38:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 17:38:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 17:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 17:44:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 17:51:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 17:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 18:07:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-02 18:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 18:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 18:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 18:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 18:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 18:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 18:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 18:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 18:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 18:39:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-02 18:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 18:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:19:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:26:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 19:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:30:21 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 19:30:21 --> 404 Page Not Found: admin//index
ERROR - 2021-12-02 19:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:30:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 19:30:21 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-02 19:30:21 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-02 19:30:22 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-02 19:30:22 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-02 19:31:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:32:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:35:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:49:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:52:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 19:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 19:57:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 19:57:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 19:57:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:00:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:01:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:02:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:03:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 20:03:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 20:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:11:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:11:51 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-12-02 20:12:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:13:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:13:20 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-12-02 20:15:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:15:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:15:50 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-12-02 20:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 20:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:24:33 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-12-02 20:24:43 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-12-02 20:29:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:38:16 --> 404 Page Not Found: City/1
ERROR - 2021-12-02 20:39:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 20:39:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 20:41:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-02 20:43:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:44:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:48:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 20:48:53 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-02 20:49:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 20:54:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 20:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 21:02:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 21:15:54 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-12-02 21:16:57 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-12-02 21:20:21 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-12-02 21:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 21:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 21:29:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 21:29:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 21:35:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 21:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 21:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 21:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 21:46:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Index/index
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Erm/help
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Lateronasp/index
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Template/Home
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Trade/quote
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Cngzjs/index
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Wx/ZFpass.asp
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: User/Reg
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Web/api
ERROR - 2021-12-02 21:59:43 --> 404 Page Not Found: Views/bank
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Loan/SubmitLogin
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Smb_scheduler/cdr.htm
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Case/index
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Index/index
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Goip/cron.htm
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Api/v1
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: 11txt/index
ERROR - 2021-12-02 21:59:44 --> 404 Page Not Found: Jsonpublic/selectAddtion.asp
ERROR - 2021-12-02 22:00:42 --> 404 Page Not Found: City/1
ERROR - 2021-12-02 22:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 22:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:05:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:05:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:06:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:07:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:07:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:07:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:08:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:08:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 22:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:09:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:11:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:12:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:13:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:13:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:13:24 --> 404 Page Not Found: 1/all
ERROR - 2021-12-02 22:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:14:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:14:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:14:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:14:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:14:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 22:14:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:15:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:15:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:15:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 22:15:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:16:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:16:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:16:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:18:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:19:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:21:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:21:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:26:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 22:27:56 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 22:27:56 --> 404 Page Not Found: admin//index
ERROR - 2021-12-02 22:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 22:27:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 22:27:57 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 22:27:57 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-12-02 22:27:57 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-12-02 22:27:59 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-12-02 22:27:59 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-02 22:27:59 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-12-02 22:27:59 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-02 22:27:59 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-02 22:27:59 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-02 22:27:59 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-02 22:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 22:39:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 22:43:50 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-02 22:43:50 --> 404 Page Not Found: admin//index
ERROR - 2021-12-02 22:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 22:43:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 22:43:51 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-02 22:43:51 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-02 22:43:51 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-02 22:51:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-02 22:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 22:53:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 22:55:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-02 22:56:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-02 23:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 23:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 23:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 23:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 23:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:20:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:22:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:24:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:30:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 23:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-02 23:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-02 23:55:44 --> 404 Page Not Found: Robotstxt/index
