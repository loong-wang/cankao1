<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-10 00:07:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-10 00:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 00:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 00:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 00:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 00:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 00:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 00:50:21 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-10 00:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 00:53:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 01:10:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 01:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 01:11:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 01:11:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 01:12:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 01:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 01:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 01:25:15 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-10 01:30:27 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-12-10 01:31:28 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-12-10 01:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 01:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 01:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 01:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 01:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 01:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:07:04 --> 404 Page Not Found: City/1
ERROR - 2021-12-10 02:07:44 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-10 02:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:18:18 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-10 02:20:03 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-10 02:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:34:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 02:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:36:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 02:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 02:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 03:51:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 03:54:15 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-10 04:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 04:55:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 05:12:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 05:13:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 05:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 05:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:39:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 05:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:40:08 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-10 05:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:42:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 05:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:52:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 05:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 05:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 05:57:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 05:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 05:57:39 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-10 05:57:39 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-10 06:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 06:21:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 06:21:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 06:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 06:24:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 06:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 06:24:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 06:25:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 06:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 06:41:18 --> 404 Page Not Found: Plug/vote
ERROR - 2021-12-10 06:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 06:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 06:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 06:58:30 --> 404 Page Not Found: QeeB/index
ERROR - 2021-12-10 07:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 07:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 07:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 07:23:40 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-10 07:34:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 07:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 07:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 07:47:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 07:48:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 07:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 07:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 07:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 07:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 07:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 08:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 08:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 08:20:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 08:23:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 08:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 08:25:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 08:26:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 08:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 08:33:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 08:43:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 08:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 09:01:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 09:01:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 09:04:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 09:16:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 09:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 09:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 09:28:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 09:28:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 09:28:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 09:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 09:37:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 09:39:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 09:41:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 09:43:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 09:43:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 09:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 09:45:29 --> 404 Page Not Found: Text4041639100729/index
ERROR - 2021-12-10 09:45:29 --> 404 Page Not Found: Evox/about
ERROR - 2021-12-10 09:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 09:45:29 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-12-10 09:45:30 --> 404 Page Not Found: Sdk/index
ERROR - 2021-12-10 09:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 09:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 09:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 09:51:14 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-12-10 09:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 10:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 10:05:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 10:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 10:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 10:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 10:21:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 10:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 10:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 10:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:29:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:31:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 10:47:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 10:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:55:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:56:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 10:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 11:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 11:05:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:05:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 11:05:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 11:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:07:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:16:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 11:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 11:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 11:39:53 --> 404 Page Not Found: Md5asp/index
ERROR - 2021-12-10 11:40:38 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-10 11:40:38 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-10 11:40:38 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-10 11:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 11:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 11:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 11:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 12:00:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 12:00:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 12:06:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 12:21:38 --> 404 Page Not Found: 1/10000
ERROR - 2021-12-10 12:24:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 12:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 12:30:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 12:31:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 12:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 12:49:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 12:52:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 12:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 12:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 12:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:04:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 13:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:07:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:17:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:18:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:18:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 13:18:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 13:25:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 13:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:35:00 --> Severity: error --> 11111 test 1
ERROR - 2021-12-10 13:37:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:41:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 13:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:53:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 13:54:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 13:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 13:56:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 13:56:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 14:09:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:10:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:19:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 14:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:22:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:22:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:24:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:24:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:26:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:28:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 14:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 14:35:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:35:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:35:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:43:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-10 14:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 14:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 14:54:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:54:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:54:19 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-12-10 14:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 14:54:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:54:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:54:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:54:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 14:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 14:56:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 14:57:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:00:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:02:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:06:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:11:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 15:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:18:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:21:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:24:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:26:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:27:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:27:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:27:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 15:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:37:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:49:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 15:53:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:55:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:55:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 15:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 16:26:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 16:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:38:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 16:40:38 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-10 16:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 16:54:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 17:06:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 17:12:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 17:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 17:23:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 17:26:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 17:28:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-10 17:35:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 17:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 17:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 17:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 17:47:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 17:50:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 17:50:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 17:50:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:01:01 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-10 18:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:08:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-10 18:14:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 18:19:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:20:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:20:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:34:29 --> 404 Page Not Found: City/16
ERROR - 2021-12-10 18:34:35 --> 404 Page Not Found: City/16
ERROR - 2021-12-10 18:34:35 --> 404 Page Not Found: City/16
ERROR - 2021-12-10 18:34:35 --> 404 Page Not Found: City/16
ERROR - 2021-12-10 18:34:35 --> 404 Page Not Found: City/16
ERROR - 2021-12-10 18:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 18:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 18:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 18:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 18:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 18:58:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 19:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 19:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 19:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 19:27:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 19:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 19:38:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 19:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 19:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 19:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 20:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 20:09:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 20:09:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 20:09:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 20:09:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 20:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 20:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 20:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 20:16:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-10 20:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 20:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 20:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 20:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 20:30:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 20:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 20:32:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into `fox_haoma` (hao_city,hao_type,hao_pinpai,hao_title,hao_jiage,hao_huafei,hao_heyue,hao_beizhu,hao_user,hao_time) values 
ERROR - 2021-12-10 20:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 20:40:02 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-10 20:50:21 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-10 20:51:35 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-10 20:57:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-10 21:01:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 21:01:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 21:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:35:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 21:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 21:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:49:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 21:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 21:55:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 22:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 22:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:13:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 22:14:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 22:16:05 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-12-10 22:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 22:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 22:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 22:19:43 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-10 22:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 22:23:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 22:25:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 22:26:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 22:27:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:28:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:28:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 22:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:33:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 22:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:36:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:37:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 22:47:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 22:47:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 22:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 22:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 23:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 23:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 23:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:11:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:11:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:12:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:12:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:15:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 23:15:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 23:18:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:20:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 23:20:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 23:22:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:26:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-10 23:35:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:36:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:38:47 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-10 23:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-10 23:41:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:46:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 23:47:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:49:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-10 23:54:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 23:54:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-10 23:56:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
