<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-13 00:01:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 00:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:15:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 00:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 00:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:46:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:47:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:48:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:49:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:49:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:49:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 00:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:50:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 00:50:34 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-13 00:50:35 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-13 00:50:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 00:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 00:58:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 01:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:01:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:02:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:02:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:03:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:03:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 01:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 01:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 01:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 01:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 01:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 01:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 02:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 02:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 02:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 02:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 02:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 02:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 02:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 02:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 02:34:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 02:35:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 02:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 02:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 02:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 03:47:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 03:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 03:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 03:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 04:01:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-11-13 04:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 04:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 04:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 04:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 04:53:09 --> 404 Page Not Found: Text4041636750388/index
ERROR - 2021-11-13 04:53:09 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-13 04:53:09 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-13 04:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 04:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 05:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 05:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 05:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 05:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 05:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 05:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 05:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 06:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 06:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 07:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 07:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 07:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 08:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 08:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 08:12:17 --> 404 Page Not Found: City/1
ERROR - 2021-11-13 08:12:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 08:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 08:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 08:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 08:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 08:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 08:35:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 08:40:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:41:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:46:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 08:46:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 08:51:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:52:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 08:56:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 08:56:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 08:56:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:56:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 08:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 08:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 08:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:02:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:02:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:02:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 09:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 09:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 09:22:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:26:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:29:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:32:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:39:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:39:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 09:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:51:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 09:51:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:52:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:58:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:58:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:59:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:59:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 09:59:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 10:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 10:25:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 10:25:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:29:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 10:32:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 10:36:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 10:39:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 10:50:12 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-11-13 10:51:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:51:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 10:55:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:02:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:02:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:04:01 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-13 11:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 11:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:06:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 11:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:08:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:09:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:09:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:10:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:11:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 11:11:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:12:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:14:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 11:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 11:16:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:19:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:20:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 11:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:21:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 11:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:22:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 11:23:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:26:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:27:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:27:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:28:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:28:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:28:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:29:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 11:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 11:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 11:40:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:01:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:02:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:02:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:02:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 12:02:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 12:03:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 12:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 12:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:14:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:24:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:26:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 12:37:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:42:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 12:43:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:44:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:44:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:44:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:45:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:45:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 12:46:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 12:46:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:46:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:46:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:47:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 12:51:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 13:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 13:12:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:13:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 13:14:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:14:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:15:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:16:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:16:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:18:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:19:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:21:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:24:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:24:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:25:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:26:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:27:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:27:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:38:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 13:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 13:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:59:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 13:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 14:00:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 14:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 14:01:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 14:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 14:09:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 14:10:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 14:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 14:16:49 --> 404 Page Not Found: City/10
ERROR - 2021-11-13 14:20:28 --> 404 Page Not Found: City/1
ERROR - 2021-11-13 14:28:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 14:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 14:34:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 14:35:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-13 14:38:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 14:39:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 14:58:36 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-13 15:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:03:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:07:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:09:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 15:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 15:20:45 --> 404 Page Not Found: City/16
ERROR - 2021-11-13 15:24:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 15:34:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 15:35:32 --> 404 Page Not Found: Shell/index
ERROR - 2021-11-13 15:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 15:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 15:52:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 15:54:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 15:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 15:58:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 16:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 16:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 16:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 16:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 16:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 16:26:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 16:26:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 16:28:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 16:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 16:32:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 16:38:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 16:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 16:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 16:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 16:41:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 16:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 17:02:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 17:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 17:10:29 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-11-13 17:11:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 17:18:53 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-13 17:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 17:23:14 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-13 17:27:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 17:32:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 17:32:24 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-11-13 17:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 17:34:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-13 17:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 18:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 18:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 18:32:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 18:32:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 18:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 18:43:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 18:45:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 18:46:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 18:49:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 18:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 18:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 19:01:56 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-13 19:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 19:04:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 19:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 19:11:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 19:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 19:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 19:20:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 19:31:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 19:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 19:50:59 --> 404 Page Not Found: App/views
ERROR - 2021-11-13 20:03:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 20:04:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 20:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 20:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 20:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 20:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 20:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 20:38:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 20:43:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 20:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 20:57:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 20:58:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 20:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:04:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:04:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 21:19:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 21:19:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:19:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 21:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 21:31:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:31:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 21:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:43:10 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-13 21:44:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 21:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 21:45:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 21:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 21:45:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 21:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 21:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 21:57:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:58:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 21:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 21:59:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 22:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 22:17:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-13 22:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 22:31:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:41:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 22:43:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:43:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:44:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:44:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 22:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 22:48:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:01:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:05:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:05:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 23:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 23:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:12:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:13:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:13:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:26:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-13 23:35:05 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-13 23:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:39:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:39:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:39:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:41:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:41:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:42:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:42:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:43:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:43:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:44:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:45:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:46:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-13 23:55:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:55:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:55:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:55:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-13 23:55:35 --> 404 Page Not Found: Faviconico/index
