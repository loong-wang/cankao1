<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-10 00:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:01:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:08:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:08:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:09:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:09:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:09:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:11:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:21:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:22:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:23:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:24:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:27:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:28:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:28:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:30:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:31:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:32:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:33:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:33:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:34:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:34:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 00:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:41:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:42:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:44:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:45:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:45:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:46:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:46:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:47:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 00:47:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-10 00:47:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-10 00:48:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:49:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-10 00:49:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-10 00:49:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:50:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:51:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 00:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:53:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:54:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:57:49 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-10 00:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 00:58:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 00:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:02:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 01:02:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 01:04:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 01:06:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 01:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:08:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:17:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:21:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:33:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:38:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:38:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:39:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 01:39:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:40:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:40:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:41:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:41:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:43:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:43:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:44:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:46:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 01:47:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:47:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 01:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:48:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:52:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:52:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:53:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:54:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:55:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:55:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:56:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:56:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:58:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:58:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 01:59:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 01:59:49 --> 404 Page Not Found: Zhiyepeixun/15803484.htm
ERROR - 2021-06-10 01:59:49 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-06-10 01:59:49 --> 404 Page Not Found: F/view
ERROR - 2021-06-10 01:59:49 --> 404 Page Not Found: FullText/fulltext_form.aspx
ERROR - 2021-06-10 01:59:50 --> 404 Page Not Found: WebDiskServerDemo/doc
ERROR - 2021-06-10 01:59:50 --> 404 Page Not Found: Topic/200802.htm
ERROR - 2021-06-10 01:59:50 --> 404 Page Not Found: Web/about
ERROR - 2021-06-10 01:59:50 --> 404 Page Not Found: Qshequ/index.jsp
ERROR - 2021-06-10 01:59:50 --> 404 Page Not Found: Card/index
ERROR - 2021-06-10 01:59:50 --> 404 Page Not Found: Shipin1/guochanqingse
ERROR - 2021-06-10 01:59:51 --> 404 Page Not Found: Zwgk/bmwj
ERROR - 2021-06-10 01:59:51 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-06-10 01:59:51 --> 404 Page Not Found: Galleries/watch-41-year-old-executive-joana-jakes-get-naked-at.html
ERROR - 2021-06-10 01:59:51 --> 404 Page Not Found: Info/1135
ERROR - 2021-06-10 01:59:51 --> 404 Page Not Found: Vod/play
ERROR - 2021-06-10 01:59:52 --> 404 Page Not Found: Bk/index
ERROR - 2021-06-10 01:59:54 --> 404 Page Not Found: List/index
ERROR - 2021-06-10 01:59:55 --> 404 Page Not Found: Topic/004108.htm
ERROR - 2021-06-10 01:59:56 --> 404 Page Not Found: Apps/ztsdp
ERROR - 2021-06-10 01:59:57 --> 404 Page Not Found: One/a
ERROR - 2021-06-10 01:59:57 --> 404 Page Not Found: Jhsw/bdym_06
ERROR - 2021-06-10 01:59:57 --> 404 Page Not Found: Netspba/aStart.m
ERROR - 2021-06-10 01:59:57 --> 404 Page Not Found: View/index149607.html
ERROR - 2021-06-10 01:59:59 --> 404 Page Not Found: Activity/skip2AwardPool
ERROR - 2021-06-10 01:59:59 --> 404 Page Not Found: Patent/201720084856.0
ERROR - 2021-06-10 01:59:59 --> 404 Page Not Found: GCmddo/index
ERROR - 2021-06-10 02:00:00 --> 404 Page Not Found: Product/list.html
ERROR - 2021-06-10 02:00:00 --> 404 Page Not Found: En/video
ERROR - 2021-06-10 02:00:01 --> 404 Page Not Found: Admin/Order
ERROR - 2021-06-10 02:00:02 --> 404 Page Not Found: Vod/detail
ERROR - 2021-06-10 02:00:02 --> 404 Page Not Found: TKP-Platform/view
ERROR - 2021-06-10 02:00:03 --> 404 Page Not Found: Detailaspx/index
ERROR - 2021-06-10 02:00:03 --> 404 Page Not Found: Donfon9/download
ERROR - 2021-06-10 02:00:04 --> 404 Page Not Found: Nadus/uyvwgrqx8h.html
ERROR - 2021-06-10 02:00:07 --> 404 Page Not Found: Zentao/task-view-2008.html
ERROR - 2021-06-10 02:00:07 --> 404 Page Not Found: Cse/search
ERROR - 2021-06-10 02:00:10 --> 404 Page Not Found: Jcxx2html/index
ERROR - 2021-06-10 02:00:11 --> 404 Page Not Found: Cbook_20953/index
ERROR - 2021-06-10 02:00:15 --> 404 Page Not Found: Case/caseregisterdetail.aspx
ERROR - 2021-06-10 02:00:33 --> 404 Page Not Found: Jijin/jijin02PC
ERROR - 2021-06-10 02:00:33 --> 404 Page Not Found: Wjyyxnkedc/ViewSubjectRandNo
ERROR - 2021-06-10 02:00:34 --> 404 Page Not Found: Gczx1/jv.html
ERROR - 2021-06-10 02:00:34 --> 404 Page Not Found: admin/Reportmx/reportmx2_t_six
ERROR - 2021-06-10 02:00:35 --> 404 Page Not Found: Detail/3527060
ERROR - 2021-06-10 02:00:35 --> 404 Page Not Found: Km/review
ERROR - 2021-06-10 02:00:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:00:39 --> 404 Page Not Found: Js_ttksq_rep_hxaspx/index
ERROR - 2021-06-10 02:00:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:00:40 --> 404 Page Not Found: Search/index
ERROR - 2021-06-10 02:00:40 --> 404 Page Not Found: En/japanese best
ERROR - 2021-06-10 02:00:40 --> 404 Page Not Found: Company/company-show-1201487.html
ERROR - 2021-06-10 02:00:40 --> 404 Page Not Found: Workflow/request
ERROR - 2021-06-10 02:00:42 --> 404 Page Not Found: Defoultasp/index
ERROR - 2021-06-10 02:00:42 --> 404 Page Not Found: Vodsearch/%E7%AC%AC%E4%BA%8C%E9%83%A8----------2---.html
ERROR - 2021-06-10 02:00:50 --> 404 Page Not Found: Sticker/-99309706
ERROR - 2021-06-10 02:00:57 --> 404 Page Not Found: Tube/--88919
ERROR - 2021-06-10 02:00:58 --> 404 Page Not Found: Book/9580.html
ERROR - 2021-06-10 02:00:59 --> 404 Page Not Found: Destiny/jcsp
ERROR - 2021-06-10 02:00:59 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-10 02:00:59 --> 404 Page Not Found: Stock/move
ERROR - 2021-06-10 02:00:59 --> 404 Page Not Found: Shipin/32-169.html
ERROR - 2021-06-10 02:01:02 --> 404 Page Not Found: W_19rqvgth05html/index
ERROR - 2021-06-10 02:01:08 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-06-10 02:01:21 --> 404 Page Not Found: Vod-detail-id-35115html/index
ERROR - 2021-06-10 02:01:21 --> 404 Page Not Found: SYSA/repair
ERROR - 2021-06-10 02:01:21 --> 404 Page Not Found: Design/index
ERROR - 2021-06-10 02:01:21 --> 404 Page Not Found: Workflow/request
ERROR - 2021-06-10 02:01:24 --> 404 Page Not Found: Topic/id-17270339.html
ERROR - 2021-06-10 02:01:24 --> 404 Page Not Found: Info-415html/index
ERROR - 2021-06-10 02:01:35 --> 404 Page Not Found: List-1html/index
ERROR - 2021-06-10 02:01:36 --> 404 Page Not Found: RedPacket/index
ERROR - 2021-06-10 02:01:37 --> 404 Page Not Found: Qy/sdgc
ERROR - 2021-06-10 02:01:38 --> 404 Page Not Found: New/nb
ERROR - 2021-06-10 02:01:38 --> 404 Page Not Found: Dj06/index.html
ERROR - 2021-06-10 02:01:38 --> 404 Page Not Found: User/playback.html
ERROR - 2021-06-10 02:01:43 --> 404 Page Not Found: OperationProcedurejsp/index
ERROR - 2021-06-10 02:01:43 --> 404 Page Not Found: Account/Login
ERROR - 2021-06-10 02:01:44 --> 404 Page Not Found: Tgrtys/list_3_6.html
ERROR - 2021-06-10 02:01:44 --> 404 Page Not Found: N/dsrqw
ERROR - 2021-06-10 02:01:45 --> 404 Page Not Found: WorkFlow/WorkFlowAppView
ERROR - 2021-06-10 02:01:46 --> 404 Page Not Found: Singeraspx/index
ERROR - 2021-06-10 02:02:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:03:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 02:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:06:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:07:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:09:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:11:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:12:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:15:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:16:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:17:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:18:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:18:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-10 02:19:10 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-10 02:19:11 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-10 02:19:12 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-10 02:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:19:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 02:19:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:21:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:21:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:25:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:25:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:26:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:26:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:32:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 02:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:38:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:39:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:41:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:42:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:43:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:45:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:45:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:46:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:47:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:48:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 02:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:50:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:52:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:54:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:56:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 02:56:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 02:56:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 02:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:58:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:58:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:58:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:59:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 02:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 02:59:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:01:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:02:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:02:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:03:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:04:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:04:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:04:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:04:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:04:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:06:33 --> 404 Page Not Found: Lmymlm/lmyss1_12.html
ERROR - 2021-06-10 03:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:06:41 --> 404 Page Not Found: 20160601/n452331923.shtml
ERROR - 2021-06-10 03:06:41 --> 404 Page Not Found: Tianxing/setting
ERROR - 2021-06-10 03:06:44 --> 404 Page Not Found: Vodtag/%E4%BA%BA%E5%A6%BB
ERROR - 2021-06-10 03:06:44 --> 404 Page Not Found: News_listasp/index
ERROR - 2021-06-10 03:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:06:55 --> 404 Page Not Found: A/116820827_493932
ERROR - 2021-06-10 03:07:05 --> 404 Page Not Found: Account/Login
ERROR - 2021-06-10 03:07:10 --> 404 Page Not Found: 16/0113
ERROR - 2021-06-10 03:07:12 --> 404 Page Not Found: 404html/index
ERROR - 2021-06-10 03:07:17 --> 404 Page Not Found: 2020/0428
ERROR - 2021-06-10 03:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:07:25 --> 404 Page Not Found: Z3000000048082754/index
ERROR - 2021-06-10 03:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:07:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:08:15 --> 404 Page Not Found: 20120417/n340831214.shtml
ERROR - 2021-06-10 03:08:17 --> 404 Page Not Found: List/index3_2.html
ERROR - 2021-06-10 03:08:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:08:20 --> 404 Page Not Found: 10146957html/index
ERROR - 2021-06-10 03:08:21 --> 404 Page Not Found: ArtDetail/index
ERROR - 2021-06-10 03:08:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:08:37 --> 404 Page Not Found: P-9853866894980html/index
ERROR - 2021-06-10 03:08:57 --> 404 Page Not Found: Indexasp/index
ERROR - 2021-06-10 03:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:09:30 --> 404 Page Not Found: City/10
ERROR - 2021-06-10 03:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:09:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:09:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:10:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:10:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:11:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:11:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 03:12:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:12:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:12:23 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 03:12:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:12:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:12:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:13:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:13:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:14:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:14:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:15:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 03:16:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:16:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:17:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:18:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:19:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:19:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:19:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:20:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:20:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:21:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 03:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:22:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:24:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:27:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:27:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:28:03 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 03:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:31:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:32:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:35:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 03:35:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:37:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 03:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:39:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:42:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:43:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:45:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:46:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:46:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:49:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:49:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:51:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:51:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:51:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:52:06 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-10 03:53:06 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-10 03:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:54:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:55:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:56:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 03:57:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:57:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:59:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 03:59:56 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-06-10 03:59:58 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-06-10 03:59:58 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-06-10 03:59:58 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-06-10 03:59:59 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-06-10 03:59:59 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-06-10 03:59:59 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-06-10 03:59:59 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-06-10 04:00:00 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-06-10 04:00:00 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-06-10 04:00:00 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-06-10 04:00:00 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-06-10 04:00:01 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-06-10 04:00:01 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-06-10 04:00:01 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-06-10 04:00:01 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-06-10 04:00:01 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-06-10 04:00:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-10 04:01:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:01:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:03:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:03:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:03:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:05:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:06:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:06:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:07:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:07:48 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-10 04:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:08:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:09:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:09:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:10:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:11:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:12:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:12:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:13:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:13:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:14:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:15:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:15:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:15:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:15:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:16:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:17:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:17:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:17:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:17:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:17:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:18:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:18:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:19:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:20:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:20:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:20:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:20:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:20:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:20:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:21:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:21:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:22:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:22:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 04:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:24:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:25:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:26:11 --> 404 Page Not Found: Env/index
ERROR - 2021-06-10 04:26:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:26:24 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-10 04:26:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:26:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 04:27:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:27:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:29:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:29:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:29:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 04:29:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:30:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:30:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:30:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:32:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:32:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:34:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 04:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:35:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:35:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:36:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:37:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:38:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:40:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:40:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:40:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:41:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:41:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:41:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 04:45:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 04:45:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 04:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 04:47:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 04:52:58 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 04:52:59 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-10 04:53:00 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-10 04:53:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:53:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 04:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:57:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 04:57:52 --> 404 Page Not Found: Env/index
ERROR - 2021-06-10 04:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 04:58:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:00:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:00:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:00:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:02:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:02:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:02:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:03:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:03:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:03:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:03:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:04:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:04:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:04:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:04:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:04:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:05:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:06:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:06:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:07:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:07:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:08:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:09:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-10 05:10:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 05:10:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 05:10:09 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-10 05:10:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-10 05:10:09 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-10 05:10:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:10:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:10:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:11:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:11:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:12:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:12:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:14:20 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-10 05:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:14:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:15:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 05:16:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:16:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:16:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:17:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:17:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:18:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:18:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:18:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:18:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:19:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:19:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 05:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:20:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:21:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:22:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:22:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:23:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:24:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:25:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:25:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:25:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:25:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:26:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:26:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:28:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:29:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:30:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:30:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:30:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:31:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:33:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:33:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:34:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:34:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:34:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:36:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:36:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:37:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:42:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:42:16 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-06-10 05:42:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 05:42:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:42:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:42:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:42:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:43:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:43:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:43:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:43:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:43:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:44:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:44:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:44:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:44:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:44:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:44:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:44:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:45:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:45:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:45:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:45:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:45:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:46:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:46:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:46:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:47:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:47:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:47:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:48:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:48:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:49:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:50:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:50:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:50:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:50:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:50:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:51:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:51:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:51:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:51:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:51:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:52:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:52:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:34 --> 404 Page Not Found: 16/10000
ERROR - 2021-06-10 05:52:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:52:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 05:53:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:53:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:53:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:53:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:53:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:53:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:54:36 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-10 05:54:51 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-10 05:55:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:55:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:55:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:55:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:55:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:56:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:56:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:56:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:57:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:57:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:57:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:58:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:58:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:58:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:58:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 05:59:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:59:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:59:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:59:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 05:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 05:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:00:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:00:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:00:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:00:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:01:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:01:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:01:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:01:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:02:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:02:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:02:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:03:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:04:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:04:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:04:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:04:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:05:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:05:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:05:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:07:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:08:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:08:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:08:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:08:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:08:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:08:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:08:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:09:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:09:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 06:09:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:09:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:09:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:10:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:10:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:10:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 06:10:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:10:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:10:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:10:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:10:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:11:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:11:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:11:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:12:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:12:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:12:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:12:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:12:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:12:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:13:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:13:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:13:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:13:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:15:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 06:15:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:15:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:15:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:15:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:15:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 06:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:16:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:16:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:16:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:16:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:16:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:17:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:17:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:17:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:17:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:18:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:18:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:18:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:18:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:19:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:19:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:20:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:20:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:20:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:20:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:20:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:21:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:21:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:22:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:23:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:23:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:25:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:26:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:26:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:27:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:27:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:28:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:28:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:28:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:28:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:28:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:28:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:29:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:31:28 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-10 06:31:36 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-10 06:32:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:32:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:32:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:32:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:33:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:33:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:33:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:34:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:34:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:34:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:34:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:35:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:35:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 06:38:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:40:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:40:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:40:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:41:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:41:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:41:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:41:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:42:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:42:14 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-10 06:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:42:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:42:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:43:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:43:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:44:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:44:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:44:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:44:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:44:42 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-10 06:44:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:45:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:45:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:46:18 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/cityt16): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 279
ERROR - 2021-06-10 06:46:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:47:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:47:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:47:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:48:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:49:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:51:54 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-10 06:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:53:05 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-10 06:54:18 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-10 06:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:55:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:57:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 06:57:58 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-10 06:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 06:59:09 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-10 06:59:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:00:20 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-10 07:00:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 07:00:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:01:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:01:37 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-10 07:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 07:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 07:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 07:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 07:04:11 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-10 07:04:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:05:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 07:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:08:50 --> 404 Page Not Found: Periodical/gxsfxyxb-zxsh201605012
ERROR - 2021-06-10 07:09:42 --> 404 Page Not Found: Heji/yijianjiesuo
ERROR - 2021-06-10 07:09:51 --> 404 Page Not Found: M/a
ERROR - 2021-06-10 07:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:09:54 --> 404 Page Not Found: S/index
ERROR - 2021-06-10 07:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:10:32 --> 404 Page Not Found: A/1516810316618944
ERROR - 2021-06-10 07:10:32 --> 404 Page Not Found: 20170312/n483109786.shtml
ERROR - 2021-06-10 07:10:32 --> 404 Page Not Found: I/index
ERROR - 2021-06-10 07:10:42 --> 404 Page Not Found: Downinfo/28510.html
ERROR - 2021-06-10 07:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:12:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:18:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 07:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:22:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:29:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:29:37 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-10 07:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:34:23 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-10 07:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:36:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:36:52 --> 404 Page Not Found: English/index
ERROR - 2021-06-10 07:37:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:37:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:39:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:41:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:52:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 07:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:55:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 07:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 07:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:02:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:04:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:07:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 08:07:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 08:07:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 08:07:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 08:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:08:11 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-10 08:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:19:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:20:26 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-10 08:20:28 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-10 08:20:46 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 08:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:22:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 08:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:27:10 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-10 08:27:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:29:40 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-10 08:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:31:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 08:31:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 08:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:32:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 08:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 08:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 08:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:44:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:44:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:44:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:44:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:45:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:45:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:45:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:46:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:46:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 08:48:40 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-10 08:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:54:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 08:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 08:58:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:02:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 09:03:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 09:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:23:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 09:23:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 09:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:33:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:37:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:38:24 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-10 09:39:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:40:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:41:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:42:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 09:48:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-10 09:48:07 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-10 09:48:08 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-10 09:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:50:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:50:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:55:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:55:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:55:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:55:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:56:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:56:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:56:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:56:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:57:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 09:58:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:58:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:58:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 09:58:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:59:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 09:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:01:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:02:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:02:03 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-10 10:02:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:03:55 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-10 10:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:07:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:09:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:09:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:09:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:09:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:10:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 10:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:11:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:11:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:11:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:11:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:13:48 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-10 10:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:15:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:16:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:16:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:16:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:16:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:16:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:17:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 10:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:23:37 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-06-10 10:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:26:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:28:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:29:22 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-10 10:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:31:11 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-10 10:31:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:32:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:32:59 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-10 10:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:34:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:38:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:40:10 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-10 10:40:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:42:04 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-10 10:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:47:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:48:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 10:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:52:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:53:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:54:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 10:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:54:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 10:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:55:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:55:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 10:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:56:09 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 10:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:57:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 10:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 10:59:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 11:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:08:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 11:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 11:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 11:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 11:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:16:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:17:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:17:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:17:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:18:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:19:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:20:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:20:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 11:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:22:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 11:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:23:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 11:24:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:25:29 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 11:26:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:27:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:30:21 --> 404 Page Not Found: 1/all
ERROR - 2021-06-10 11:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:30:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 11:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:34:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 11:34:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 11:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:48:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 11:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:54:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 11:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:55:53 --> 404 Page Not Found: Images/Nxrs4tAtO
ERROR - 2021-06-10 11:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:57:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 11:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Www20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Wwwxuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Www_xuanhao_net20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Wwwxuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Xuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Xuanhao_net20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Xuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Xuanhao20210607rar/index
ERROR - 2021-06-10 11:58:41 --> 404 Page Not Found: Www20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Wwwxuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Www_xuanhao_net20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Wwwxuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhao_net20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhao20210607targz/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Www20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Wwwxuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Www_xuanhao_net20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Wwwxuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhao_net20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Xuanhao20210607zip/index
ERROR - 2021-06-10 11:58:42 --> 404 Page Not Found: Www2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Wwwxuanhaonet2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Www_xuanhao_net2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Wwwxuanhaonet2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhaonet2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhao_net2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhaonet2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhao2021-06-07rar/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Www2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Wwwxuanhaonet2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Www_xuanhao_net2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Wwwxuanhaonet2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhaonet2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhao_net2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhaonet2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Xuanhao2021-06-07targz/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Www2021-06-07zip/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Wwwxuanhaonet2021-06-07zip/index
ERROR - 2021-06-10 11:58:43 --> 404 Page Not Found: Www_xuanhao_net2021-06-07zip/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Wwwxuanhaonet2021-06-07zip/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhaonet2021-06-07zip/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhao_net2021-06-07zip/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhaonet2021-06-07zip/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhao2021-06-07zip/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Www20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Wwwxuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Www_xuanhao_net20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Wwwxuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhao_net20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhaonet20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Xuanhao20210607rar/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Www20210607targz/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Wwwxuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Www_xuanhao_net20210607targz/index
ERROR - 2021-06-10 11:58:44 --> 404 Page Not Found: Wwwxuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhao_net20210607targz/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhaonet20210607targz/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhao20210607targz/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Www20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Wwwxuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Www_xuanhao_net20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Wwwxuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhao_net20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhaonet20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: Xuanhao20210607zip/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: 20210607rar/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: 20210607targz/index
ERROR - 2021-06-10 11:58:45 --> 404 Page Not Found: 20210607zip/index
ERROR - 2021-06-10 11:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 11:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 11:59:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:00:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:00:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:01:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 12:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:03:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:03:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:03:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 12:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:04:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:07:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:09:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 12:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:11:05 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-10 12:11:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 12:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:17:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:19:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:24:27 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-10 12:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 12:24:29 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-10 12:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:27:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:27:57 --> 404 Page Not Found: Indexasp/index
ERROR - 2021-06-10 12:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:28:47 --> 404 Page Not Found: Yangshi/jianbian.html
ERROR - 2021-06-10 12:28:48 --> 404 Page Not Found: Detailasp/index
ERROR - 2021-06-10 12:28:59 --> 404 Page Not Found: Contribute/sso
ERROR - 2021-06-10 12:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:30:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:31:25 --> 404 Page Not Found: Gczx66/Bxw0udj.html
ERROR - 2021-06-10 12:31:31 --> 404 Page Not Found: Jobs/street-search--stickrtime-15.htm
ERROR - 2021-06-10 12:31:32 --> 404 Page Not Found: Member/Login
ERROR - 2021-06-10 12:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:31:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:32:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 12:32:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:32:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 12:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:35:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 12:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:38:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:46:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 12:46:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 12:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:48:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 12:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:57:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:57:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 12:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 12:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:05:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:05:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:05:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:07:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:08:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:08:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:08:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:09:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:09:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:09:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:10:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 13:10:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:10:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:11:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:11:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:11:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:11:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:12:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:12:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:12:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:12:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:13:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:13:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:13:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:14:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:15:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 13:15:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:15:21 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session254e54b7f62979f5ab964963668b64bc3b06e64a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-10 13:15:21 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionb232233b11e6797793056b84578397343e1f9cf9): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-10 13:15:21 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session9a0b18331ae7eeb7bb11e19fb54a15bcd73791b4): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-10 13:15:21 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionad8987da90b37bf0f666baa152bd6f00c4ddf635): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-10 13:15:21 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session01bd6441a067360081c8ba7a89a5edf3b8e99fac): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-10 13:15:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:15:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:17:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:17:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:17:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:17:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:18:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:18:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:19:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:20:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:20:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:21:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:22:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:22:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:23:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:25:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 13:26:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:28:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:29:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:30:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:31:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:31:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:31:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:31:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:31:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:31:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:32:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:32:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:32:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:32:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:33:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:33:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:33:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:33:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:33:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:33:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:34:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:34:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:34:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:34:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:35:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:35:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:38:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:39:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:39:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:40:13 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-06-10 13:40:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:40:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:41:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:41:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:41:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:41:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:42:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:42:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:42:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:42:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:42:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:43:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:43:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:43:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:43:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:44:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:44:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:44:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:45:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:45:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:45:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:45:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:45:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:46:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:46:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:46:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:47:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:47:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:47:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:47:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:47:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:47:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:48:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:48:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:48:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:48:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:49:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:49:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:49:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:49:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:49:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 13:50:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:50:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:50:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:50:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:50:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:51:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:51:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:51:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:51:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:51:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:51:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:52:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:52:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:53:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:53:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:54:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:55:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:55:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:55:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:55:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:55:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:56:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:56:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:56:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:57:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:58:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:58:47 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-10 13:58:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 13:58:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:59:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 13:59:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:02:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:02:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:03:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:04:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:07:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:08:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:08:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:09:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:10:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:10:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:11:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:11:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:11:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:12:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:12:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:12:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:12:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:13:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:13:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:13:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:13:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:13:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:14:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:15:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:16:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:16:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:16:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:16:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:17:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:18:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:18:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:18:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:19:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:19:25 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-10 14:19:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:20:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:20:46 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-10 14:20:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:20:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 14:20:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 14:21:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:22:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:22:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:23:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:23:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:23:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:24:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:24:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 14:24:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:25:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:25:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:25:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:26:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:26:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:26:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:26:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:27:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:27:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:27:20 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-10 14:27:21 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-10 14:27:23 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-10 14:27:29 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-10 14:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:27:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:28:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:29:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:30:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:30:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:30:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:30:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:31:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:32:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:34:17 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-10 14:34:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:34:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:35:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:35:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:36:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:36:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:36:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:37:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:38:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:38:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:39:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:39:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:40:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:41:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:42:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:42:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 14:42:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 14:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:46:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:46:13 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-10 14:46:23 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 14:47:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:49:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:49:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:49:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:50:28 --> 404 Page Not Found: 16/10000
ERROR - 2021-06-10 14:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 14:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:55:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:55:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:59:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 14:59:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 14:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:00:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:01:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:02:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:03:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:03:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:03:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:05:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:07:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:08:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:14:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:14:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:18:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:18:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:18:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:19:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:20:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:22:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:24:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:24:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:24:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:28:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:29:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:29:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:29:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:30:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:31:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:31:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:33:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:35:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:35:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:35:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:35:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:37:39 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-10 15:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:38:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:38:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:42:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:42:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 15:43:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:44:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:46:25 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 279
ERROR - 2021-06-10 15:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:49:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:52:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:53:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:54:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:54:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:54:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 15:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 15:55:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:56:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 15:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 15:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:00:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 16:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:04:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:04:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:05:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:07:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:10:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:12:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:15:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:15:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:18:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:20:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:22:47 --> 404 Page Not Found: 1/10000
ERROR - 2021-06-10 16:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:24:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:26:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:27:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:29:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:29:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:29:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:31:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:33:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:36:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:41:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:42:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:42:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:42:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:44:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:45:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 16:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:46:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 16:46:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:48:32 --> 404 Page Not Found: City/index
ERROR - 2021-06-10 16:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:58:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 16:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 16:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:01:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:02:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 17:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:08:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:09:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:09:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:11:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:12:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:15:38 --> 404 Page Not Found: Env/index
ERROR - 2021-06-10 17:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:16:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:17:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:19:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 17:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:22:58 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 17:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:25:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:28:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:29:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:29:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:29:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 17:30:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:30:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:30:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:30:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:30:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:30:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:30:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:30:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:31:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:32:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:32:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:37:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:44:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 17:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:46:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:50:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:51:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 17:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 17:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:01:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 18:01:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 18:01:00 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-10 18:01:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 18:01:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-10 18:01:02 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-10 18:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:03:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:04:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:05:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:08:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:08:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:11:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:11:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:15:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:16:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:18:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:18:33 --> 404 Page Not Found: Menuhtml/index
ERROR - 2021-06-10 18:18:34 --> 404 Page Not Found: GponForm/diag_FORM
ERROR - 2021-06-10 18:18:42 --> 404 Page Not Found: Console/login
ERROR - 2021-06-10 18:18:42 --> 404 Page Not Found: Console/login
ERROR - 2021-06-10 18:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:18:58 --> 404 Page Not Found: Console/LoginForm.jsp
ERROR - 2021-06-10 18:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:20:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:23:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:24:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:24:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:25:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:28:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:28:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:30:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:31:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:31:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:36:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:38:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:39:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:39:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 18:39:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 18:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:39:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:40:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:40:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:42:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:42:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:43:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:44:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:45:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:45:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:45:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:45:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:48:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:48:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:50:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 18:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:51:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:51:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:51:34 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-10 18:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:54:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 18:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:57:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 18:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 18:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:00:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:01:40 --> 404 Page Not Found: All/index
ERROR - 2021-06-10 19:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:01:59 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-10 19:03:06 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-10 19:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:05:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:06:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:06:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:06:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:06:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:11:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:15:27 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-06-10 19:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:16:43 --> 404 Page Not Found: Article/info
ERROR - 2021-06-10 19:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:20:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:24:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 19:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:25:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:30:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:31:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:43:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:43:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:43:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:43:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:43:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:43:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:43:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:46:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:51:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:51:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 19:51:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 19:52:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 19:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:55:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 19:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 19:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:01:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 20:01:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:10:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:11:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:11:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 20:12:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:12:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:14:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:16:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:16:42 --> 404 Page Not Found: 16/10000
ERROR - 2021-06-10 20:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:19:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 20:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:21:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:21:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:22:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:26:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:28:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:30:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:31:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:31:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:32:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:41:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:49:55 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-10 20:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-10 20:50:13 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 20:50:14 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-10 20:50:15 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-10 20:50:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-10 20:50:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-10 20:50:16 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-10 20:50:16 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-10 20:50:16 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-10 20:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:51:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 20:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:52:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 20:53:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 20:55:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 20:58:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 20:58:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 20:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 21:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:00:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:11:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:15:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:16:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:18:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 21:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:20:28 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-10 21:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:28:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:30:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:34:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 21:34:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 21:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:36:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:39:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:39:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 21:42:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:42:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:42:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:42:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 21:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:48:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 21:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 21:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 21:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:53:51 --> 404 Page Not Found: City/1
ERROR - 2021-06-10 21:53:51 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-10 21:53:53 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-10 21:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 21:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:03:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 22:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:05:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:06:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:06:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:07:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:08:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:08:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:09:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:10:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:11:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 22:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:11:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:15:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:20:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:21:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 22:21:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 22:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:23:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:29:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:30:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:30:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:33:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:34:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:35:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:36:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:36:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:39:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 22:39:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 22:39:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 22:39:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 22:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:41:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:42:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:42:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 22:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:42:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:43:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 22:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:44:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:44:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:45:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:45:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 22:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:46:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:47:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 22:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:47:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 22:47:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:47:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:48:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:49:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:49:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:54:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:54:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:55:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:55:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:57:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 22:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:59:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 22:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:01:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 23:03:29 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-06-10 23:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:04:29 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-06-10 23:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:07:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 23:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:17:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:20:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:23:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:24:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:25:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:25:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:30:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:32:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 23:32:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 23:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:33:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:35:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:35:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:35:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:39:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:39:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:41:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:41:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:44:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-10 23:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:44:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:44:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-10 23:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:49:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-10 23:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:51:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-10 23:51:23 --> 404 Page Not Found: Actuator/health
ERROR - 2021-06-10 23:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:54:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-10 23:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-10 23:59:57 --> 404 Page Not Found: Robotstxt/index
