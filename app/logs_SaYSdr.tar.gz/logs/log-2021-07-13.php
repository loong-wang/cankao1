<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-13 00:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:05:41 --> 404 Page Not Found: City/2
ERROR - 2021-07-13 00:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:11:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 00:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:13:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 00:13:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 00:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:16:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 00:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:21:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:24:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 00:24:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 00:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:32:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 00:32:15 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-07-13 00:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:37:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 00:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:39:30 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 00:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:41:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 00:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:46:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 00:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 00:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:47:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 00:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:49:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 00:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:51:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 00:52:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 00:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 00:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:08:35 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 01:08:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 01:08:37 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 01:08:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 01:08:38 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 01:08:38 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 01:08:38 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 01:08:38 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 01:08:38 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 01:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:12:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 01:12:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 01:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 01:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:13:57 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-13 01:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:14:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 01:14:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 01:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:23:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 01:24:48 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-13 01:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:30:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 01:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:32:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 01:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:45:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 01:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:48:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 01:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:49:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 01:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:54:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 01:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 01:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:00:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 02:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:01:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 02:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:02:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 02:02:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 02:04:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 02:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:08:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 02:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:08:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 02:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:09:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 02:09:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 02:09:12 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 02:09:12 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 02:09:12 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 02:09:12 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 02:09:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 02:09:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 02:09:15 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 02:09:15 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 02:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:14:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 02:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:21:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 02:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:22:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 02:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:22:56 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-13 02:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:25:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 02:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:33:56 --> 404 Page Not Found: Env/index
ERROR - 2021-07-13 02:36:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 02:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:38:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 02:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:41:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 02:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 02:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:43:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 02:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:47:39 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-13 02:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 02:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:00:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 03:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 03:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:09:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 03:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:15:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 03:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:20:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 03:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:23:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 03:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:25:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 03:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:31:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 03:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:35:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 03:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 03:40:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 03:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 03:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 03:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:47:24 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-07-13 03:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:52:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 03:52:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 03:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:53:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 03:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 03:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:00:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-13 04:01:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 04:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:03:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 04:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 04:04:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 04:04:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 04:04:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 04:04:06 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 04:04:06 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 04:04:06 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 04:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:09:51 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-13 04:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:14:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 04:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:17:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 04:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:18:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 04:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:24:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 04:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:28:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 04:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:33:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 04:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:34:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 04:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:35:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 04:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:38:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 04:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:53:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 04:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:57:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 04:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 04:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:03:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 05:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:07:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:08:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 05:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:09:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:09:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:10:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:20:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:21:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:23:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:37:56 --> 404 Page Not Found: City/17
ERROR - 2021-07-13 05:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:41:29 --> 404 Page Not Found: City/1
ERROR - 2021-07-13 05:41:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 05:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:43:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 05:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 05:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:49:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 05:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 05:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 05:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:56:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 05:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 05:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 06:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 06:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:01:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 06:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:07:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 06:07:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 06:07:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 06:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 06:11:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 06:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:16:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 06:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:17:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 06:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:20:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 06:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:25:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 06:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:28:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 06:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:34:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 06:34:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 06:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:49:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 06:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:51:36 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-07-13 06:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:57:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 06:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:58:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 06:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 06:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:04:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 07:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:20:41 --> 404 Page Not Found: English/index
ERROR - 2021-07-13 07:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:29:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:29:28 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-13 07:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:35:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 07:35:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 07:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:39:14 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-07-13 07:39:14 --> 404 Page Not Found: Otc/index
ERROR - 2021-07-13 07:39:15 --> 404 Page Not Found: Wap/trading
ERROR - 2021-07-13 07:39:15 --> 404 Page Not Found: Wap/trading
ERROR - 2021-07-13 07:39:18 --> 404 Page Not Found: admin/Index/index
ERROR - 2021-07-13 07:39:19 --> 404 Page Not Found: Web/api
ERROR - 2021-07-13 07:39:20 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-07-13 07:39:21 --> 404 Page Not Found: M/ticker
ERROR - 2021-07-13 07:39:22 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-07-13 07:39:22 --> 404 Page Not Found: Index/login
ERROR - 2021-07-13 07:39:24 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-07-13 07:39:25 --> 404 Page Not Found: Legal/currency
ERROR - 2021-07-13 07:39:26 --> 404 Page Not Found: M/allticker
ERROR - 2021-07-13 07:39:27 --> 404 Page Not Found: S_api/basic
ERROR - 2021-07-13 07:39:28 --> 404 Page Not Found: Api/user
ERROR - 2021-07-13 07:39:30 --> 404 Page Not Found: Account/login
ERROR - 2021-07-13 07:39:30 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-07-13 07:39:30 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-07-13 07:39:30 --> 404 Page Not Found: Home/Bind
ERROR - 2021-07-13 07:39:31 --> 404 Page Not Found: V1/management
ERROR - 2021-07-13 07:39:35 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-07-13 07:39:35 --> 404 Page Not Found: Xy/index
ERROR - 2021-07-13 07:39:36 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-07-13 07:39:36 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-07-13 07:39:36 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-07-13 07:39:38 --> 404 Page Not Found: S_api/basic
ERROR - 2021-07-13 07:39:38 --> 404 Page Not Found: Static/local
ERROR - 2021-07-13 07:39:38 --> 404 Page Not Found: GetLocale/index
ERROR - 2021-07-13 07:39:38 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-07-13 07:39:38 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-07-13 07:39:39 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-07-13 07:39:39 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-07-13 07:39:40 --> 404 Page Not Found: Data/json
ERROR - 2021-07-13 07:39:40 --> 404 Page Not Found: Infe/rest
ERROR - 2021-07-13 07:39:41 --> 404 Page Not Found: N/news
ERROR - 2021-07-13 07:39:41 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-07-13 07:39:42 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-07-13 07:39:42 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-07-13 07:39:45 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-07-13 07:39:54 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-07-13 07:39:55 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-07-13 07:39:56 --> 404 Page Not Found: Ajax/index
ERROR - 2021-07-13 07:39:56 --> 404 Page Not Found: Ajax/index
ERROR - 2021-07-13 07:39:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 07:39:59 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-07-13 07:40:01 --> 404 Page Not Found: Front/User
ERROR - 2021-07-13 07:40:02 --> 404 Page Not Found: Api/index
ERROR - 2021-07-13 07:40:02 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-07-13 07:40:03 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-07-13 07:40:04 --> 404 Page Not Found: Api/uploads
ERROR - 2021-07-13 07:40:05 --> 404 Page Not Found: Ws/index
ERROR - 2021-07-13 07:40:07 --> 404 Page Not Found: admin//index
ERROR - 2021-07-13 07:40:08 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-07-13 07:40:08 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-07-13 07:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:40:10 --> 404 Page Not Found: Api/v
ERROR - 2021-07-13 07:40:13 --> 404 Page Not Found: Api/Index
ERROR - 2021-07-13 07:40:13 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-07-13 07:40:14 --> 404 Page Not Found: Home/Get
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Home/login
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Homes/index
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Homes/index
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Api/site
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Api/stock
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Api/wallet
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: H5/index
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Wap/Api
ERROR - 2021-07-13 07:40:20 --> 404 Page Not Found: Wap/Api
ERROR - 2021-07-13 07:40:21 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-07-13 07:40:21 --> 404 Page Not Found: Sign/index
ERROR - 2021-07-13 07:40:24 --> 404 Page Not Found: Index/index
ERROR - 2021-07-13 07:40:24 --> 404 Page Not Found: Api/message
ERROR - 2021-07-13 07:40:24 --> 404 Page Not Found: Api/product
ERROR - 2021-07-13 07:40:26 --> 404 Page Not Found: Api/currency
ERROR - 2021-07-13 07:40:29 --> 404 Page Not Found: Api/apps
ERROR - 2021-07-13 07:40:29 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-07-13 07:40:29 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-07-13 07:40:29 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-07-13 07:40:30 --> 404 Page Not Found: Api/v1
ERROR - 2021-07-13 07:40:30 --> 404 Page Not Found: Loan/index
ERROR - 2021-07-13 07:40:31 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Api/exclude
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Api/user
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 07:40:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 07:40:33 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 07:40:34 --> 404 Page Not Found: Index/api
ERROR - 2021-07-13 07:40:37 --> 404 Page Not Found: Im/in
ERROR - 2021-07-13 07:40:37 --> 404 Page Not Found: Api/common
ERROR - 2021-07-13 07:40:37 --> 404 Page Not Found: Api/user
ERROR - 2021-07-13 07:40:37 --> 404 Page Not Found: Api/config-init
ERROR - 2021-07-13 07:40:37 --> 404 Page Not Found: Portal/index
ERROR - 2021-07-13 07:40:37 --> 404 Page Not Found: Content/favicon.ico
ERROR - 2021-07-13 07:40:40 --> 404 Page Not Found: Site/info
ERROR - 2021-07-13 07:40:46 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-07-13 07:40:47 --> 404 Page Not Found: M/index
ERROR - 2021-07-13 07:40:52 --> 404 Page Not Found: Api/mobile
ERROR - 2021-07-13 07:40:53 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-07-13 07:40:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 07:40:57 --> 404 Page Not Found: Api/index
ERROR - 2021-07-13 07:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:41:54 --> 404 Page Not Found: City/1
ERROR - 2021-07-13 07:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:44:57 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-13 07:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:48:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 07:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:48:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 07:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:52:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 07:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 07:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:01:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 08:01:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 08:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 08:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:03:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 08:05:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 08:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:12:21 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-13 08:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:14:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 08:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:18:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 08:18:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 08:19:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 08:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:20:46 --> 404 Page Not Found: Env/index
ERROR - 2021-07-13 08:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:22:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 08:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:37:45 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 08:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 08:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 08:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:39:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 08:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:43:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 08:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:44:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 08:44:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 08:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:47:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 08:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:50:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 08:51:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 08:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 08:51:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 08:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 08:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:02:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 09:02:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 09:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:03:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 09:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:06:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 09:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:08:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 09:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:14:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 09:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:23:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 09:24:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 09:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:29:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 09:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:31:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 09:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 09:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:32:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 09:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:46:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 09:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 09:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:00:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:07:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:08:36 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-13 10:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:10:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:12:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:12:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:14:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:19:04 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 10:19:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 10:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:20:49 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-13 10:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:29:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:39:57 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 10:39:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 10:39:59 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-07-13 10:40:00 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 10:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:47:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:52:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:55:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 10:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:58:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 10:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 10:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:59:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 10:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 10:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 11:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:12:30 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-13 11:13:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:15:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:18:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:20:31 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-13 11:20:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 11:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:22:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:22:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:30:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:39:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 11:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:47:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 11:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:51:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 11:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:57:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 11:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 11:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:04:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 12:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:07:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:08:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:10:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 12:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:10:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 12:10:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:11:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 12:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:13:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:14:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:15:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 12:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:24:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 12:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:30:06 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-13 12:30:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 12:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:36:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:37:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:37:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:38:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 12:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:40:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 12:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:48:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 12:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 12:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:53:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-13 12:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 12:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:02:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 13:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:07:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 13:09:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 13:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:10:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 13:11:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 13:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:12:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 13:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:15:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 13:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:17:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 13:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:26:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 13:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:27:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:28:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:28:19 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 13:28:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 13:29:20 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 13:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:30:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:32:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 13:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:34:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 13:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:35:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:38:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 13:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 13:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:50:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 13:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:50:53 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-07-13 13:51:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 13:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:52:31 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-07-13 13:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:53:10 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-07-13 13:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 13:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:01:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 14:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:02:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 14:02:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 14:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:04:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 14:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:05:56 --> 404 Page Not Found: English/index
ERROR - 2021-07-13 14:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 14:19:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 14:19:36 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 14:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:32:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 14:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:40:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 14:40:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 14:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:42:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 14:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 14:52:03 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 14:52:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 14:52:05 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 14:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:53:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 14:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:54:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 14:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:56:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 14:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:56:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 14:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 14:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:03:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:09:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 15:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:12:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:15:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:18:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:23:30 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-13 15:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:25:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:26:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:33:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:35:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 15:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:42:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:44:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:44:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 15:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:47:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:47:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:48:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:48:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:50:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:51:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 15:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:51:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 15:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 15:59:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 15:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:00:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 16:00:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:01:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 16:01:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:08:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 16:08:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 16:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 16:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:16:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:18:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 16:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:22:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:23:42 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-13 16:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:28:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:29:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:37:58 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 16:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 16:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:39:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 16:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:40:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 16:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:41:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:42:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 16:43:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:47:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 16:47:18 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 16:47:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 16:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:50:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 16:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:57:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 16:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 16:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:00:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 17:01:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 17:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:07:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 17:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:10:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 17:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:13:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:15:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:15:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:15:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:16:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:16:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 17:17:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:17:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:17:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:17:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:21:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 17:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:22:59 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-13 17:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 17:30:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 17:32:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 17:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:33:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 17:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:37:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 17:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:54:50 --> 404 Page Not Found: Article/view
ERROR - 2021-07-13 17:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:56:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 17:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:56:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 17:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 17:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:58:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 17:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 17:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:08:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 18:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:09:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:14:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:15:40 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 18:15:41 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 18:15:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 18:15:43 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 18:15:43 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 18:16:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 18:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:18:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:18:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 18:18:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 18:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:21:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:23:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:24:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:27:30 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-13 18:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 18:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:33:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 18:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:36:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 18:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:37:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:45:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:48:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:53:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:58:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:58:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 18:59:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 18:59:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:01:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:04:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:09:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 19:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:13:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:16:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:17:15 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-07-13 19:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:19:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:19:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:20:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:20:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:20:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:21:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:25:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:25:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:25:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:25:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:25:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:25:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:22 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 19:26:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:26:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:26:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:27:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 19:28:04 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 19:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:32:12 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-13 19:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:33:43 --> 404 Page Not Found: Login/index
ERROR - 2021-07-13 19:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:36:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 19:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:38:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 19:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:39:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:40:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 19:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:57:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:58:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 19:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 19:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:00:48 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-13 20:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:07:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:07:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:07:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 20:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:08:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 20:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:18:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 20:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:32:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:44:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 20:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:53:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 20:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:55:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:56:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 20:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 20:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 21:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:01:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:01:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:11:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 21:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:14:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:14:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:14:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:15:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 21:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:18:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:24:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 21:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:25:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 21:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:33:03 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-13 21:33:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 21:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 21:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:45:30 --> 404 Page Not Found: Env/index
ERROR - 2021-07-13 21:45:30 --> 404 Page Not Found: Envdevlocal/index
ERROR - 2021-07-13 21:45:31 --> 404 Page Not Found: Envprodlocal/index
ERROR - 2021-07-13 21:45:32 --> 404 Page Not Found: Envproductionlocal/index
ERROR - 2021-07-13 21:45:32 --> 404 Page Not Found: Envlocal/index
ERROR - 2021-07-13 21:45:33 --> 404 Page Not Found: Envstage/index
ERROR - 2021-07-13 21:45:33 --> 404 Page Not Found: Envlive/index
ERROR - 2021-07-13 21:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:47:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 21:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:50:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 21:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 21:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:00:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 22:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:02:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:02:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:02:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:03:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:03:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:03:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:03:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:07:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 22:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:12:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 22:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:13:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 22:13:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:13:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:14:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 22:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:15:24 --> 404 Page Not Found: City/index
ERROR - 2021-07-13 22:15:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 22:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:17:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 22:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:23:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:25:02 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-13 22:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:26:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 22:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:29:44 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-13 22:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:31:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:31:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:32:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:32:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:33:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:33:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:34:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:35:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:35:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:36:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:36:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 22:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:50:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 22:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:52:10 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 22:52:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 22:52:11 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-13 22:52:12 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-13 22:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:54:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 22:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 22:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:01:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 23:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:03:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 23:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:04:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 23:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:05:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 23:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:17:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 23:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:19:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 23:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 23:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:20:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:20:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:21:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:22:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:22:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:23:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:24:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:25:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 23:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:29:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 23:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:29:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 23:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:32:28 --> 404 Page Not Found: City/17
ERROR - 2021-07-13 23:32:28 --> 404 Page Not Found: City/17
ERROR - 2021-07-13 23:32:28 --> 404 Page Not Found: City/17
ERROR - 2021-07-13 23:32:51 --> 404 Page Not Found: City/17
ERROR - 2021-07-13 23:33:19 --> 404 Page Not Found: City/17
ERROR - 2021-07-13 23:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:33:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 23:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:42:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 23:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:47:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-13 23:47:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-13 23:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:48:25 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-07-13 23:48:25 --> 404 Page Not Found: City/16
ERROR - 2021-07-13 23:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:49:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 23:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:52:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 23:53:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-13 23:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:55:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-13 23:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:58:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-13 23:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-13 23:59:39 --> 404 Page Not Found: Robotstxt/index
