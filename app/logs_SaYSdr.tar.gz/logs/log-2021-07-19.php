<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-19 00:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:05:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:10:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:11:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:11:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:14:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:16:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 00:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:18:52 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-19 00:18:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:21:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:22:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:23:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:24:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:32:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:34:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:35:15 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 00:35:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 00:35:15 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 00:35:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 00:35:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 00:35:15 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 00:35:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 00:35:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 00:35:17 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-19 00:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:39:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:39:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:42:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:44:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 00:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:45:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:45:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 00:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:48:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:56:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 00:58:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 00:59:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:02:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 01:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:04:02 --> 404 Page Not Found: Pv/spa122.cfg
ERROR - 2021-07-19 01:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:09:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:12:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:26:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:26:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:29:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 01:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:35:22 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 01:35:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 01:36:00 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 01:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:38:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:39:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 01:39:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 01:39:36 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 01:39:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 01:39:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 01:39:36 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 01:39:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 01:39:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 01:39:38 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 01:39:38 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 01:39:38 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 01:39:39 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 01:39:39 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 01:39:39 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 01:39:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 01:39:39 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 01:39:39 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 01:39:39 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-19 01:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:42:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:43:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:43:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:43:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:51:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:51:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 01:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 01:59:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:01:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-19 02:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 02:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 02:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:04:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 02:04:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 02:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:07:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:15:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:16:11 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2021-07-19 02:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:25:12 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2021-07-19 02:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:27:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:29:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:33:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:38:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:45:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:46:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:47:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:48:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:48:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:48:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:49:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:51:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:51:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:51:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:52:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:52:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:53:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:54:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:55:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:56:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:57:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:57:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:57:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:57:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:58:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 02:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 02:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:00:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:00:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:01:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 03:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:01:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:02:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 03:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:08:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:09:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:10:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:11:21 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-19 03:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:16:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:19:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:19:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:20:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:20:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:20:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 03:20:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 03:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:22:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:22:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:22:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 03:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:25:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:25:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:27:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:33:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:33:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:33:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:36:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:38:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:43:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:43:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:44:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:44:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:46:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:49:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:53:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:54:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:54:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:54:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 03:54:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:56:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:56:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:56:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:57:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:58:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 03:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 03:59:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:00:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-19 04:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 04:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:02:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 04:03:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 04:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:03:56 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-19 04:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:11:40 --> 404 Page Not Found: Article/view
ERROR - 2021-07-19 04:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:18:34 --> 404 Page Not Found: Manager/text
ERROR - 2021-07-19 04:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:25:33 --> 404 Page Not Found: admin//index
ERROR - 2021-07-19 04:25:39 --> 404 Page Not Found: Manager/index
ERROR - 2021-07-19 04:25:43 --> 404 Page Not Found: admin/Content/sitetree
ERROR - 2021-07-19 04:25:47 --> 404 Page Not Found: Simpla/index
ERROR - 2021-07-19 04:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:31:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 04:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:32:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 04:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:39:00 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-19 04:39:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:39:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 04:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:47:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:48:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:50:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:50:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:51:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:52:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 04:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:57:29 --> 404 Page Not Found: City/1
ERROR - 2021-07-19 04:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 04:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:10:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:11:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:11:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:12:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:16:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 05:21:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 05:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 05:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:23:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:24:49 --> 404 Page Not Found: admin//index
ERROR - 2021-07-19 05:24:50 --> 404 Page Not Found: Login/index
ERROR - 2021-07-19 05:24:57 --> 404 Page Not Found: admin//index
ERROR - 2021-07-19 05:24:59 --> 404 Page Not Found: Loginaspx/index
ERROR - 2021-07-19 05:25:00 --> 404 Page Not Found: Login/index
ERROR - 2021-07-19 05:25:01 --> 404 Page Not Found: Login/index
ERROR - 2021-07-19 05:25:03 --> 404 Page Not Found: Loginhtml/index
ERROR - 2021-07-19 05:25:04 --> 404 Page Not Found: Security/login
ERROR - 2021-07-19 05:25:05 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-07-19 05:25:07 --> 404 Page Not Found: admin/Loginhtml/index
ERROR - 2021-07-19 05:25:08 --> 404 Page Not Found: CMSPages/logon.aspx
ERROR - 2021-07-19 05:25:09 --> 404 Page Not Found: Loginasp/index
ERROR - 2021-07-19 05:25:12 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-07-19 05:25:15 --> 404 Page Not Found: Users/sign_in
ERROR - 2021-07-19 05:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:25:17 --> 404 Page Not Found: Loginaspx/index
ERROR - 2021-07-19 05:25:18 --> 404 Page Not Found: Auth/login
ERROR - 2021-07-19 05:25:20 --> 404 Page Not Found: admin/Auth/login
ERROR - 2021-07-19 05:25:21 --> 404 Page Not Found: Account/Login
ERROR - 2021-07-19 05:25:22 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-07-19 05:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:31:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:38:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:46:38 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-19 05:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:47:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 05:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:48:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 05:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 05:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:01:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:02:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 06:02:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 06:02:00 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 06:02:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 06:02:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 06:02:00 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 06:02:01 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 06:02:02 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 06:02:02 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 06:02:02 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 06:02:02 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 06:02:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 06:02:02 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 06:02:02 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 06:02:03 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 06:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 06:09:43 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 06:09:43 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 06:09:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 06:09:44 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 06:09:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 06:09:45 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 06:09:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 06:09:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 06:09:45 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 06:09:46 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 06:09:47 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 06:09:47 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 06:09:47 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 06:09:47 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 06:09:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 06:09:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 06:09:48 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 06:09:48 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 06:09:48 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 06:09:48 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-19 06:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 06:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:21:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:22:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:23:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:37:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:39:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:44:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:45:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:46:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:47:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 06:47:45 --> 404 Page Not Found: Blog/index
ERROR - 2021-07-19 06:47:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:52:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 06:52:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 06:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 06:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:02:28 --> 404 Page Not Found: Manager/html
ERROR - 2021-07-19 07:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:08:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 07:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:19:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 07:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:27:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 07:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:32:59 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-19 07:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:37:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 07:39:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 07:39:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 07:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:47:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 07:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:53:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 07:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:56:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 07:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 07:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:05:54 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 08:06:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:11:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:13:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 08:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:14:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:21:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:21:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:21:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:23:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 08:23:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 08:24:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:28:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:30:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:32:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 08:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:42:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 08:43:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 08:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:54:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 08:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:56:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 08:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 08:59:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 09:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:08:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:15:13 --> 404 Page Not Found: Article/view
ERROR - 2021-07-19 09:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:25:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 09:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:27:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:28:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:30:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:30:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:36:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:39:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:40:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:42:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:44:54 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-19 09:46:15 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-19 09:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:46:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:46:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:47:08 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-19 09:47:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:47:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:47:33 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-19 09:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:48:23 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-19 09:48:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:49:17 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-19 09:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:49:45 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-19 09:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:50:36 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-19 09:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:51:49 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-19 09:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:53:34 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-19 09:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:55:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 09:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:56:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:56:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:57:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:57:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 09:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 09:59:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 09:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:02:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:03:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:05:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:06:26 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-19 10:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:06:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:12:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:12:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:13:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:13:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:20:08 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-19 10:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:23:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 10:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:27:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:40:40 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-07-19 10:40:40 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-07-19 10:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:42:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 10:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:45:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 10:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:47:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 10:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:55:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 10:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 10:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:03:23 --> 404 Page Not Found: Include/taglib
ERROR - 2021-07-19 11:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:08:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:11:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 11:12:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:21:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:21:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 11:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:22:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:23:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:24:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:24:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:25:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:25:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 11:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:26:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:26:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:13 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-19 11:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:27:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:27:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 11:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:27:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:27:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:27:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:27:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:29:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:30:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:30:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:30:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:30:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:30:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:31:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:31:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:31:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:32:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:32:26 --> 404 Page Not Found: Order/index
ERROR - 2021-07-19 11:32:29 --> 404 Page Not Found: Vod-read-id-2628html/index
ERROR - 2021-07-19 11:32:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:32:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:32:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:32:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:33:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:34:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:34:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:34:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:34:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:34:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:34:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:35:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:35:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:35:27 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-07-19 11:36:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:36:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:37:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:37:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:37:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:37:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:38:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:39:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:39:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:40:19 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-19 11:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:40:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:40:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:40:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:41:23 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-19 11:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:41:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:42:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:43:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:43:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:44:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 11:44:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:44:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 11:46:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:47:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:48:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 11:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:51:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:51:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:52:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:52:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 11:52:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:53:41 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-19 11:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:56:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:56:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:57:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:58:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:59:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 11:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 11:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:00:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:00:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:01:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:01:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 12:01:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:02:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:02:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:03:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:04:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 12:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:05:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:05:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:06:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:06:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:06:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:07:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:07:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:11:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:13:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 12:13:30 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-19 12:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:14:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:15:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:21:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:22:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 12:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:31:32 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 12:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:33:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 12:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:34:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 12:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:35:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 12:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:52:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:52:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:53:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 12:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 12:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:56:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 12:56:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 12:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:57:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 12:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 12:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:01:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 13:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:06:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:07:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:08:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:09:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:09:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 13:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:11:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:12:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:12:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:13:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:14:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:14:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:14:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:18:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:19:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:19:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:20:08 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 13:20:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:20:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:20:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:21:21 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 13:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:21:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 13:21:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 13:21:23 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-19 13:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:22:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:25:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:25:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:25:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:26:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 13:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:27:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:28:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:28:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:28:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:30:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:30:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:32:04 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-19 13:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:34:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 13:35:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:35:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:36:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:38:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 13:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:38:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:42:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:45:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:46:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:47:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:48:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:48:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:50:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:51:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:52:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:52:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:52:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:52:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 13:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:58:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 13:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 13:58:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 13:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:02:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 14:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:03:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:08:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:08:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 14:08:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 14:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:09:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:16:40 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 14:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:18:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 14:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:20:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 14:20:52 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-19 14:20:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:21:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:25:07 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-19 14:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:29:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:31:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 14:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 14:35:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 14:36:00 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 14:36:01 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 14:36:01 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-19 14:36:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:46:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 14:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:48:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:48:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:49:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:49:23 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-19 14:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 14:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:55:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:56:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 14:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:56:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:57:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 14:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:58:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 14:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 14:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 14:59:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:00:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:03:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:04:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 15:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:06:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:15:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 15:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:16:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:18:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 15:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:18:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:19:47 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-19 15:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:20:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:21:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:22:31 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-19 15:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:30:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:36:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:36:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 15:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:37:32 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-19 15:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:37:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:43:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:45:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:46:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 15:46:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:46:52 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-19 15:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:52:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:55:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 15:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:58:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 15:58:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 15:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 15:59:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:00:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 16:00:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:03:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:10:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:11:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:12:01 --> 404 Page Not Found: City/10
ERROR - 2021-07-19 16:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:12:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:12:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:12:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:15:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:27:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:31:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:33:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:34:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:35:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:35:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:36:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:36:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:37:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:37:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:37:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:41:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:42:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:42:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:44:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:45:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:45:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:46:12 --> 404 Page Not Found: Article/info
ERROR - 2021-07-19 16:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:46:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:47:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:47:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:47:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:48:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:48:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:48:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:49:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:49:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:49:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:50:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 16:50:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:51:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:52:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:52:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:52:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:52:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:54:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:55:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:56:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:56:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:56:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:57:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:57:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:57:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 16:58:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:59:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 16:59:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 16:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:00:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:02:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:02:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:03:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:03:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:04:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:04:26 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 17:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:05:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:07:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:08:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:10:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:12:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:13:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:15:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:17:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:17:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:18:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:20:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:20:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 17:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:24:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 17:25:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:25:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:26:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:26:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:27:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:27:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:28:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 17:28:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:34:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 17:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:35:07 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-07-19 17:35:25 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-19 17:35:26 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-19 17:35:27 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-07-19 17:35:38 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-19 17:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:37:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 17:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 17:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:46:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 17:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:46:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:46:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 17:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:47:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:47:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:48:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:48:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:48:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:49:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:49:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:50:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:50:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:50:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:51:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:51:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:51:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 17:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 17:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:53:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 17:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 17:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:05:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:05:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:06:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:06:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:08:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:08:08 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-19 18:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:11:23 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-19 18:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:12:50 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-19 18:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:13:51 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-19 18:15:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:15:48 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-19 18:16:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:16:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:17:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 18:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:21:33 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-19 18:21:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 18:21:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 18:21:36 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 18:21:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 18:21:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 18:21:37 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 18:21:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 18:21:39 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 18:21:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 18:21:39 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 18:21:39 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 18:21:57 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-19 18:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:23:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:25:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:31:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:31:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:34:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:36:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:36:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:36:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:37:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:37:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:40:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 18:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:44:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:44:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:46:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:46:58 --> 404 Page Not Found: 16/10000
ERROR - 2021-07-19 18:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:56:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:56:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 18:58:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:58:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:59:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 18:59:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 18:59:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:03:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:04:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:05:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:06:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:11:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:12:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:13:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:13:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:14:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:15:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 19:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:24:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:24:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:26:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:30:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:30:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:31:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:31:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:34:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:35:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:35:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:36:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-19 19:36:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-19 19:37:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 19:37:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 19:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:38:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:38:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:41:02 --> 404 Page Not Found: Shell/index
ERROR - 2021-07-19 19:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:41:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:41:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:42:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:42:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 19:43:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:44:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:45:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:48:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:49:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 19:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:52:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 19:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:53:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 19:53:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 19:53:50 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-19 19:53:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-19 19:53:50 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 19:53:50 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-19 19:53:50 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-19 19:53:51 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-19 19:53:52 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-19 19:53:53 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-19 19:53:53 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-19 19:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:56:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 19:56:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 19:56:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 19:56:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 19:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:57:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:57:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 19:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 19:59:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 19:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:01:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 20:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 20:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 20:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 20:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:06:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:07:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:08:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:09:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:09:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:10:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:13:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:13:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:16:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:16:59 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-19 20:17:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:27:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:29:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:35:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:37:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:37:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:41:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:41:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:42:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:43:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:43:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:44:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:44:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:45:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:46:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:46:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:47:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:47:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:47:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:49:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:49:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:50:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:50:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:51:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:51:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:52:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:52:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:53:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:53:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:53:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:54:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:54:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:54:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:55:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:55:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:56:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:57:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:57:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:57:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 20:58:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 20:58:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 20:59:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:00:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:00:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:01:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:01:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:02:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:02:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:03:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:03:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:04:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:04:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:05:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:05:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:06:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:06:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:07:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:07:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:07:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:08:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:08:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:08:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:09:01 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-19 21:09:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-19 21:09:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:09:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 21:09:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:09:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:09:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:10:07 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-19 21:10:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:11:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:11:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:12:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:12:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:12:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:13:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:14:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:14:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:15:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:15:20 --> 404 Page Not Found: English/index
ERROR - 2021-07-19 21:15:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 21:15:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 21:15:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:16:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:17:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:17:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:18:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:18:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:19:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:20:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:20:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:21:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:21:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:22:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:22:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:23:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:24:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:24:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:24:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:24:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:28:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:29:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 21:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:30:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:35:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:35:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:36:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:37:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:37:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:37:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:38:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:38:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 21:39:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:41:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:42:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:44:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:45:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:55:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 21:55:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:56:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 21:57:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 21:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 21:59:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:03:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 22:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:04:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:04:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:04:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:04:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:06:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 22:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:08:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:08:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 22:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:11:44 --> 404 Page Not Found: City/10
ERROR - 2021-07-19 22:11:49 --> 404 Page Not Found: City/1
ERROR - 2021-07-19 22:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:15:12 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-19 22:15:13 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-19 22:16:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:16:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:16:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-19 22:16:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-19 22:17:19 --> 404 Page Not Found: City/index
ERROR - 2021-07-19 22:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:18:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-19 22:18:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-19 22:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:19:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:19:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:19:35 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-19 22:19:35 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-19 22:19:35 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-19 22:19:35 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-19 22:19:37 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-19 22:19:37 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-19 22:19:37 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-07-19 22:19:37 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-19 22:19:37 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-19 22:19:37 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-19 22:19:39 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-19 22:19:40 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-19 22:19:40 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-19 22:19:52 --> 404 Page Not Found: City/2
ERROR - 2021-07-19 22:19:54 --> 404 Page Not Found: City/16
ERROR - 2021-07-19 22:19:57 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-19 22:19:58 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-19 22:20:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:21:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:22:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:22:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:23:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 22:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:25:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:26:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 22:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:33:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:34:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:34:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:34:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:34:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:34:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 22:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:35:30 --> 404 Page Not Found: City/15
ERROR - 2021-07-19 22:35:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:35:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 22:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:35:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 22:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:41:45 --> 404 Page Not Found: City/1
ERROR - 2021-07-19 22:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:42:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:43:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:43:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 22:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:52:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 22:53:09 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2021-07-19 22:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:57:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 22:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 22:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:03:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 23:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:04:47 --> 404 Page Not Found: Env/index
ERROR - 2021-07-19 23:05:39 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-19 23:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:06:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 23:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:11:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 23:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:19:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 23:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:27:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 23:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:28:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 23:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 23:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:29:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 23:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 23:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:30:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 23:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:31:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 23:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 23:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:34:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 23:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:35:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 23:36:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 23:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:42:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 23:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:42:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 23:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:44:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 23:44:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 23:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:46:06 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-19 23:46:39 --> 404 Page Not Found: Cgi-bin/frame_html
ERROR - 2021-07-19 23:46:41 --> 404 Page Not Found: Portal/MvcDefaultSheet.jsp
ERROR - 2021-07-19 23:46:46 --> 404 Page Not Found: Ctr_DD/Detail
ERROR - 2021-07-19 23:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:46:54 --> 404 Page Not Found: Play/38142-4-4.html
ERROR - 2021-07-19 23:46:55 --> 404 Page Not Found: A/20150405
ERROR - 2021-07-19 23:47:00 --> 404 Page Not Found: Home/DownLoad
ERROR - 2021-07-19 23:47:00 --> 404 Page Not Found: Public/PhotoList.aspx
ERROR - 2021-07-19 23:47:01 --> 404 Page Not Found: Tag/%E5%8C%85%E8%A3%85%E5%88%B6%E4%BD%9C
ERROR - 2021-07-19 23:47:02 --> 404 Page Not Found: Vod/type
ERROR - 2021-07-19 23:47:03 --> 404 Page Not Found: Ldzc/-
ERROR - 2021-07-19 23:47:14 --> 404 Page Not Found: About/5
ERROR - 2021-07-19 23:47:14 --> 404 Page Not Found: Saasoscp/enterprise
ERROR - 2021-07-19 23:47:15 --> 404 Page Not Found: Saasoscp/enterprise
ERROR - 2021-07-19 23:47:17 --> 404 Page Not Found: Tyt_new/Admin
ERROR - 2021-07-19 23:47:18 --> 404 Page Not Found: 2011-07/1114630_2.shtml
ERROR - 2021-07-19 23:47:22 --> 404 Page Not Found: admin/DbOrderShip/index
ERROR - 2021-07-19 23:47:22 --> 404 Page Not Found: Oa/sys
ERROR - 2021-07-19 23:47:25 --> 404 Page Not Found: Indexaspx/index
ERROR - 2021-07-19 23:47:27 --> 404 Page Not Found: Vod/type
ERROR - 2021-07-19 23:47:30 --> 404 Page Not Found: V2/attach
ERROR - 2021-07-19 23:47:30 --> 404 Page Not Found: Article/Index
ERROR - 2021-07-19 23:47:42 --> 404 Page Not Found: ProOrderArea/NewProOrderEQ
ERROR - 2021-07-19 23:47:42 --> 404 Page Not Found: Manhua/3870
ERROR - 2021-07-19 23:47:42 --> 404 Page Not Found: ComList/businessPending
ERROR - 2021-07-19 23:47:42 --> 404 Page Not Found: Download/53248711
ERROR - 2021-07-19 23:47:53 --> 404 Page Not Found: Xf/newhouse_xx_xi.html
ERROR - 2021-07-19 23:48:02 --> 404 Page Not Found: Workflow/request
ERROR - 2021-07-19 23:48:04 --> 404 Page Not Found: Order/orderDesc
ERROR - 2021-07-19 23:48:08 --> 404 Page Not Found: Newweb/payMent
ERROR - 2021-07-19 23:48:08 --> 404 Page Not Found: Picture-yn-2012-01-04-1984489html/index
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: Searchjspx/index
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: Transportation/Edit
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: 2017/hotels
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: Vod/type
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: NetflowMission/normalMission
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: Page135html/index
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: Productsaspx/index
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: Xmkhtadmin/FDL
ERROR - 2021-07-19 23:48:15 --> 404 Page Not Found: Wf/icity
ERROR - 2021-07-19 23:48:17 --> 404 Page Not Found: 21/0507
ERROR - 2021-07-19 23:48:18 --> 404 Page Not Found: S/Paper.aspx
ERROR - 2021-07-19 23:48:18 --> 404 Page Not Found: Entry-add/invite-entry.do
ERROR - 2021-07-19 23:48:21 --> 404 Page Not Found: Business/order
ERROR - 2021-07-19 23:48:21 --> 404 Page Not Found: 63/linda
ERROR - 2021-07-19 23:48:24 --> 404 Page Not Found: Courses/gx_jyts_010
ERROR - 2021-07-19 23:48:24 --> 404 Page Not Found: SQMISTrackingPrintpage/index
ERROR - 2021-07-19 23:48:24 --> 404 Page Not Found: ISV/LogisticSupply
ERROR - 2021-07-19 23:48:24 --> 404 Page Not Found: User/DocTransferOne
ERROR - 2021-07-19 23:48:24 --> 404 Page Not Found: Km/review
ERROR - 2021-07-19 23:48:24 --> 404 Page Not Found: PreLessionPPT/standard
ERROR - 2021-07-19 23:48:25 --> 404 Page Not Found: Workflow/request
ERROR - 2021-07-19 23:48:25 --> 404 Page Not Found: Manage/FaPiao
ERROR - 2021-07-19 23:48:25 --> 404 Page Not Found: Vod/play
ERROR - 2021-07-19 23:48:26 --> 404 Page Not Found: admin/Goods/readd
ERROR - 2021-07-19 23:48:39 --> 404 Page Not Found: Lr/chatpre.aspx
ERROR - 2021-07-19 23:48:41 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-07-19 23:48:41 --> 404 Page Not Found: ProductCust/594534-330800.html
ERROR - 2021-07-19 23:48:42 --> 404 Page Not Found: News/index
ERROR - 2021-07-19 23:48:42 --> 404 Page Not Found: Indexaspx/index
ERROR - 2021-07-19 23:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:48:48 --> 404 Page Not Found: Previewhtml/index
ERROR - 2021-07-19 23:48:49 --> 404 Page Not Found: MgtOrders/Print5.aspx
ERROR - 2021-07-19 23:48:50 --> 404 Page Not Found: Shop/shopbrand.html
ERROR - 2021-07-19 23:48:50 --> 404 Page Not Found: Indexdo/index
ERROR - 2021-07-19 23:48:51 --> 404 Page Not Found: Cn/pro-pd.asp
ERROR - 2021-07-19 23:49:10 --> 404 Page Not Found: Card/index
ERROR - 2021-07-19 23:49:10 --> 404 Page Not Found: Vod-list-id-204-pg-26-order--by--class-0-year-0-letter--area--lang-html/index
ERROR - 2021-07-19 23:49:11 --> 404 Page Not Found: View/index186427.html
ERROR - 2021-07-19 23:49:11 --> 404 Page Not Found: List/index42.html
ERROR - 2021-07-19 23:49:14 --> 404 Page Not Found: User-center/uc-order
ERROR - 2021-07-19 23:49:16 --> 404 Page Not Found: Tv/66644
ERROR - 2021-07-19 23:49:21 --> 404 Page Not Found: Cnewsasp/index
ERROR - 2021-07-19 23:49:22 --> 404 Page Not Found: H-col-106html/index
ERROR - 2021-07-19 23:49:24 --> 404 Page Not Found: Content/detail
ERROR - 2021-07-19 23:49:25 --> 404 Page Not Found: Heroaspx/index
ERROR - 2021-07-19 23:49:25 --> 404 Page Not Found: Vod/type
ERROR - 2021-07-19 23:49:28 --> 404 Page Not Found: 2798html/index
ERROR - 2021-07-19 23:49:28 --> 404 Page Not Found: Scwlt/wlyw
ERROR - 2021-07-19 23:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:49:31 --> 404 Page Not Found: Wangpaizhuanye/20160202
ERROR - 2021-07-19 23:49:33 --> 404 Page Not Found: 144166html/index
ERROR - 2021-07-19 23:49:34 --> 404 Page Not Found: Ubbxoa/14565.html
ERROR - 2021-07-19 23:49:35 --> 404 Page Not Found: View/index186273.html
ERROR - 2021-07-19 23:49:36 --> 404 Page Not Found: Workflow/request
ERROR - 2021-07-19 23:49:36 --> 404 Page Not Found: Vod/type
ERROR - 2021-07-19 23:49:37 --> 404 Page Not Found: Search/index
ERROR - 2021-07-19 23:49:39 --> 404 Page Not Found: Vod/type
ERROR - 2021-07-19 23:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:50:16 --> 404 Page Not Found: Guanye/shouce.asp
ERROR - 2021-07-19 23:50:18 --> 404 Page Not Found: Dance/topic
ERROR - 2021-07-19 23:50:21 --> 404 Page Not Found: Productasp/index
ERROR - 2021-07-19 23:50:35 --> 404 Page Not Found: Index/article
ERROR - 2021-07-19 23:50:36 --> 404 Page Not Found: School/5
ERROR - 2021-07-19 23:50:36 --> 404 Page Not Found: Bdfd/5sigxqtp.html
ERROR - 2021-07-19 23:50:37 --> 404 Page Not Found: Admin/Purchase
ERROR - 2021-07-19 23:50:51 --> 404 Page Not Found: 0754wd_7html/index
ERROR - 2021-07-19 23:50:51 --> 404 Page Not Found: Zjxx/pingmian
ERROR - 2021-07-19 23:50:53 --> 404 Page Not Found: Home/about
ERROR - 2021-07-19 23:50:54 --> 404 Page Not Found: News/showList
ERROR - 2021-07-19 23:51:16 --> 404 Page Not Found: Html/oumeirenti
ERROR - 2021-07-19 23:51:17 --> 404 Page Not Found: Gallery/its-troop-straight-away
ERROR - 2021-07-19 23:51:18 --> 404 Page Not Found: Go/7e5a04c80d.html
ERROR - 2021-07-19 23:51:19 --> 404 Page Not Found: List/index
ERROR - 2021-07-19 23:51:20 --> 404 Page Not Found: Chaosmen-prentice/index
ERROR - 2021-07-19 23:51:26 --> 404 Page Not Found: Ywkd/tjxw
ERROR - 2021-07-19 23:51:28 --> 404 Page Not Found: Forum/thread-11052131-1-1.html
ERROR - 2021-07-19 23:51:33 --> 404 Page Not Found: 2016/0717
ERROR - 2021-07-19 23:51:40 --> 404 Page Not Found: List_7htm/index
ERROR - 2021-07-19 23:51:43 --> 404 Page Not Found: Play/205628-1-1.html
ERROR - 2021-07-19 23:51:44 --> 404 Page Not Found: Zhonghe/main.asp
ERROR - 2021-07-19 23:51:44 --> 404 Page Not Found: Ti/118706
ERROR - 2021-07-19 23:51:44 --> 404 Page Not Found: News/article
ERROR - 2021-07-19 23:51:48 --> 404 Page Not Found: Td/18
ERROR - 2021-07-19 23:51:49 --> 404 Page Not Found: Lishijiemi/337879-1-1.html
ERROR - 2021-07-19 23:51:51 --> 404 Page Not Found: Kaochang/user
ERROR - 2021-07-19 23:51:51 --> 404 Page Not Found: XmUiForWeb20/xmebid
ERROR - 2021-07-19 23:51:52 --> 404 Page Not Found: Txt/93394_40446946.html
ERROR - 2021-07-19 23:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:52:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-19 23:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:54:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-19 23:54:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 23:54:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-19 23:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:58:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-19 23:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-19 23:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-19 23:59:53 --> 404 Page Not Found: Robotstxt/index
