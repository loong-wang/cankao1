<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-08 00:00:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 00:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 00:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 00:11:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 00:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 00:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 00:39:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 00:46:18 --> 404 Page Not Found: 404/index.html
ERROR - 2022-02-08 00:46:18 --> 404 Page Not Found: 404/index.html
ERROR - 2022-02-08 00:48:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 00:48:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 00:58:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 01:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 01:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 01:13:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 01:15:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 01:22:57 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-02-08 01:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 01:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:29:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:29:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:30:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:30:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:30:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:30:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 01:31:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:31:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:35:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 01:39:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:40:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:40:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 01:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 01:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 01:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 01:59:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 02:01:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 02:02:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 02:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:13:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 02:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:17:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 02:28:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 02:28:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 02:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:39:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 02:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:40:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 02:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 02:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:02:52 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-02-08 03:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:18:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 03:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 03:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 03:27:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 03:28:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 03:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 03:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-08 03:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 03:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 04:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 04:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 04:19:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 04:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 04:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 04:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 04:57:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 04:58:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 04:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 05:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 05:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 05:17:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 05:18:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 05:19:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:20:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:23:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:25:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:27:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 05:28:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:49:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:54:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:58:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 05:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:01:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 06:01:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 06:03:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 06:05:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 06:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:41:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 06:48:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 06:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 06:56:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 07:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 07:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 07:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 07:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:26:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 07:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:34:40 --> 404 Page Not Found: City/1
ERROR - 2022-02-08 07:34:43 --> 404 Page Not Found: City/1
ERROR - 2022-02-08 07:34:43 --> 404 Page Not Found: City/1
ERROR - 2022-02-08 07:35:12 --> 404 Page Not Found: City/1
ERROR - 2022-02-08 07:35:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 07:35:40 --> 404 Page Not Found: City/1
ERROR - 2022-02-08 07:36:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 07:38:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 07:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 07:54:26 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-08 07:54:27 --> 404 Page Not Found: Member/space
ERROR - 2022-02-08 07:54:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 07:54:28 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 07:54:28 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 07:54:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:29 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-08 07:54:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 07:54:30 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 07:54:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 08:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 08:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:10:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-08 08:11:01 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-08 08:11:01 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-08 08:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 08:11:01 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:11:02 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-08 08:11:03 --> 404 Page Not Found: Member/space
ERROR - 2022-02-08 08:11:03 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 08:11:04 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 08:11:05 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 08:11:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:07 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-08 08:11:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:11:07 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 08:11:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:33:43 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2022-02-08 08:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:42:52 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-08 08:42:52 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-08 08:42:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 08:42:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Member/space
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 08:42:53 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 08:42:54 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 08:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:55 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-08 08:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:42:55 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 08:42:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 08:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 08:59:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:00:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:01:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:01:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:01:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:01:24 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-02-08 09:01:28 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-02-08 09:04:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 09:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:05:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:10:25 --> 404 Page Not Found: Inc/check_sql.asp
ERROR - 2022-02-08 09:10:25 --> 404 Page Not Found: Seeyon/common
ERROR - 2022-02-08 09:10:25 --> 404 Page Not Found: Label/ajax
ERROR - 2022-02-08 09:10:25 --> 404 Page Not Found: Tmui/tmui
ERROR - 2022-02-08 09:10:25 --> 404 Page Not Found: Xui/common
ERROR - 2022-02-08 09:10:25 --> 404 Page Not Found: Js/player
ERROR - 2022-02-08 09:10:25 --> 404 Page Not Found: Templets/default
ERROR - 2022-02-08 09:10:26 --> 404 Page Not Found: Js/err.html
ERROR - 2022-02-08 09:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:14:59 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-08 09:15:00 --> 404 Page Not Found: Member/space
ERROR - 2022-02-08 09:15:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:15:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:15:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:15:00 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 09:15:00 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 09:15:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:15:02 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-08 09:15:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:15:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:15:02 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 09:15:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:19:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:19:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:25:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:27:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:27:37 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-08 09:27:42 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-08 09:27:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:27:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:27:46 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-08 09:27:47 --> 404 Page Not Found: Member/space
ERROR - 2022-02-08 09:27:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:51 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:27:52 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 09:27:56 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 09:27:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:57 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-08 09:27:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:27:59 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 09:27:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 09:31:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:32:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 09:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 09:43:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 09:50:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 09:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 09:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:00:04 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-02-08 10:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:04:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:13:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:13:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:15:31 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-08 10:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:16:44 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-08 10:17:19 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-08 10:18:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-08 10:19:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:26:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 10:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 10:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 10:50:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 10:54:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:56:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 10:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:03:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 11:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:06:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:06:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 11:11:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:33:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:37:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 11:37:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 11:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:47:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 11:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 11:58:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 12:01:37 --> 404 Page Not Found: App/views
ERROR - 2022-02-08 12:01:38 --> 404 Page Not Found: App/views
ERROR - 2022-02-08 12:01:38 --> 404 Page Not Found: App/views
ERROR - 2022-02-08 12:04:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:05:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:11:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:13:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:17:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:20:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 12:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 12:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:30:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:30:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:31:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:32:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:32:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:33:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:33:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:33:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 12:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 12:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 12:53:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:53:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:54:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:55:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:57:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:58:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 12:58:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:58:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 12:58:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:00:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:11:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:12:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:12:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 13:12:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 13:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:23:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:24:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 13:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 13:55:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 13:56:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 13:57:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 13:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 13:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 14:02:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 14:02:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 14:02:33 --> Severity: error --> 11111 test 1
ERROR - 2022-02-08 14:04:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 14:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 14:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 14:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:24:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:24:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:26:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:26:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:36:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:47:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:47:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 14:47:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:48:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 14:48:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 14:48:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:49:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:49:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:50:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:51:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:52:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 14:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 14:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:58:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 14:58:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:00:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:01:01 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-08 15:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:01:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 15:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:06:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:08:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:08:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:11:25 --> Severity: error --> 11111 test 1
ERROR - 2022-02-08 15:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:28:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 15:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:36:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:37:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:38:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:39:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:40:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:41:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:44:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:49:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 15:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 15:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:58:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 15:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:02:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:03:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:05:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:05:39 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-02-08 16:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:15:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:18:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:18:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:19:04 --> Severity: error --> 11111 test 1
ERROR - 2022-02-08 16:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:20:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:25:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 16:27:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:29:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:34:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:36:37 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-08 16:36:37 --> 404 Page Not Found: Member/space
ERROR - 2022-02-08 16:36:37 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:37 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:36:39 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 16:36:39 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 16:36:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:40 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-08 16:36:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:41 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-08 16:36:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:36:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:37:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:38:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:50:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:52:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:56:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 16:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 16:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 16:59:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 16:59:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 17:02:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:05:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 17:05:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 17:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 17:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:08:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 17:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:11:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 17:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:15:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 17:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:22:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 17:22:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 17:22:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 17:22:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 17:25:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:30:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:46:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:47:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:47:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:49:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:51:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 17:58:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 18:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 18:02:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:02:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:02:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:02:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 18:20:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 18:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 18:31:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 18:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 18:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 18:42:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 18:42:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:42:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:42:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:42:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 18:42:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 18:43:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:43:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 18:43:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 18:44:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 18:47:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 19:00:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 19:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 19:15:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:16:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:16:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 19:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:17:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 19:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 19:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:28:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 19:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 19:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:53:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 19:56:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 19:56:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 20:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 20:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 20:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 20:19:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 20:19:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 20:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 20:40:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 21:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 21:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 21:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 21:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 21:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:13:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 21:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:16:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 21:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:26:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 21:39:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 21:39:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 21:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 21:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 22:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 22:07:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 22:11:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 22:12:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 22:14:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 22:14:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 22:14:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 22:15:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 22:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:17:42 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-02-08 22:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 22:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:44:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 22:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 22:51:57 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-02-08 22:56:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 23:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 23:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 23:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 23:04:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 23:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 23:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-08 23:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:33:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:37:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:37:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-08 23:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 23:39:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:39:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-08 23:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-08 23:46:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-08 23:57:00 --> 404 Page Not Found: Robotstxt/index
