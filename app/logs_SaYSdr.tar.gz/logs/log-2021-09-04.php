<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-04 00:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 00:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 00:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:27:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 00:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 00:58:10 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-04 01:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:04:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 01:06:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 01:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 01:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:10:32 --> 404 Page Not Found: Env/index
ERROR - 2021-09-04 01:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:11:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 01:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 01:11:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:12:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:12:38 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-09-04 01:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:13:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:13:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:13:13 --> 404 Page Not Found: City/16
ERROR - 2021-09-04 01:13:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 01:13:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 01:13:14 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-04 01:13:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 01:13:14 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 01:13:15 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 01:13:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 01:13:17 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 01:13:17 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-04 01:13:17 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-04 01:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:13:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 01:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:13:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:15:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 01:15:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 01:15:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:18:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 01:18:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 01:21:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 01:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:26:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:29:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:39:18 --> 404 Page Not Found: Env/index
ERROR - 2021-09-04 01:39:19 --> 404 Page Not Found: Core/.env
ERROR - 2021-09-04 01:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:39:26 --> 404 Page Not Found: App/.env
ERROR - 2021-09-04 01:39:27 --> 404 Page Not Found: Public/.env
ERROR - 2021-09-04 01:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:43:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:45:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:48:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:53:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:53:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 01:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 01:57:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 01:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:02:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 02:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:03:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 02:03:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 02:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:15:00 --> 404 Page Not Found: City/1
ERROR - 2021-09-04 02:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:17:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 02:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:18:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 02:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 02:35:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 02:35:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 02:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 02:35:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 02:35:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 02:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:54:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 02:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 02:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:04:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 03:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:11:36 --> 404 Page Not Found: City/index
ERROR - 2021-09-04 03:11:40 --> 404 Page Not Found: City/1
ERROR - 2021-09-04 03:11:43 --> 404 Page Not Found: City/10
ERROR - 2021-09-04 03:11:47 --> 404 Page Not Found: City/15
ERROR - 2021-09-04 03:11:51 --> 404 Page Not Found: City/16
ERROR - 2021-09-04 03:11:55 --> 404 Page Not Found: City/2
ERROR - 2021-09-04 03:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:14:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 03:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:17:04 --> 404 Page Not Found: City/10
ERROR - 2021-09-04 03:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:34:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 03:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:54:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 03:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 03:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-09-04 04:01:16 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-04 04:01:39 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-04 04:02:01 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-04 04:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:04:08 --> 404 Page Not Found: English/index
ERROR - 2021-09-04 04:04:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 04:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:21:16 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-04 04:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:28:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 04:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:38:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 04:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:45:18 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-04 04:45:48 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-04 04:45:52 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-04 04:46:17 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-04 04:47:38 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-04 04:47:43 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-04 04:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:48:10 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-04 04:48:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 04:48:34 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-04 04:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:48:57 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-04 04:49:20 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-04 04:50:08 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-04 04:50:39 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-04 04:51:04 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-04 04:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:52:23 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-04 04:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:53:30 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-04 04:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:55:17 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-04 04:55:40 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-04 04:56:04 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-04 04:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 04:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:17:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 05:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:27:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 05:33:31 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-04 05:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:36:58 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-04 05:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:37:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 05:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 05:43:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 05:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:43:02 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-04 05:43:32 --> 404 Page Not Found: Env/index
ERROR - 2021-09-04 05:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:47:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 05:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 05:51:43 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-04 05:51:44 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-04 05:51:45 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-04 05:51:45 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 05:51:45 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 05:51:45 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 05:51:45 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-04 05:51:45 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-04 05:51:45 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-04 05:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 05:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:21:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:25:52 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-04 06:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:28:00 --> 404 Page Not Found: Cart/index
ERROR - 2021-09-04 06:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:33:42 --> 404 Page Not Found: English/index
ERROR - 2021-09-04 06:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 06:59:28 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-04 07:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:03:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 07:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:27:18 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-04 07:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 07:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 07:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 07:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:41:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 07:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:54:01 --> 404 Page Not Found: 1sql/index
ERROR - 2021-09-04 07:54:02 --> 404 Page Not Found: 123sql/index
ERROR - 2021-09-04 07:54:03 --> 404 Page Not Found: 2020sql/index
ERROR - 2021-09-04 07:54:04 --> 404 Page Not Found: 2021sql/index
ERROR - 2021-09-04 07:54:05 --> 404 Page Not Found: A_checkoutssql/index
ERROR - 2021-09-04 07:54:06 --> 404 Page Not Found: Administratorssql/index
ERROR - 2021-09-04 07:54:07 --> 404 Page Not Found: Adminsql/index
ERROR - 2021-09-04 07:54:08 --> 404 Page Not Found: Adminssql/index
ERROR - 2021-09-04 07:54:08 --> 404 Page Not Found: Apisql/index
ERROR - 2021-09-04 07:54:09 --> 404 Page Not Found: Asql/index
ERROR - 2021-09-04 07:54:10 --> 404 Page Not Found: Backsql/index
ERROR - 2021-09-04 07:54:11 --> 404 Page Not Found: Backtxt/index
ERROR - 2021-09-04 07:54:12 --> 404 Page Not Found: Backup/backup.sql
ERROR - 2021-09-04 07:54:12 --> 404 Page Not Found: Backup/bd.sql
ERROR - 2021-09-04 07:54:13 --> 404 Page Not Found: Backup/database.sql
ERROR - 2021-09-04 07:54:14 --> 404 Page Not Found: Backup/dbdump.sql
ERROR - 2021-09-04 07:54:15 --> 404 Page Not Found: Backup/shxuanhaonet.sql
ERROR - 2021-09-04 07:54:16 --> 404 Page Not Found: Backup/dump.sql
ERROR - 2021-09-04 07:54:17 --> 404 Page Not Found: Backup/localhost.sql
ERROR - 2021-09-04 07:54:18 --> 404 Page Not Found: Backup/mysql.sql
ERROR - 2021-09-04 07:54:19 --> 404 Page Not Found: Backup/order.sql
ERROR - 2021-09-04 07:54:19 --> 404 Page Not Found: Backup/orders.sql
ERROR - 2021-09-04 07:54:20 --> 404 Page Not Found: Backup/payment.sql
ERROR - 2021-09-04 07:54:21 --> 404 Page Not Found: Backup/payments.sql
ERROR - 2021-09-04 07:54:22 --> 404 Page Not Found: Backup/shop.sql
ERROR - 2021-09-04 07:54:23 --> 404 Page Not Found: Backup/xuanhao.sql
ERROR - 2021-09-04 07:54:24 --> 404 Page Not Found: Backups/order.sql
ERROR - 2021-09-04 07:54:25 --> 404 Page Not Found: Backups/orders.sql
ERROR - 2021-09-04 07:54:26 --> 404 Page Not Found: Backups/payment.sql
ERROR - 2021-09-04 07:54:27 --> 404 Page Not Found: Backups/payments.sql
ERROR - 2021-09-04 07:54:28 --> 404 Page Not Found: _backupsql/index
ERROR - 2021-09-04 07:54:30 --> 404 Page Not Found: Backupsql/index
ERROR - 2021-09-04 07:54:30 --> 404 Page Not Found: Backuptxt/index
ERROR - 2021-09-04 07:54:31 --> 404 Page Not Found: Backups/shop.sql
ERROR - 2021-09-04 07:54:32 --> 404 Page Not Found: Backupssql/index
ERROR - 2021-09-04 07:54:34 --> 404 Page Not Found: Backups/store.sql
ERROR - 2021-09-04 07:54:35 --> 404 Page Not Found: Backup/store.sql
ERROR - 2021-09-04 07:54:35 --> 404 Page Not Found: Basesql/index
ERROR - 2021-09-04 07:54:36 --> 404 Page Not Found: Bdsql/index
ERROR - 2021-09-04 07:54:39 --> 404 Page Not Found: Billingsql/index
ERROR - 2021-09-04 07:54:40 --> 404 Page Not Found: Bitcoinsql/index
ERROR - 2021-09-04 07:54:40 --> 404 Page Not Found: Cardsql/index
ERROR - 2021-09-04 07:54:41 --> 404 Page Not Found: Cardssql/index
ERROR - 2021-09-04 07:54:42 --> 404 Page Not Found: Checkoutsql/index
ERROR - 2021-09-04 07:54:43 --> 404 Page Not Found: Checkoutssql/index
ERROR - 2021-09-04 07:54:44 --> 404 Page Not Found: Configsql/index
ERROR - 2021-09-04 07:54:45 --> 404 Page Not Found: Credit_cardsql/index
ERROR - 2021-09-04 07:54:46 --> 404 Page Not Found: Creditcardsql/index
ERROR - 2021-09-04 07:54:47 --> 404 Page Not Found: Credit_cardssql/index
ERROR - 2021-09-04 07:54:47 --> 404 Page Not Found: Creditcardssql/index
ERROR - 2021-09-04 07:54:48 --> 404 Page Not Found: Database/shxuanhaonet.sql
ERROR - 2021-09-04 07:54:49 --> 404 Page Not Found: Database/order.sql
ERROR - 2021-09-04 07:54:50 --> 404 Page Not Found: Database/orders.sql
ERROR - 2021-09-04 07:54:51 --> 404 Page Not Found: Database/payment.sql
ERROR - 2021-09-04 07:54:52 --> 404 Page Not Found: Database/payments.sql
ERROR - 2021-09-04 07:54:53 --> 404 Page Not Found: Database/shop.sql
ERROR - 2021-09-04 07:54:54 --> 404 Page Not Found: Database/xuanhao.sql
ERROR - 2021-09-04 07:54:56 --> 404 Page Not Found: Databasesql/index
ERROR - 2021-09-04 07:54:56 --> 404 Page Not Found: Database/store.sql
ERROR - 2021-09-04 07:54:57 --> 404 Page Not Found: Datasql/index
ERROR - 2021-09-04 07:54:58 --> 404 Page Not Found: Datatxt/index
ERROR - 2021-09-04 07:54:59 --> 404 Page Not Found: Datenbankensql/index
ERROR - 2021-09-04 07:55:00 --> 404 Page Not Found: Dbasesql/index
ERROR - 2021-09-04 07:55:01 --> 404 Page Not Found: Dbasetxt/index
ERROR - 2021-09-04 07:55:02 --> 404 Page Not Found: Db/backup.sql
ERROR - 2021-09-04 07:55:03 --> 404 Page Not Found: Db_backupsql/index
ERROR - 2021-09-04 07:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:55:04 --> 404 Page Not Found: Dbbackup/store.sql
ERROR - 2021-09-04 07:55:05 --> 404 Page Not Found: Db/bd.sql
ERROR - 2021-09-04 07:55:06 --> 404 Page Not Found: Db/database.sql
ERROR - 2021-09-04 07:55:07 --> 404 Page Not Found: Db/dbdump.sql
ERROR - 2021-09-04 07:55:08 --> 404 Page Not Found: Db/shxuanhaonet.sql
ERROR - 2021-09-04 07:55:09 --> 404 Page Not Found: Dbdumpsql/index
ERROR - 2021-09-04 07:55:10 --> 404 Page Not Found: Db/dump.sql
ERROR - 2021-09-04 07:55:11 --> 404 Page Not Found: Db/localhost.sql
ERROR - 2021-09-04 07:55:12 --> 404 Page Not Found: Db_mysqlsql/index
ERROR - 2021-09-04 07:55:12 --> 404 Page Not Found: Db/mysql.sql
ERROR - 2021-09-04 07:55:13 --> 404 Page Not Found: Db/order.sql
ERROR - 2021-09-04 07:55:14 --> 404 Page Not Found: Db/orders.sql
ERROR - 2021-09-04 07:55:15 --> 404 Page Not Found: Db/payment.sql
ERROR - 2021-09-04 07:55:16 --> 404 Page Not Found: Db/payments.sql
ERROR - 2021-09-04 07:55:18 --> 404 Page Not Found: Db/shop.sql
ERROR - 2021-09-04 07:55:19 --> 404 Page Not Found: Db/xuanhao.sql
ERROR - 2021-09-04 07:55:19 --> 404 Page Not Found: Dbsql/index
ERROR - 2021-09-04 07:55:20 --> 404 Page Not Found: Dbtxt/index
ERROR - 2021-09-04 07:55:21 --> 404 Page Not Found: Db/store.sql
ERROR - 2021-09-04 07:55:22 --> 404 Page Not Found: Shxuanhaonetsql/index
ERROR - 2021-09-04 07:55:23 --> 404 Page Not Found: Dump/backup.sql
ERROR - 2021-09-04 07:55:24 --> 404 Page Not Found: Dump/bd.sql
ERROR - 2021-09-04 07:55:25 --> 404 Page Not Found: Dump/database.sql
ERROR - 2021-09-04 07:55:26 --> 404 Page Not Found: Dump/dbdump.sql
ERROR - 2021-09-04 07:55:28 --> 404 Page Not Found: Dump/shxuanhaonet.sql
ERROR - 2021-09-04 07:55:30 --> 404 Page Not Found: Dump/dump.sql
ERROR - 2021-09-04 07:55:31 --> 404 Page Not Found: Dump/localhost.sql
ERROR - 2021-09-04 07:55:32 --> 404 Page Not Found: Dump/mysql.sql
ERROR - 2021-09-04 07:55:33 --> 404 Page Not Found: Dump/order.sql
ERROR - 2021-09-04 07:55:34 --> 404 Page Not Found: Dump/orders.sql
ERROR - 2021-09-04 07:55:35 --> 404 Page Not Found: Dump/payment.sql
ERROR - 2021-09-04 07:55:35 --> 404 Page Not Found: Dump/payments.sql
ERROR - 2021-09-04 07:55:36 --> 404 Page Not Found: Dump/shop.sql
ERROR - 2021-09-04 07:55:37 --> 404 Page Not Found: Dump/xuanhao.sql
ERROR - 2021-09-04 07:55:38 --> 404 Page Not Found: Dumps/order.sql
ERROR - 2021-09-04 07:55:39 --> 404 Page Not Found: Dumps/orders.sql
ERROR - 2021-09-04 07:55:40 --> 404 Page Not Found: Dumps/payment.sql
ERROR - 2021-09-04 07:55:41 --> 404 Page Not Found: Dumps/payments.sql
ERROR - 2021-09-04 07:55:42 --> 404 Page Not Found: Dumpsql/index
ERROR - 2021-09-04 07:55:42 --> 404 Page Not Found: Dumptxt/index
ERROR - 2021-09-04 07:55:43 --> 404 Page Not Found: Dumps/shop.sql
ERROR - 2021-09-04 07:55:44 --> 404 Page Not Found: Dumps/store.sql
ERROR - 2021-09-04 07:55:45 --> 404 Page Not Found: Dump/store.sql
ERROR - 2021-09-04 07:55:45 --> 404 Page Not Found: Exportsql/index
ERROR - 2021-09-04 07:55:47 --> 404 Page Not Found: Gatewaysql/index
ERROR - 2021-09-04 07:55:48 --> 404 Page Not Found: Homesql/index
ERROR - 2021-09-04 07:55:49 --> 404 Page Not Found: Keyssql/index
ERROR - 2021-09-04 07:55:50 --> 404 Page Not Found: Localhostsql/index
ERROR - 2021-09-04 07:55:50 --> 404 Page Not Found: Mainsql/index
ERROR - 2021-09-04 07:55:51 --> 404 Page Not Found: Migrationsql/index
ERROR - 2021-09-04 07:55:52 --> 404 Page Not Found: Mysql/backup.sql
ERROR - 2021-09-04 07:55:53 --> 404 Page Not Found: Mysql/bd.sql
ERROR - 2021-09-04 07:55:54 --> 404 Page Not Found: Mysql/database.sql
ERROR - 2021-09-04 07:55:56 --> 404 Page Not Found: Mysql/dbdump.sql
ERROR - 2021-09-04 07:55:56 --> 404 Page Not Found: Mysql/shxuanhaonet.sql
ERROR - 2021-09-04 07:55:57 --> 404 Page Not Found: Mysql/dump.sql
ERROR - 2021-09-04 07:55:58 --> 404 Page Not Found: Mysqldumpsql/index
ERROR - 2021-09-04 07:55:59 --> 404 Page Not Found: Mysql/localhost.sql
ERROR - 2021-09-04 07:56:00 --> 404 Page Not Found: Mysql/mysql.sql
ERROR - 2021-09-04 07:56:01 --> 404 Page Not Found: Mysql/order.sql
ERROR - 2021-09-04 07:56:02 --> 404 Page Not Found: Mysql/orders.sql
ERROR - 2021-09-04 07:56:03 --> 404 Page Not Found: Mysql/payment.sql
ERROR - 2021-09-04 07:56:03 --> 404 Page Not Found: Mysql/payments.sql
ERROR - 2021-09-04 07:56:04 --> 404 Page Not Found: Mysql/shop.sql
ERROR - 2021-09-04 07:56:05 --> 404 Page Not Found: Mysql/xuanhao.sql
ERROR - 2021-09-04 07:56:06 --> 404 Page Not Found: Mysqlsql/index
ERROR - 2021-09-04 07:56:07 --> 404 Page Not Found: Mysql/store.sql
ERROR - 2021-09-04 07:56:08 --> 404 Page Not Found: Oldsql/index
ERROR - 2021-09-04 07:56:09 --> 404 Page Not Found: Ordersql/index
ERROR - 2021-09-04 07:56:10 --> 404 Page Not Found: Orderssql/index
ERROR - 2021-09-04 07:56:11 --> 404 Page Not Found: Orderstxt/index
ERROR - 2021-09-04 07:56:12 --> 404 Page Not Found: Oscommercesql/index
ERROR - 2021-09-04 07:56:14 --> 404 Page Not Found: OsCommercesql/index
ERROR - 2021-09-04 07:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:56:15 --> 404 Page Not Found: Passwordssql/index
ERROR - 2021-09-04 07:56:16 --> 404 Page Not Found: Paymentsql/index
ERROR - 2021-09-04 07:56:17 --> 404 Page Not Found: Paymentssql/index
ERROR - 2021-09-04 07:56:18 --> 404 Page Not Found: Paymentstxt/index
ERROR - 2021-09-04 07:56:19 --> 404 Page Not Found: Public_htmlsql/index
ERROR - 2021-09-04 07:56:20 --> 404 Page Not Found: Savesql/index
ERROR - 2021-09-04 07:56:21 --> 404 Page Not Found: Securitysql/index
ERROR - 2021-09-04 07:56:22 --> 404 Page Not Found: Serversql/index
ERROR - 2021-09-04 07:56:23 --> 404 Page Not Found: Shopsql/index
ERROR - 2021-09-04 07:56:24 --> 404 Page Not Found: Shoptxt/index
ERROR - 2021-09-04 07:56:25 --> 404 Page Not Found: Xuanhaosql/index
ERROR - 2021-09-04 07:56:25 --> 404 Page Not Found: Sitesql/index
ERROR - 2021-09-04 07:56:26 --> 404 Page Not Found: Sql/backup.sql
ERROR - 2021-09-04 07:56:27 --> 404 Page Not Found: Sql/bd.sql
ERROR - 2021-09-04 07:56:28 --> 404 Page Not Found: Sql/database.sql
ERROR - 2021-09-04 07:56:29 --> 404 Page Not Found: Sql/dbdump.sql
ERROR - 2021-09-04 07:56:30 --> 404 Page Not Found: Sql/shxuanhaonet.sql
ERROR - 2021-09-04 07:56:31 --> 404 Page Not Found: Sql/dump.sql
ERROR - 2021-09-04 07:56:32 --> 404 Page Not Found: Sql/localhost.sql
ERROR - 2021-09-04 07:56:33 --> 404 Page Not Found: Sql/mysql.sql
ERROR - 2021-09-04 07:56:33 --> 404 Page Not Found: Sql/order.sql
ERROR - 2021-09-04 07:56:34 --> 404 Page Not Found: Sql/orders.sql
ERROR - 2021-09-04 07:56:35 --> 404 Page Not Found: Sql/payment.sql
ERROR - 2021-09-04 07:56:36 --> 404 Page Not Found: Sql/payments.sql
ERROR - 2021-09-04 07:56:37 --> 404 Page Not Found: Sql/shop.sql
ERROR - 2021-09-04 07:56:38 --> 404 Page Not Found: Sql/xuanhao.sql
ERROR - 2021-09-04 07:56:39 --> 404 Page Not Found: Sqlsql/index
ERROR - 2021-09-04 07:56:39 --> 404 Page Not Found: Sql/store.sql
ERROR - 2021-09-04 07:56:40 --> 404 Page Not Found: Storesql/index
ERROR - 2021-09-04 07:56:41 --> 404 Page Not Found: Storetxt/index
ERROR - 2021-09-04 07:56:42 --> 404 Page Not Found: Tempsql/index
ERROR - 2021-09-04 07:56:44 --> 404 Page Not Found: Tmpsql/index
ERROR - 2021-09-04 07:56:44 --> 404 Page Not Found: Testsql/index
ERROR - 2021-09-04 07:56:45 --> 404 Page Not Found: Uploadsql/index
ERROR - 2021-09-04 07:56:46 --> 404 Page Not Found: Updatesql/index
ERROR - 2021-09-04 07:56:47 --> 404 Page Not Found: Userssql/index
ERROR - 2021-09-04 07:56:48 --> 404 Page Not Found: Walletsql/index
ERROR - 2021-09-04 07:56:49 --> 404 Page Not Found: Websql/index
ERROR - 2021-09-04 07:56:50 --> 404 Page Not Found: Wordpresssql/index
ERROR - 2021-09-04 07:56:51 --> 404 Page Not Found: Wpsql/index
ERROR - 2021-09-04 07:56:52 --> 404 Page Not Found: Wwwrootsql/index
ERROR - 2021-09-04 07:56:53 --> 404 Page Not Found: Wwwsql/index
ERROR - 2021-09-04 07:56:54 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2021-09-04 07:56:54 --> 404 Page Not Found: admin/Backup/index
ERROR - 2021-09-04 07:56:56 --> 404 Page Not Found: admin/Backups/index
ERROR - 2021-09-04 07:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:56:57 --> 404 Page Not Found: admin/Files/index
ERROR - 2021-09-04 07:56:58 --> 404 Page Not Found: admin/Mysql/index
ERROR - 2021-09-04 07:56:59 --> 404 Page Not Found: admin/Upload/index
ERROR - 2021-09-04 07:57:00 --> 404 Page Not Found: admin/Uploaded/index
ERROR - 2021-09-04 07:57:01 --> 404 Page Not Found: admin/Uploads/index
ERROR - 2021-09-04 07:57:02 --> 404 Page Not Found: Archive/index
ERROR - 2021-09-04 07:57:03 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-04 07:57:04 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-04 07:57:04 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-04 07:57:06 --> 404 Page Not Found: BACKUP/index
ERROR - 2021-09-04 07:57:06 --> 404 Page Not Found: Backup/bitcoin
ERROR - 2021-09-04 07:57:07 --> 404 Page Not Found: Backups/index
ERROR - 2021-09-04 07:57:08 --> 404 Page Not Found: Backups/index
ERROR - 2021-09-04 07:57:09 --> 404 Page Not Found: Backups/index
ERROR - 2021-09-04 07:57:10 --> 404 Page Not Found: Bak/index
ERROR - 2021-09-04 07:57:11 --> 404 Page Not Found: Bitcoin/index
ERROR - 2021-09-04 07:57:12 --> 404 Page Not Found: Bitcoin/index
ERROR - 2021-09-04 07:57:13 --> 404 Page Not Found: Database/index
ERROR - 2021-09-04 07:57:15 --> 404 Page Not Found: Db_backup/index
ERROR - 2021-09-04 07:57:16 --> 404 Page Not Found: Dbbackup/index
ERROR - 2021-09-04 07:57:17 --> 404 Page Not Found: Db_backups/index
ERROR - 2021-09-04 07:57:18 --> 404 Page Not Found: Dbbackups/index
ERROR - 2021-09-04 07:57:19 --> 404 Page Not Found: Db/index
ERROR - 2021-09-04 07:57:20 --> 404 Page Not Found: Db_dump/index
ERROR - 2021-09-04 07:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:57:22 --> 404 Page Not Found: Dbdump/index
ERROR - 2021-09-04 07:57:23 --> 404 Page Not Found: Db_dumps/index
ERROR - 2021-09-04 07:57:23 --> 404 Page Not Found: Dbdumps/index
ERROR - 2021-09-04 07:57:24 --> 404 Page Not Found: Dump/index
ERROR - 2021-09-04 07:57:26 --> 404 Page Not Found: Dump/index
ERROR - 2021-09-04 07:57:27 --> 404 Page Not Found: Dumps/index
ERROR - 2021-09-04 07:57:29 --> 404 Page Not Found: Export/index
ERROR - 2021-09-04 07:57:30 --> 404 Page Not Found: Files/index
ERROR - 2021-09-04 07:57:31 --> 404 Page Not Found: Includes/database
ERROR - 2021-09-04 07:57:32 --> 404 Page Not Found: Includes/database
ERROR - 2021-09-04 07:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:57:33 --> 404 Page Not Found: Log/index
ERROR - 2021-09-04 07:57:34 --> 404 Page Not Found: Logs/index
ERROR - 2021-09-04 07:57:36 --> 404 Page Not Found: Mariadb/index
ERROR - 2021-09-04 07:57:37 --> 404 Page Not Found: Mysql_backup/index
ERROR - 2021-09-04 07:57:38 --> 404 Page Not Found: Mysqlbackup/index
ERROR - 2021-09-04 07:57:39 --> 404 Page Not Found: Mysql_backups/index
ERROR - 2021-09-04 07:57:40 --> 404 Page Not Found: Mysqlbackups/index
ERROR - 2021-09-04 07:57:41 --> 404 Page Not Found: Mysql_dump/index
ERROR - 2021-09-04 07:57:41 --> 404 Page Not Found: Mysqldump/index
ERROR - 2021-09-04 07:57:42 --> 404 Page Not Found: Mysql_dumps/index
ERROR - 2021-09-04 07:57:43 --> 404 Page Not Found: Mysqldumps/index
ERROR - 2021-09-04 07:57:44 --> 404 Page Not Found: Mysql/index
ERROR - 2021-09-04 07:57:45 --> 404 Page Not Found: Old_files/index
ERROR - 2021-09-04 07:57:46 --> 404 Page Not Found: Oldfiles/index
ERROR - 2021-09-04 07:57:49 --> 404 Page Not Found: Old/index
ERROR - 2021-09-04 07:57:50 --> 404 Page Not Found: Pmadumps/index
ERROR - 2021-09-04 07:57:51 --> 404 Page Not Found: Pma/index
ERROR - 2021-09-04 07:57:52 --> 404 Page Not Found: Saved/index
ERROR - 2021-09-04 07:57:53 --> 404 Page Not Found: Save/index
ERROR - 2021-09-04 07:57:54 --> 404 Page Not Found: Sql/backup
ERROR - 2021-09-04 07:57:55 --> 404 Page Not Found: Sql/backups
ERROR - 2021-09-04 07:57:56 --> 404 Page Not Found: Sql_dumps/index
ERROR - 2021-09-04 07:57:57 --> 404 Page Not Found: Sql/index
ERROR - 2021-09-04 07:57:58 --> 404 Page Not Found: Sql/sql
ERROR - 2021-09-04 07:57:59 --> 404 Page Not Found: Uploaded/index
ERROR - 2021-09-04 07:58:00 --> 404 Page Not Found: Upload/index
ERROR - 2021-09-04 07:58:02 --> 404 Page Not Found: Var/backups
ERROR - 2021-09-04 07:58:02 --> 404 Page Not Found: Wallet/index
ERROR - 2021-09-04 07:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 07:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:16:11 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-09-04 08:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:36:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 08:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:46:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 08:46:42 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-04 08:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:53:33 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-04 08:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 08:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:05:50 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-04 09:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:15:10 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-04 09:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:22:31 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-04 09:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:27:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:30:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 09:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 09:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:39:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:45:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:46:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 09:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:53:48 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/member_dingdan_show.php 74
ERROR - 2021-09-04 09:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 09:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:03:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 10:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 10:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:04:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 10:05:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 10:05:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 10:05:04 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-04 10:05:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 10:05:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 10:05:04 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-04 10:05:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-04 10:05:05 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-04 10:05:06 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-04 10:05:06 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-04 10:05:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 10:05:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 10:05:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 10:05:06 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-04 10:05:07 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-04 10:05:07 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-04 10:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 10:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:16:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 10:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:17:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 10:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:26:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 10:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:32:07 --> 404 Page Not Found: City/index
ERROR - 2021-09-04 10:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:35:58 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-04 10:36:03 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-04 10:36:03 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-04 10:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:41:05 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-04 10:41:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 10:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:44:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 10:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:53:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 10:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 10:57:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 10:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 10:58:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 10:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:00:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:08:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 11:08:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:10:39 --> 404 Page Not Found: 404/index.html
ERROR - 2021-09-04 11:10:39 --> 404 Page Not Found: 404/index.html
ERROR - 2021-09-04 11:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:13:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:15:22 --> 404 Page Not Found: City/9
ERROR - 2021-09-04 11:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:15:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:16:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:17:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:23:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:34:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:42:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:50:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:51:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 11:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:54:44 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/member_dingdan_show.php 74
ERROR - 2021-09-04 11:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 11:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-04 12:00:38 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-04 12:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:01:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 12:02:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:02:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 12:03:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 12:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:05:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:07:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 12:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:08:04 --> 404 Page Not Found: A/chanpinzhongxin
ERROR - 2021-09-04 12:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:12:03 --> 404 Page Not Found: City/1
ERROR - 2021-09-04 12:12:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:14:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:19:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:31:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 12:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:32:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:33:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:34:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:34:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:35:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:37:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:37:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:38:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:38:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:39:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:40:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:43:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:44:17 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-04 12:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 12:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:56:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:58:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 12:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 12:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 12:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:02:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:03:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:05:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:07:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 13:07:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 13:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:16:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:19:06 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-04 13:19:15 --> 404 Page Not Found: English/index
ERROR - 2021-09-04 13:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:19:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:35:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:40:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 13:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:40:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 13:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:41:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:43:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:48:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:50:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:55:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:57:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 13:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 13:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:00:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:00:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:03:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:12:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:13:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:25:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:25:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:32:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 14:32:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:38:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:43:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:48:05 --> 404 Page Not Found: Index/index
ERROR - 2021-09-04 14:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:54:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 14:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 14:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 14:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:04:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:07:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:09:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:10:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:10:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:10:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:10:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:10:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:11:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:11:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:12:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:12:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:12:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:12:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:13:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:13:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 15:13:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:41:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 15:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:55:52 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-04 15:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:57:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:57:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:58:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:58:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:58:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:58:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:59:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 15:59:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 15:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 16:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:12:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 16:12:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 16:12:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 16:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:32:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 16:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:41:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 16:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:42:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:44:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 16:44:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:44:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:44:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:50:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:51:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 16:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 16:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:06:22 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-04 17:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:10:47 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-04 17:10:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:11:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:13:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:13:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:19:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 17:19:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 17:20:40 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-04 17:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:23:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:24:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 17:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:37:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 17:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:37:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 17:38:48 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 17:38:48 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-04 17:38:49 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 17:38:50 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-04 17:38:51 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-04 17:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 17:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:03:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:04:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 18:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:07:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:08:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:10:26 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-04 18:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:17:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 18:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:31:53 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-09-04 18:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:32:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 18:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:35:10 --> 404 Page Not Found: Env/index
ERROR - 2021-09-04 18:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:44:56 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-04 18:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:46:45 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-09-04 18:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:48:37 --> 404 Page Not Found: City/1
ERROR - 2021-09-04 18:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:50:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:55:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:55:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:55:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:55:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:56:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 18:57:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 18:57:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 18:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 18:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:01:12 --> 404 Page Not Found: English/index
ERROR - 2021-09-04 19:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 19:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:42:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:45:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:48:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 19:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:56:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:57:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 19:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 19:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 20:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 20:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:20:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 20:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:25:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 20:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:30:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 20:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 20:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 20:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:44:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 20:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 20:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 20:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 20:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 20:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:54:45 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-04 20:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 20:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-04 21:04:32 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-04 21:04:33 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-04 21:04:34 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-04 21:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:12:33 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-04 21:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:17:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 21:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 21:25:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 21:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:26:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:26:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:26:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:26:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:27:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:27:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:27:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:28:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:30:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:30:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:32:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 21:32:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 21:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:33:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:33:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:33:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:33:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:33:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:33:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:34:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:35:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:38:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:38:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-04 21:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:40:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 21:40:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 21:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:44:58 --> 404 Page Not Found: Contact/index
ERROR - 2021-09-04 21:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:49:05 --> 404 Page Not Found: Contact/index
ERROR - 2021-09-04 21:49:11 --> 404 Page Not Found: Contact/index
ERROR - 2021-09-04 21:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:51:53 --> 404 Page Not Found: Contact/index
ERROR - 2021-09-04 21:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:53:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 21:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 21:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:05:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-04 22:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:10:43 --> 404 Page Not Found: Static/admin
ERROR - 2021-09-04 22:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:14:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:15:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:15:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:16:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:27:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:33:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:40:17 --> 404 Page Not Found: Html-en/hot-products-BExJnSQdumvP-1-0-1-1.html
ERROR - 2021-09-04 22:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:44:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 22:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:49:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 22:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:50:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-04 22:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:53:50 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-04 22:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 22:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:07:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 23:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:08:44 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-04 23:08:44 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-04 23:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:11:46 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-04 23:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:18:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 23:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 23:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:27:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-04 23:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:33:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 23:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:36:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 23:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:44:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 23:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:46:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-04 23:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:49:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 23:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-04 23:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-04 23:59:38 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
