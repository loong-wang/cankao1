<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-21 00:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 00:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 00:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 00:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 00:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 00:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 00:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 00:20:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 00:31:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 00:35:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 00:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 00:57:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 01:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 01:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 01:12:10 --> 404 Page Not Found: 5182/dfer
ERROR - 2021-12-21 01:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 01:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 01:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 01:35:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 01:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 01:36:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 01:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 01:41:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 01:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 01:45:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 01:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 01:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 02:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 02:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 02:25:21 --> 404 Page Not Found: News/images
ERROR - 2021-12-21 02:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 02:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 02:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 02:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 02:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 02:48:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 02:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 02:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 02:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:19:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 03:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:25:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 03:25:32 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 03:25:32 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 03:29:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 03:30:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 03:30:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 03:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 03:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:46:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 03:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:50:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 03:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 03:54:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 03:58:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 03:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:02:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 04:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:06:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 04:10:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 04:14:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 04:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:27:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 04:28:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 04:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 04:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 05:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 05:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 05:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 05:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 05:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 05:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 05:35:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 05:36:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 06:06:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 06:06:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 06:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 06:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 06:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 06:38:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 07:06:34 --> 404 Page Not Found: Daswf/concon.asp
ERROR - 2021-12-21 07:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 07:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 07:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 07:29:50 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/member_dingdan_show.php 74
ERROR - 2021-12-21 07:30:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/member_dingdan_show.php 74
ERROR - 2021-12-21 07:30:13 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/member_dingdan_show.php 74
ERROR - 2021-12-21 07:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 07:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:04:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 08:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:18:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 08:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:24:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 08:27:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 08:32:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 08:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 08:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 08:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 08:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 08:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 08:46:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 08:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 08:57:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 09:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:16:08 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-21 09:17:32 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-12-21 09:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 09:19:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:19:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:19:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:19:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 09:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:30:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:30:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:33:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:39:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:40:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:40:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:40:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:42:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:42:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:42:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 09:43:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:44:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 09:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 09:58:08 --> 404 Page Not Found: 1asa/index
ERROR - 2021-12-21 09:58:08 --> 404 Page Not Found: 1asa/index
ERROR - 2021-12-21 09:58:08 --> 404 Page Not Found: 1asa/index
ERROR - 2021-12-21 09:58:09 --> 404 Page Not Found: 1asa/index
ERROR - 2021-12-21 10:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 10:06:57 --> 404 Page Not Found: City/16
ERROR - 2021-12-21 10:07:22 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-12-21 10:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 10:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 10:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:22:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:23:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:23:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:24:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:25:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:25:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 10:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 10:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 10:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 10:43:20 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-12-21 10:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 10:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:07:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:07:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:07:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:10:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 11:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:18:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:23:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:28:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 11:28:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:29:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:35:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:35:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:36:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:45:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:45:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 11:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:50:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:51:56 --> 404 Page Not Found: Css/index.asp
ERROR - 2021-12-21 11:52:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:52:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:53:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:53:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:55:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:55:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 11:56:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:56:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 11:56:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 12:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:06:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 12:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:08:50 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-21 12:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:22:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 12:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:29:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-21 12:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:36:47 --> 404 Page Not Found: Css/css.asp
ERROR - 2021-12-21 12:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 12:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 12:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 13:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:29:02 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-21 13:29:02 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-21 13:29:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Member/space
ERROR - 2021-12-21 13:29:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:29:04 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 13:29:04 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 13:29:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:05 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-21 13:29:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:29:05 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 13:29:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 13:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:32:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:38:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 13:38:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:38:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 13:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 13:41:07 --> 404 Page Not Found: English/index
ERROR - 2021-12-21 13:47:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:47:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 13:47:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 14:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 14:08:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:08:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:08:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:12:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 14:15:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:16:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:20:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:24:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 14:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:25:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 14:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:28:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:30:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:31:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 14:31:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:31:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:32:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:33:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:37:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:38:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:38:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:40:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 14:40:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 14:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:51:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 14:52:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 14:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 14:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:04:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:05:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 15:05:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 15:05:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 15:05:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 15:05:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:09:42 --> 404 Page Not Found: Sitemap-68425html/index
ERROR - 2021-12-21 15:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:11:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:16:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:34:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:34:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:36:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:36:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:36:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:38:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:41:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 15:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:43:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 15:43:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:44:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:44:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:45:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:45:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:46:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:47:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:48:26 --> 404 Page Not Found: Coonaspx/index
ERROR - 2021-12-21 15:48:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 15:48:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 15:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:02:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:04:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:08:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:11:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:21:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 16:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:27:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 16:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:31:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:47:40 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-12-21 16:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:55:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 16:55:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 16:55:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 16:56:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 16:56:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 16:56:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 16:57:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 16:57:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:06:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:07:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 17:11:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 17:11:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 17:11:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 17:11:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 17:12:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 17:12:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 17:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:13:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 17:13:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 17:15:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 17:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:18:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:26:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 17:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:33:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 17:34:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:34:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:35:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 17:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 17:48:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 17:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:31:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 18:34:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 18:34:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 18:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:41:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 18:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 18:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 18:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 18:43:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 18:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 18:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:05:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:05:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:06:31 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Member/space
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 19:06:32 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 19:06:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:33 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-21 19:06:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:06:34 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-21 19:06:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:19:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 19:20:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:31:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:37:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 19:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:40:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:42:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:43:28 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-12-21 19:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:44:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 19:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:49:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 19:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:52:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:52:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:53:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:54:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:56:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:57:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:57:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 19:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 19:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:00:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 20:00:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:00:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 20:03:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 20:03:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 20:03:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:06:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:07:23 --> 404 Page Not Found: Dgbv/jmnb
ERROR - 2021-12-21 20:08:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 20:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:14:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:15:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 20:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 20:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 20:33:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 20:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 20:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 20:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:40:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:43:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 20:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 20:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:04:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:09:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:13:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:13:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:25:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:26:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:29:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:32:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:33:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:33:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:35:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:38:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:41:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 21:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 21:42:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 21:42:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 21:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:50:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:51:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 21:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 21:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:53:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:56:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 21:56:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:57:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 21:58:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 21:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:01:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:01:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 22:06:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:07:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:07:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:09:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:10:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:12:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 22:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:15:02 --> 404 Page Not Found: Date/js
ERROR - 2021-12-21 22:15:02 --> 404 Page Not Found: Date/js
ERROR - 2021-12-21 22:15:02 --> 404 Page Not Found: Date/js
ERROR - 2021-12-21 22:15:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 22:15:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:16:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:20:08 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-12-21 22:20:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 22:21:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 22:22:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:25:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 22:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:34:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:38:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 22:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:41:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-21 22:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:44:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:45:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 22:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:53:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 22:56:02 --> 404 Page Not Found: Com3indexlxasp/index
ERROR - 2021-12-21 22:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 22:58:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 23:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:06:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-21 23:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 23:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:12:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 23:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:19:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 23:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 23:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-21 23:40:10 --> 404 Page Not Found: Date/js
ERROR - 2021-12-21 23:47:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 23:52:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-21 23:52:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-21 23:54:52 --> 404 Page Not Found: Robotstxt/index
