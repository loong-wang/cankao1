<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-19 00:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 00:01:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:04:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:13:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:14:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:14:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:15:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:17:42 --> 404 Page Not Found: Wp-content/wp-content
ERROR - 2021-05-19 00:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:18:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:23:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:23:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:24:41 --> 404 Page Not Found: Expensesasp/index
ERROR - 2021-05-19 00:29:16 --> 404 Page Not Found: Wp/index
ERROR - 2021-05-19 00:29:16 --> 404 Page Not Found: Blog/index
ERROR - 2021-05-19 00:29:17 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-05-19 00:29:18 --> 404 Page Not Found: Site/index
ERROR - 2021-05-19 00:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:29:27 --> 404 Page Not Found: Cms/index
ERROR - 2021-05-19 00:29:27 --> 404 Page Not Found: Web/index
ERROR - 2021-05-19 00:29:28 --> 404 Page Not Found: News/index
ERROR - 2021-05-19 00:29:31 --> 404 Page Not Found: New/index
ERROR - 2021-05-19 00:29:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:30:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:30:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:33:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:34:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:34:53 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-05-19 00:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:34:55 --> 404 Page Not Found: Member/space
ERROR - 2021-05-19 00:34:57 --> 404 Page Not Found: Include/taglib
ERROR - 2021-05-19 00:34:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 00:34:58 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-05-19 00:34:58 --> 404 Page Not Found: Dede/templets
ERROR - 2021-05-19 00:34:58 --> 404 Page Not Found: Data/cache
ERROR - 2021-05-19 00:34:58 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-05-19 00:34:59 --> 404 Page Not Found: Data/cache
ERROR - 2021-05-19 00:34:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 00:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:34:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 00:35:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 00:35:01 --> 404 Page Not Found: Member/space
ERROR - 2021-05-19 00:35:03 --> 404 Page Not Found: Include/taglib
ERROR - 2021-05-19 00:35:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 00:35:04 --> 404 Page Not Found: Dede/templets
ERROR - 2021-05-19 00:35:04 --> 404 Page Not Found: Data/cache
ERROR - 2021-05-19 00:35:05 --> 404 Page Not Found: Data/cache
ERROR - 2021-05-19 00:35:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 00:35:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 00:35:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 00:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:37:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:39:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 00:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:47:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 00:47:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 00:47:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 00:47:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 00:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:49:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:51:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:54:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:55:02 --> 404 Page Not Found: Vod-search-wd-WWW44BNBNCOM-p-1html/index
ERROR - 2021-05-19 00:55:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 00:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 00:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 00:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:10:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:11:24 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-05-19 01:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:15:03 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-05-19 01:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:16:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:17:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:19:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:20:42 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 01:20:42 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 01:20:42 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 01:20:42 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 01:20:42 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 01:20:42 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 01:20:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 01:20:44 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 01:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:24:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:27:26 --> 404 Page Not Found: Config/getuser
ERROR - 2021-05-19 01:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:31:35 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-05-19 01:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:32:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 01:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:37:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:41:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:41:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 01:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 01:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:51:11 --> 404 Page Not Found: Wp-content/wp-content
ERROR - 2021-05-19 01:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 01:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:55:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 01:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 01:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:00:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:03:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:04:02 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-05-19 02:06:09 --> 404 Page Not Found: Cache/content-post.php.suspected
ERROR - 2021-05-19 02:06:20 --> 404 Page Not Found: Cache/content-post.php.suspected
ERROR - 2021-05-19 02:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:06:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:10:57 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 02:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:13:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 02:14:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:16:12 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-05-19 02:17:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:17:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:17:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 02:18:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:26:18 --> 404 Page Not Found: admin//index
ERROR - 2021-05-19 02:26:19 --> 404 Page Not Found: Magento/admin
ERROR - 2021-05-19 02:26:19 --> 404 Page Not Found: Magento2/admin
ERROR - 2021-05-19 02:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:28:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:29:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:29:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 02:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:37:11 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 02:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:38:00 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-05-19 02:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:40:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 02:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 02:59:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:06:33 --> 404 Page Not Found: Env/index
ERROR - 2021-05-19 03:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:09:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:10:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 03:11:52 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-05-19 03:12:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:13:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:15:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:18:58 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-05-19 03:20:07 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-05-19 03:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:20:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:20:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:21:15 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-05-19 03:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:22:30 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-05-19 03:22:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:23:44 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-05-19 03:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:24:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:26:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 03:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:34:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:37:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 03:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:37:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 03:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:38:58 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 03:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:44:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:46:01 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 03:46:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 03:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:53:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 03:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:57:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 03:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 03:58:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 03:59:06 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 03:59:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 03:59:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 03:59:08 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 03:59:08 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 03:59:08 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 04:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:00:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-05-19 04:01:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:01:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:02:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:03:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:03:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:06:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:07:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:08:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:08:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:08:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:09:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:10:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:10:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:11:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:11:53 --> 404 Page Not Found: Shell/index
ERROR - 2021-05-19 04:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:12:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 04:12:47 --> 404 Page Not Found: City/16
ERROR - 2021-05-19 04:13:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 04:15:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:16:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:18:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:18:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:18:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:19:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:19:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:20:26 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-05-19 04:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:23:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:24:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:26:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:28:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:38:14 --> 404 Page Not Found: Node/add
ERROR - 2021-05-19 04:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:40:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:45:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:46:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:46:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 04:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:48:36 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-05-19 04:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:50:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:55:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 04:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 04:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:01:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 05:02:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:04:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:05:06 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 05:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:05:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:06:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:07:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:12:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:12:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:13:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:15:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:16:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:23:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 05:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:30:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:31:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:31:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 05:31:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 05:33:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:38:37 --> 404 Page Not Found: City/15
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Dgg/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Mysql/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Bak_adminn_cn/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Bak_admin_99/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Shujukudata/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Bf/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Wgw/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Database/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Bak_data/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Bf-admin/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Ebf/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Beifen/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Backsql/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Diguo/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Bak/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Mysqlbak/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Beifenwang/doc.html
ERROR - 2021-05-19 05:39:03 --> 404 Page Not Found: Mysql-manage/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Ebak/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Databak/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Awdiguo/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Dg/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Dgbf/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Bei/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: EmpireBak/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Dgbak/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Data/doc.html
ERROR - 2021-05-19 05:39:04 --> 404 Page Not Found: Dbbak/doc.html
ERROR - 2021-05-19 05:39:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 05:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 05:52:19 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 05:52:20 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 05:52:21 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 05:52:21 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 05:52:21 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 05:52:21 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 05:52:21 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 05:52:21 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 05:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 05:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:10:56 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 06:10:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 06:10:56 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 06:10:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 06:10:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 06:10:58 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 06:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:11:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 06:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:16:24 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-05-19 06:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:25:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 06:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:25:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 06:25:46 --> 404 Page Not Found: Assets/img
ERROR - 2021-05-19 06:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:27:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 06:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:30:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 06:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:38:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 06:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:43:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 06:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Www20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Wwwxuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Www_xuanhao_net20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Wwwxuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Xuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Xuanhao_net20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Xuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Xuanhao20210516rar/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Www20210516targz/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Wwwxuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Www_xuanhao_net20210516targz/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Wwwxuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:42 --> 404 Page Not Found: Xuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Xuanhao_net20210516targz/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Xuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Xuanhao20210516targz/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Www20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Wwwxuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Www_xuanhao_net20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Wwwxuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Xuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Xuanhao_net20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Xuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Xuanhao20210516zip/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Www2021-05-16rar/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Wwwxuanhaonet2021-05-16rar/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Www_xuanhao_net2021-05-16rar/index
ERROR - 2021-05-19 06:48:43 --> 404 Page Not Found: Wwwxuanhaonet2021-05-16rar/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhaonet2021-05-16rar/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhao_net2021-05-16rar/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhaonet2021-05-16rar/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhao2021-05-16rar/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Www2021-05-16targz/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Wwwxuanhaonet2021-05-16targz/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Www_xuanhao_net2021-05-16targz/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Wwwxuanhaonet2021-05-16targz/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhaonet2021-05-16targz/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhao_net2021-05-16targz/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhaonet2021-05-16targz/index
ERROR - 2021-05-19 06:48:44 --> 404 Page Not Found: Xuanhao2021-05-16targz/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Www2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Wwwxuanhaonet2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Www_xuanhao_net2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Wwwxuanhaonet2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhaonet2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhao_net2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhaonet2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhao2021-05-16zip/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Www20210516rar/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Wwwxuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Www_xuanhao_net20210516rar/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Wwwxuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhao_net20210516rar/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhaonet20210516rar/index
ERROR - 2021-05-19 06:48:45 --> 404 Page Not Found: Xuanhao20210516rar/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Www20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Wwwxuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Www_xuanhao_net20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Wwwxuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Xuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Xuanhao_net20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Xuanhaonet20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Xuanhao20210516targz/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Www20210516zip/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Wwwxuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:46 --> 404 Page Not Found: Www_xuanhao_net20210516zip/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: Wwwxuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: Xuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: Xuanhao_net20210516zip/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: Xuanhaonet20210516zip/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: Xuanhao20210516zip/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: 20210516rar/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: 20210516targz/index
ERROR - 2021-05-19 06:48:47 --> 404 Page Not Found: 20210516zip/index
ERROR - 2021-05-19 06:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:51:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 06:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:57:05 --> 404 Page Not Found: Config/getuser
ERROR - 2021-05-19 06:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 06:59:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:00:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:01:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:01:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:07:08 --> 404 Page Not Found: Haokan/zt
ERROR - 2021-05-19 07:07:56 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-05-19 07:07:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:14:13 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-05-19 07:14:26 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-05-19 07:14:27 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-05-19 07:14:28 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-05-19 07:17:39 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-05-19 07:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:22:16 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-05-19 07:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:26:56 --> 404 Page Not Found: T4mH/index
ERROR - 2021-05-19 07:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:27:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:34:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:40:00 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-05-19 07:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:49:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:54:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 07:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:57:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 07:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 07:58:27 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 08:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:05:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:05:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:07:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:07:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:12:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 08:12:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 08:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:14:41 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-05-19 08:15:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 08:15:45 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 08:15:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:15:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:22:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:22:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 08:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:25:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 08:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:33:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 08:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:36:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 08:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:38:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 08:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:40:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 08:40:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 08:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:44:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 08:45:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 08:47:45 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 08:47:46 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 08:47:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 08:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:49:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 08:49:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 08:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:54:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 08:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 08:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:14:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-19 09:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:39:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 09:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:43:34 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 09:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:45:47 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-05-19 09:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:50:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:51:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:51:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:51:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:52:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:54:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:54:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:54:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 09:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:55:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:56:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 09:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 09:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:01:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:01:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:04:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:11:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:27:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 10:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:30:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:30:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:31:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:31:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:32:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:34:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 10:42:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 10:42:26 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 10:42:27 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 10:42:28 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 10:42:28 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 10:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:43:23 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-05-19 10:43:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 10:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:45:06 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-05-19 10:45:07 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-05-19 10:47:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 10:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:50:37 --> 404 Page Not Found: Env/index
ERROR - 2021-05-19 10:51:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 10:51:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 10:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:53:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 10:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:54:18 --> 404 Page Not Found: Seeyon/fileDownload.do
ERROR - 2021-05-19 10:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:54:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:32 --> 404 Page Not Found: Cn/product.asp
ERROR - 2021-05-19 10:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:54:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:55:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:55:05 --> 404 Page Not Found: Bdfwq/index.html
ERROR - 2021-05-19 10:55:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:55:27 --> 404 Page Not Found: Km/review
ERROR - 2021-05-19 10:55:33 --> 404 Page Not Found: Servicecontract/SoleServiceContractNew.aspx
ERROR - 2021-05-19 10:55:40 --> 404 Page Not Found: Xuzhou/system
ERROR - 2021-05-19 10:55:40 --> 404 Page Not Found: Loginhtm/index
ERROR - 2021-05-19 10:55:50 --> 404 Page Not Found: News/news_1538.html
ERROR - 2021-05-19 10:55:52 --> 404 Page Not Found: Dtxx_6176/index
ERROR - 2021-05-19 10:55:52 --> 404 Page Not Found: Itemhtm/index
ERROR - 2021-05-19 10:55:55 --> 404 Page Not Found: Prod/menpiao_edit.jsp
ERROR - 2021-05-19 10:55:57 --> 404 Page Not Found: EditorD2N/Register.aspx
ERROR - 2021-05-19 10:56:00 --> 404 Page Not Found: Ckfinder/plugins
ERROR - 2021-05-19 10:56:01 --> 404 Page Not Found: Wangchunru/yjfx
ERROR - 2021-05-19 10:56:03 --> 404 Page Not Found: Bbs-vhdufk-frpsdqb/f
ERROR - 2021-05-19 10:56:05 --> 404 Page Not Found: Work/Work_Duty_Manage.aspx
ERROR - 2021-05-19 10:56:05 --> 404 Page Not Found: Guoji/7195.html
ERROR - 2021-05-19 10:56:05 --> 404 Page Not Found: Chushou/3_191823538.htm
ERROR - 2021-05-19 10:56:05 --> 404 Page Not Found: User/login.html
ERROR - 2021-05-19 10:56:05 --> 404 Page Not Found: Xmtms/admin
ERROR - 2021-05-19 10:56:05 --> 404 Page Not Found: Vod/type
ERROR - 2021-05-19 10:56:06 --> 404 Page Not Found: Quannian/quanziliao
ERROR - 2021-05-19 10:56:07 --> 404 Page Not Found: Info/1053
ERROR - 2021-05-19 10:56:09 --> 404 Page Not Found: Wap/news69356
ERROR - 2021-05-19 10:56:12 --> 404 Page Not Found: Vod-play-id-16520-src-1-num-1html/index
ERROR - 2021-05-19 10:56:13 --> 404 Page Not Found: Dg/20191119
ERROR - 2021-05-19 10:56:14 --> 404 Page Not Found: Cpcx/Manage
ERROR - 2021-05-19 10:56:16 --> 404 Page Not Found: WKC/WebPublication
ERROR - 2021-05-19 10:56:17 --> 404 Page Not Found: Buycar/list-okop9os207oe10ob144
ERROR - 2021-05-19 10:56:18 --> 404 Page Not Found: Dzjp/tq2.htm
ERROR - 2021-05-19 10:56:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 10:56:46 --> 404 Page Not Found: Zhnfbnotesdo/index
ERROR - 2021-05-19 10:56:54 --> 404 Page Not Found: 1/1337.html
ERROR - 2021-05-19 10:57:04 --> 404 Page Not Found: Jcjg/Organization.aspx
ERROR - 2021-05-19 10:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 10:57:20 --> 404 Page Not Found: TemplateFormaspx/index
ERROR - 2021-05-19 10:57:39 --> 404 Page Not Found: Vod/type
ERROR - 2021-05-19 10:57:42 --> 404 Page Not Found: User/singlogin.do
ERROR - 2021-05-19 10:57:51 --> 404 Page Not Found: User/singlogin.do
ERROR - 2021-05-19 10:58:02 --> 404 Page Not Found: Html/finance
ERROR - 2021-05-19 10:58:02 --> 404 Page Not Found: User/singlogin.do
ERROR - 2021-05-19 10:58:13 --> 404 Page Not Found: Yousiteadmin/websetedit.asp
ERROR - 2021-05-19 10:58:14 --> 404 Page Not Found: admin/Members/customer
ERROR - 2021-05-19 10:58:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:58:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 10:59:41 --> 404 Page Not Found: Jwglxt/cjlrgl
ERROR - 2021-05-19 10:59:42 --> 404 Page Not Found: 315575/index
ERROR - 2021-05-19 10:59:53 --> 404 Page Not Found: Dtxsasp/index
ERROR - 2021-05-19 11:00:07 --> 404 Page Not Found: Vhtml/index
ERROR - 2021-05-19 11:00:13 --> 404 Page Not Found: Member/SellTaskMoney
ERROR - 2021-05-19 11:00:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:00:28 --> 404 Page Not Found: Weaver/weaver.file.FileDownload
ERROR - 2021-05-19 11:01:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:01:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:24 --> 404 Page Not Found: Qiyezixun/20210508
ERROR - 2021-05-19 11:02:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:02:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:04:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:05:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:06:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:07:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:08:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:09:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:10:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:11:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:11:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:12:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:30:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:39:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:40:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:43:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:50:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:50:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:53:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:55:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 11:55:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 11:55:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 11:55:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 11:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:56:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:56:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:57:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:57:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 11:58:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 11:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 11:59:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 11:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 12:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 12:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 12:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 12:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:11:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:12:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:13:15 --> 404 Page Not Found: Env/index
ERROR - 2021-05-19 12:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:15:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:15:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:16:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 12:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:18:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:24:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:29:00 --> 404 Page Not Found: Shell/index
ERROR - 2021-05-19 12:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 12:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:31:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:37:37 --> 404 Page Not Found: Assets/img
ERROR - 2021-05-19 12:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:48:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:49:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:49:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:49:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:55:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 12:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 12:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:07:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 13:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:11:00 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-05-19 13:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:25:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 13:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:33:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 13:33:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 13:33:04 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 13:33:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 13:33:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 13:33:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 13:33:07 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 13:33:07 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 13:33:07 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 13:33:07 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 13:33:08 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 13:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:37:43 --> 404 Page Not Found: English/index
ERROR - 2021-05-19 13:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:40:24 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 13:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:40:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:42:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 13:44:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:44:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:45:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 13:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:45:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:46:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 13:46:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 13:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:46:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 13:46:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 13:46:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:46:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:49:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:49:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:50:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 13:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:51:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 13:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 13:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 13:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:00:24 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 14:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:03:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:05:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 14:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:10:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 14:10:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 14:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:11:41 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 14:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:12:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 14:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:15:02 --> 404 Page Not Found: City/index
ERROR - 2021-05-19 14:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:25:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 14:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:27:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 14:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:28:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 14:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:29:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 14:29:38 --> 404 Page Not Found: Assets/img
ERROR - 2021-05-19 14:29:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:30:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 14:30:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:33:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:37:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 14:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:39:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:42:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:47:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 14:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:49:53 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-05-19 14:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:52:02 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-05-19 14:52:16 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-05-19 14:52:17 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-05-19 14:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:56:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:56:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 14:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 14:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:03:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:03:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:05:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:05:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:10:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:12:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:14:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:18:30 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-05-19 15:19:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:22:15 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-05-19 15:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:23:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:24:07 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 15:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:25:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 15:25:30 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 15:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:25:48 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-05-19 15:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:25:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:27:39 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-05-19 15:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:35:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:37:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:38:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:38:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:40:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:40:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:40:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:41:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:41:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 15:41:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:42:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 15:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:43:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:44:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:45:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:45:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 15:45:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:46:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:46:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:46:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:48:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:48:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:48:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:49:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:50:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:51:30 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 15:51:37 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 15:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:52:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:53:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:53:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:53:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 15:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:53:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:56:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 15:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 15:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:03:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:06:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:06:38 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-05-19 16:06:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:07:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:17:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:17:40 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-05-19 16:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:18:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:18:23 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-05-19 16:18:33 --> 404 Page Not Found: City/2
ERROR - 2021-05-19 16:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:19:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:19:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:21:40 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-05-19 16:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:25:50 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-05-19 16:26:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 16:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:27:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:31:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:32:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:37:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:37:24 --> 404 Page Not Found: Nmaplowercheck1621413436/index
ERROR - 2021-05-19 16:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:37:29 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-05-19 16:37:33 --> 404 Page Not Found: Pools/default
ERROR - 2021-05-19 16:37:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:48:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:50:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:53:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:55:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:55:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:55:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:56:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 16:57:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:57:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:57:26 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-05-19 16:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 16:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 16:59:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:02:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:02:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:03:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:04:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:04:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:06:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 17:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:08:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:08:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:12:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:13:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:13:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:17:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:17:24 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 17:17:24 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 17:17:24 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 17:17:24 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 17:17:24 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 17:17:24 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 17:17:25 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 17:17:26 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 17:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:18:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:21:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:25:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:25:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:25:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:25:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:28:01 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-05-19 17:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:31:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 17:32:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:37:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:39:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 17:39:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 17:39:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 17:39:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 17:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:39:41 --> 404 Page Not Found: Upsphpsuspected/index
ERROR - 2021-05-19 17:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:45:59 --> 404 Page Not Found: Login/index
ERROR - 2021-05-19 17:45:59 --> 404 Page Not Found: Jenkins/login
ERROR - 2021-05-19 17:45:59 --> 404 Page Not Found: Manager/html
ERROR - 2021-05-19 17:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:47:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:48:22 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-05-19 17:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:55:14 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-05-19 17:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:56:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 17:58:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 17:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:01:23 --> Severity: Warning --> Missing argument 1 for News::show() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 581
ERROR - 2021-05-19 18:01:26 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-05-19 18:01:31 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 18:01:34 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 18:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:01:35 --> 404 Page Not Found: City/index
ERROR - 2021-05-19 18:01:41 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-05-19 18:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:11:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:14:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:19:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:21:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:24:57 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-05-19 18:25:03 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-05-19 18:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:26:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:26:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:31:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:31:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 18:31:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 18:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:33:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 18:34:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 18:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:35:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:36:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:40:31 --> 404 Page Not Found: Cart/index
ERROR - 2021-05-19 18:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:55:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:56:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 18:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 18:58:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:01:40 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-05-19 19:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:02:15 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-05-19 19:02:22 --> 404 Page Not Found: City/2
ERROR - 2021-05-19 19:03:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 19:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:05:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:09:18 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 19:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:09:53 --> 404 Page Not Found: City/index
ERROR - 2021-05-19 19:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:11:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:16:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:19:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:21:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:27:39 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-05-19 19:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:30:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:30:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 19:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:31:42 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 19:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:35:55 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-05-19 19:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:43:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:45:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:48:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 19:54:35 --> 404 Page Not Found: City/16
ERROR - 2021-05-19 19:55:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:57:51 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-05-19 19:57:52 --> Severity: Warning --> Missing argument 1 for Xinxi::show() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 97
ERROR - 2021-05-19 19:57:56 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 19:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 19:59:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:59:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 19:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:01:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:01:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:03:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:03:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:04:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-19 20:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:05:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:05:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:05:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:06:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:11:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:12:21 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 20:12:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 20:12:21 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 20:12:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 20:12:21 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 20:12:21 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 20:12:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 20:12:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 20:12:24 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 20:12:24 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 20:12:24 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 20:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:12:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:12:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:13:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:15:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:18:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:20:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:20:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:20:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:21:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:21:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:21:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:21:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:23:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:23:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:25:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:25:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 20:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 20:26:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:31:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:33:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:35:54 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2021-05-19 20:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:39:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:44:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:46:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:53:13 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 20:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 20:55:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:56:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:56:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 20:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:01:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:01:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:02:51 --> 404 Page Not Found: English/index
ERROR - 2021-05-19 21:03:00 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 21:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:03:19 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-05-19 21:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:04:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:05:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:05:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:11:31 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 21:11:41 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 21:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:13:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:14:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:17:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 21:17:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:17:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:19:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:19:14 --> 404 Page Not Found: City/10
ERROR - 2021-05-19 21:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:20:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:22:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 21:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 21:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:38:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:46:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 21:46:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:46:34 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 21:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:48:52 --> Severity: Warning --> Missing argument 1 for News::show() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 581
ERROR - 2021-05-19 21:48:53 --> Severity: Warning --> Missing argument 1 for News::show() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 581
ERROR - 2021-05-19 21:48:55 --> Severity: Warning --> Missing argument 1 for News::show() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 581
ERROR - 2021-05-19 21:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:51:09 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-05-19 21:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:54:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:56:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:56:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 21:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 21:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 21:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:01:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:02:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:05:13 --> 404 Page Not Found: Vod-read-id-2807html/index
ERROR - 2021-05-19 22:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:09:43 --> 404 Page Not Found: City/10
ERROR - 2021-05-19 22:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:11:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:12:19 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-05-19 22:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:15:32 --> 404 Page Not Found: Cache/simple.php5.suspected
ERROR - 2021-05-19 22:16:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:19:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:27:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:30:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:32:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:33:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:34:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 22:34:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:35:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:35:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:36:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:36:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:37:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:37:08 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 22:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:38:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:38:08 --> 404 Page Not Found: City/1
ERROR - 2021-05-19 22:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:38:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:38:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:39:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 22:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:39:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:40:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:40:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:40:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:41:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:42:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:43:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:44:01 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 22:44:01 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 22:44:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 22:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:45:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:46:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:46:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:47:44 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:48:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:48:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:48:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:48:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:48:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:48:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:48:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:48:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:48:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:48:53 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:49:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:49:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:49:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:49:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:49:08 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:49:14 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:49:52 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:49:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:49:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:50:00 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:50:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:50:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:50:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-05-19 22:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:51:53 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-05-19 22:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:52:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:54:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:55:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:57:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 22:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 22:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:00:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:00:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:06:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:11:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:13:43 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-05-19 23:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:14:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:15:17 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-05-19 23:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:18:51 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-19 23:19:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:21:29 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-05-19 23:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:28:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:28:41 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 23:28:41 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-05-19 23:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:31:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:32:52 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2021-05-19 23:33:51 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-19 23:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:36:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:38:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 23:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:39:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:41:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:45:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-19 23:45:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:45:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 23:45:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 23:45:47 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-19 23:45:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-19 23:45:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 23:45:48 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-19 23:45:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-19 23:45:48 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-19 23:45:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-19 23:45:49 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-19 23:45:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-19 23:45:50 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-19 23:45:50 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-19 23:45:50 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-19 23:45:51 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-19 23:45:51 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-19 23:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:46:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:46:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:46:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:46:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:47:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:47:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:47:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:47:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-19 23:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:49:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:53:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:53:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-19 23:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-19 23:59:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
