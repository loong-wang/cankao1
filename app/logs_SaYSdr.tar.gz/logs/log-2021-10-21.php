<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-21 00:09:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 00:24:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 00:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 00:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 00:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 00:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:44:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:44:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:45:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:46:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 00:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:10:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 01:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:13:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:15:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:27:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 01:40:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 02:05:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 02:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 02:23:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 02:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 02:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 02:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 03:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 03:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 03:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 03:31:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 03:32:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 03:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 03:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 03:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 03:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 04:01:03 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-10-21 04:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 04:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 04:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 05:06:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 05:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 05:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 05:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 05:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 05:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 05:34:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 05:46:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 05:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 05:52:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 06:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 06:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 06:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 06:42:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 06:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 06:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 06:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 06:59:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 07:00:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 07:00:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 07:00:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 07:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 07:02:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 07:03:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 07:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:24:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 07:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:41:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 07:51:37 --> 404 Page Not Found: Index/login
ERROR - 2021-10-21 07:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 07:59:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 07:59:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 08:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 08:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 08:16:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 08:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 08:32:02 --> 404 Page Not Found: Login/index
ERROR - 2021-10-21 08:49:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 08:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 08:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 08:51:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 08:52:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 08:53:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 08:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 08:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 08:56:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 09:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 09:19:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 09:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:23:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:27:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 09:27:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 09:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 09:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 09:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 09:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 09:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:49:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 09:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 09:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 10:03:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:07:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 10:08:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 10:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 10:11:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 10:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 10:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:31:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 10:32:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 10:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 10:37:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 10:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 10:38:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 10:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 10:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 10:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:53:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:54:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:55:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:56:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:57:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 10:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 11:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 11:06:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 11:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 11:10:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:10:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 11:11:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:11:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-21 11:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 11:15:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 11:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 11:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 11:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 11:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 11:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 11:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 11:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 12:00:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 12:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 12:02:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 12:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 12:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 12:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 12:11:49 --> 404 Page Not Found: Undefined/index
ERROR - 2021-10-21 12:14:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 12:15:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 12:28:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 12:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 12:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 12:52:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 12:52:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 12:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 12:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 12:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 12:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 12:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:00:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 13:03:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 13:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:12:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-21 13:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 13:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 14:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 14:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 14:07:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 14:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 14:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 14:23:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 14:24:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 14:25:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 14:25:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 14:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 14:35:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 14:40:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 14:40:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 14:46:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 14:51:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 14:53:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 14:53:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 14:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 15:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 15:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 15:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 15:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 15:11:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 15:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:22:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 15:24:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 15:28:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 15:28:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 15:29:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 15:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:31:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 15:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:35:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 15:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 15:56:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 15:57:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:04:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:05:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:05:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 16:21:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 16:25:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 16:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:28:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 16:35:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 16:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 16:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 16:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:42:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 16:53:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 16:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 17:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 17:05:07 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-21 17:20:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:21:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:22:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 17:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:24:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 17:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 17:35:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:40:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:41:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 17:44:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:46:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:46:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:46:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:46:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:47:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:47:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:47:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:47:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:47:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:48:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:48:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:48:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:48:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:48:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 17:48:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:48:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:48:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:52:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:55:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 17:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 17:57:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 17:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 18:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 18:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 18:03:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 18:06:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 18:07:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 18:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 18:29:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 18:29:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 18:34:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 18:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 18:37:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 18:37:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 18:40:49 --> 404 Page Not Found: CurrentTime/index
ERROR - 2021-10-21 18:48:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 18:49:19 --> 404 Page Not Found: Tags/luotihunshazhao
ERROR - 2021-10-21 18:49:23 --> 404 Page Not Found: Archives/4.html
ERROR - 2021-10-21 18:49:25 --> 404 Page Not Found: Shaoer/jyzx
ERROR - 2021-10-21 18:49:29 --> 404 Page Not Found: Index/tzgg.htm
ERROR - 2021-10-21 18:49:36 --> 404 Page Not Found: Stats/global
ERROR - 2021-10-21 18:49:40 --> 404 Page Not Found: Jindu/ICBC
ERROR - 2021-10-21 18:49:51 --> 404 Page Not Found: News/80031.html
ERROR - 2021-10-21 18:49:54 --> 404 Page Not Found: Cpeinet/202108
ERROR - 2021-10-21 18:50:00 --> 404 Page Not Found: Product/10
ERROR - 2021-10-21 18:50:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 18:50:24 --> 404 Page Not Found: Champion/ezreal
ERROR - 2021-10-21 18:50:27 --> 404 Page Not Found: Glzl/1080.html
ERROR - 2021-10-21 18:50:29 --> 404 Page Not Found: Html/law.html
ERROR - 2021-10-21 18:51:03 --> 404 Page Not Found: Col/col38278
ERROR - 2021-10-21 18:51:41 --> 404 Page Not Found: Cqqx/html
ERROR - 2021-10-21 18:51:48 --> 404 Page Not Found: A/32780.aspx
ERROR - 2021-10-21 18:52:16 --> 404 Page Not Found: Cars/sg52
ERROR - 2021-10-21 18:52:21 --> 404 Page Not Found: Qz/index
ERROR - 2021-10-21 18:52:52 --> 404 Page Not Found: Article-36704-1html/index
ERROR - 2021-10-21 18:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:13:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 19:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:22:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 19:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:35:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:38:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 19:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:38:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:39:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:39:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:42:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:43:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:46:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:47:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:47:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:48:26 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-10-21 19:48:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:49:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:51:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:52:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:52:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 19:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 19:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 20:00:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 20:02:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 20:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 20:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 20:13:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 20:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 20:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 20:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 20:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 20:50:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 20:52:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 20:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 20:59:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 21:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 21:02:08 --> 404 Page Not Found: Page/images
ERROR - 2021-10-21 21:02:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 21:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 21:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 21:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 21:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 22:02:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 22:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 22:12:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 22:15:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 22:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 22:26:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 22:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:26:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 22:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:30:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 22:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:41:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:41:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:41:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:41:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:42:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:42:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:44:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:44:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:48:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:49:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 22:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 22:59:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:06:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:07:46 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-21 23:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 23:11:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-21 23:12:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 23:12:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 23:12:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-21 23:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 23:30:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:31:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:31:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:46:53 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-10-21 23:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:54:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-21 23:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:56:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-21 23:56:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:57:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:57:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-21 23:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
