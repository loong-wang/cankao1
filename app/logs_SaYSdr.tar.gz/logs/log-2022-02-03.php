<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-03 00:10:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 00:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 00:13:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-03 00:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 00:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 00:17:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:17:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:20:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:21:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:21:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:25:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:27:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:28:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:31:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:32:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:35:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:37:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:38:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:38:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 00:39:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-03 00:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 01:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 01:26:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-03 01:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 01:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 01:37:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 01:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 01:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 01:38:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 01:39:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 01:39:37 --> 404 Page Not Found: Deirmltoagcjsqf/index
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Api/chat
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Web/wap
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Info/hide
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Api/pc
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Static/wap
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Btc/system-user
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Api/index
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Backend/index
ERROR - 2022-02-03 01:39:39 --> 404 Page Not Found: Option/coin
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Dock/system
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Auth/web
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Api/zhenren
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Api/index
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: :8088/index
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Api/currency
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Api/config
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Api/config
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: admin/Event/uploadfile
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Pub/getQhDynamic
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Pc/tools
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Manifestjson/index
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Step3asp/index
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Home/tools
ERROR - 2022-02-03 01:39:40 --> 404 Page Not Found: Application/Home
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/Game
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/home
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: AppApi/NotLoggedInApi
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Xmlb/index
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: V2/start
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/user
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/v1
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/site
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Notice/unreadMsgCount
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/apps
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/v2
ERROR - 2022-02-03 01:39:41 --> 404 Page Not Found: Api/user
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Api/site
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Sys/setting
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Login/index.asp
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: History_codeshtml/index
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Api/login
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: OpenApi/getHelpInfo
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Api/shares
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Api/sms
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Default_drawnoticeshtml/index
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Api/product
ERROR - 2022-02-03 01:39:42 --> 404 Page Not Found: Js/preload
ERROR - 2022-02-03 01:39:43 --> 404 Page Not Found: User/login.html
ERROR - 2022-02-03 01:39:43 --> 404 Page Not Found: Home/login
ERROR - 2022-02-03 01:39:43 --> 404 Page Not Found: Service/index
ERROR - 2022-02-03 01:39:43 --> 404 Page Not Found: H5/login
ERROR - 2022-02-03 01:39:43 --> 404 Page Not Found: Wallet/index
ERROR - 2022-02-03 01:39:44 --> 404 Page Not Found: En/autonews.html
ERROR - 2022-02-03 01:39:44 --> 404 Page Not Found: Shujuku/index.asp
ERROR - 2022-02-03 01:39:44 --> 404 Page Not Found: Api/index
ERROR - 2022-02-03 01:39:44 --> 404 Page Not Found: Ws/index
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Api/getapi
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: :8013/index
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Mobile/index.html
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Api/message
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Index/index
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Index/index
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Case/index
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Fei1asp/index
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Business/t-ec-info
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: Api/uploads
ERROR - 2022-02-03 01:39:45 --> 404 Page Not Found: admin/Auth/login
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Ajax/index_b_trends
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Index/login
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Html/wechat
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Index/chat
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Platform/passport
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Melody/api
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Api/index
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Gethmaspx/index
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: V1/management
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Native/getStationInfo.do
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Api/nimcc
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Api/exclude
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: View/game
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Template/Home
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Web/api
ERROR - 2022-02-03 01:39:46 --> 404 Page Not Found: Views/bank
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: Index/index
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: Index/index
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: M/trial.asp
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: Jsonpublic/selectAddtion.asp
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: Bin-release/update_descriptor_1.xml
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: Index/index
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: Resource/ui_config
ERROR - 2022-02-03 01:39:47 --> 404 Page Not Found: Login/index
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Image/delImage
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Loan/SubmitLogin
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Mobile/loan
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Mobile/api
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Mobile/index
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Superadmin/lock.lock
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Static/appAdd.jsp
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Api/Index
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Index/index
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Index/pcpage
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Trade/quote
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Wx/ZFpass.asp
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: User/Reg
ERROR - 2022-02-03 01:39:48 --> 404 Page Not Found: Index/lotteryHall.do
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Msky/v1.0
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Public/1.txt
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: _login/in
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: 11txt/index
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Aw010072asp/index
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: _vti_pvt/structure.cnf
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Db/admin_yly.sql
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Gov/manager
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: 1asp/index
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Manager/top.asp
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Guanyuhtml/index
ERROR - 2022-02-03 01:39:49 --> 404 Page Not Found: Control/index
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Detaila/purchaseorder.asp
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Submitasp/index
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Verificationasp/index
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Loginasp/index
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Serverhtml/index
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Dd/order.asp
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: %23m%23a%23n%23a%23g%23e%23r_/index.asp
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Wap/tixing.asp
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Ht/top.asp
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Networdasp/index
ERROR - 2022-02-03 01:39:50 --> 404 Page Not Found: Manager/index.asp
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Submit-tbasp/index
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Txt_index_dna_cntxt/index
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: T3/Account
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: 123/stat_login.asp
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Onlinerunasp/index
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Ye1asp/index
ERROR - 2022-02-03 01:39:51 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Vwaitasp/index
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Erroasp/index
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Instructions/toWait.do
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Error3asp/index
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: Jiankonghtm/index
ERROR - 2022-02-03 01:39:51 --> 404 Page Not Found: S1asp/index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Postasp/index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Submitasp/index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Save2asp/index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Captchaasp/index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Plus/guestbook
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Zhucheasp/index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Code/cxk_xym.asp
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Admin/Index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: User/step1.asp
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: %E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8Etxt/index
ERROR - 2022-02-03 01:39:52 --> 404 Page Not Found: Cxkcasp/index
ERROR - 2022-02-03 01:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 01:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 01:47:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:49:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:50:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:50:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:51:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:53:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:54:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:54:58 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2022-02-03 01:55:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 01:56:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:56:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:58:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 01:59:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:01:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:02:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:05:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:06:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 02:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:08:07 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2022-02-03 02:09:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:09:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 02:11:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:12:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:16:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:18:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:20:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:21:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 02:23:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:23:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:26:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:28:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:29:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:29:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:30:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:33:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:34:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:35:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 02:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 02:45:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:46:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:50:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 02:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 03:06:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:11:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:13:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 03:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:17:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:23:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 03:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:24:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:24:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 03:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 03:28:10 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2022-02-03 03:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 03:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:38:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:38:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 03:44:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 03:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:52:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 04:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 04:53:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 05:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:23:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 05:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:43:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 05:43:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 05:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 05:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 06:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 06:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 06:23:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 06:23:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 06:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 06:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 06:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 06:43:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 06:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 07:03:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 07:21:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 07:23:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:23:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:23:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:24:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:24:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:25:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:25:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:26:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:29:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:30:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:31:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:33:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:34:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:36:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:37:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:37:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:38:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:39:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:41:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:42:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:43:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:45:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:46:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:46:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:49:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:51:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:52:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:55:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:55:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:56:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:57:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:57:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:57:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:57:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:57:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:57:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 07:57:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:57:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:58:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 07:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:00:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 08:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 08:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:05:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 08:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 08:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:18:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 08:22:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 08:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:24:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 08:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:25:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 08:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:34:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 08:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 08:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 08:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 08:43:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 08:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 08:52:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 08:52:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 08:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:38:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:39:05 --> 404 Page Not Found: English/index
ERROR - 2022-02-03 09:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:39:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 09:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:44:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:46:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:46:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:47:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:48:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:48:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 09:48:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:48:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:50:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:50:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 09:51:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:52:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:53:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:55:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:55:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:56:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:57:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 09:58:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:00:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:01:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:01:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:02:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:03:11 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-02-03 10:04:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:04:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 10:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 10:06:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:06:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:07:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:09:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:09:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:11:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:11:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:13:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 10:13:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:14:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:15:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:16:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:16:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:18:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:18:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 10:19:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:19:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 10:20:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:20:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:21:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:22:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:22:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:22:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:23:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:25:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:25:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:25:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:26:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 10:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 10:26:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:26:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 10:26:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:26:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 10:28:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:28:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:29:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:29:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:29:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 10:30:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:31:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:31:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:32:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:33:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:33:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:34:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:34:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:36:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:36:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 10:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 10:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 10:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 10:51:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 10:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 11:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 11:46:54 --> 404 Page Not Found: Login/index
ERROR - 2022-02-03 12:00:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:01:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:06:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:06:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:07:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:08:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 12:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:11:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:14:54 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-03 12:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:17:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:17:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 12:18:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 12:21:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 12:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:23:59 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-03 12:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:29:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 12:35:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:43:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 12:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:53:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 12:55:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 12:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 13:04:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 13:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 13:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 13:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 13:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 13:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 13:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 13:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 13:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 13:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 13:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 13:45:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 13:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 13:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 13:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 14:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:01:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:02:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:04:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 14:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 14:07:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:08:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:15:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 14:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:22:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:22:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 14:23:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 14:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 14:29:27 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2022-02-03 14:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 14:34:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 14:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 14:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 15:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 15:02:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:10:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 15:16:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 15:17:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 15:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 15:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 15:32:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 15:32:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 15:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 15:41:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:41:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 15:52:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:52:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:52:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:52:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:53:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:53:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:53:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:53:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 15:56:06 --> 404 Page Not Found: City/16
ERROR - 2022-02-03 15:57:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 16:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 16:06:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 16:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 16:14:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 16:28:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 16:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 16:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 16:41:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 16:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 16:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 17:20:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 17:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:45:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 17:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 17:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 17:46:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 17:47:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 17:48:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 17:51:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 17:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:01:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 18:01:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 18:01:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 18:02:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 18:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:10:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:17:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:20:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:28:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:29:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:30:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 18:30:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:31:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 18:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:34:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 18:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:46:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 18:46:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 18:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 18:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 19:00:52 --> 404 Page Not Found: City/15
ERROR - 2022-02-03 19:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 19:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 19:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 19:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 19:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 19:38:29 --> 404 Page Not Found: App/views
ERROR - 2022-02-03 19:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 19:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 20:05:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 20:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 20:08:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 20:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 20:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 20:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 20:22:20 --> Severity: Warning --> Missing argument 1 for Taocan::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 181
ERROR - 2022-02-03 20:22:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 20:22:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 20:22:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 20:22:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-03 20:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 20:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 20:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 20:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 20:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:02:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 21:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:05:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 21:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 21:07:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 21:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 21:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:16:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 21:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 21:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 22:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 22:09:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 22:09:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-03 22:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 22:10:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 22:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 22:12:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 22:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 22:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 22:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 22:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 22:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 22:40:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 22:43:42 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-03 22:44:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 22:53:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 22:57:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-03 23:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:08:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 23:08:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 23:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 23:11:42 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-02-03 23:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 23:15:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 23:15:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 23:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-03 23:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:43:16 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-03 23:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-03 23:56:25 --> 404 Page Not Found: Robotstxt/index
