<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-24 00:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:00:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 00:01:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 00:03:02 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-24 00:03:03 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-24 00:03:04 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-24 00:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:04:26 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-24 00:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:05:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 00:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:07:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:09:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:17:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:18:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 00:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:26:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:28:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 00:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:29:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:33:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:35:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:35:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:36:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:37:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:38:57 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-24 00:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:40:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:40:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:40:45 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-24 00:42:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:42:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:42:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-24 00:42:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 00:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:43:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-24 00:43:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:44:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 00:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:44:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:45:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:45:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:49:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 00:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:50:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:56:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 00:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 00:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:02:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:04:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:07:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:10:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:11:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:12:29 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-07-24 01:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:13:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 01:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:20:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:24:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 01:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:31:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:34:23 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-24 01:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:38:42 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-24 01:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:42:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 01:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:56:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 01:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:56:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 01:57:12 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-24 01:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 01:58:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 02:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:02:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 02:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:09:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 02:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:10:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 02:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:15:52 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-24 02:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:23:30 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-24 02:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:31:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 02:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:32:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 02:33:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 02:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:37:23 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-24 02:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:50:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 02:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:52:29 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-24 02:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:54:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 02:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:54:44 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-07-24 02:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 02:58:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 02:59:14 --> Severity: Warning --> Missing argument 1 for Taocan::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 181
ERROR - 2021-07-24 03:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:14:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:24:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 03:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:24:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 03:24:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 03:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 03:24:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 03:25:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 03:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:34:21 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 03:34:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 03:34:21 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-24 03:34:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 03:34:21 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 03:34:21 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-24 03:34:21 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-24 03:34:22 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-24 03:34:23 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-24 03:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:37:16 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-24 03:38:14 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-24 03:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:39:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 03:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 03:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:39:58 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-07-24 03:40:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:40:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:40:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:41:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:42:27 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-24 03:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:43:12 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-24 03:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:43:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:48:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:49:37 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-24 03:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:50:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:52:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 03:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:55:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 03:58:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 03:59:14 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-24 03:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-24 04:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:02:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 04:03:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 04:03:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:08:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:13:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:18:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 04:20:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 04:20:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 04:20:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 04:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:21:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 04:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:24:00 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-24 04:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:24:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:29:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:38:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:38:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:38:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:39:02 --> 404 Page Not Found: Invoker/readonly
ERROR - 2021-07-24 04:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 04:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 04:41:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 04:42:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 04:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:42:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:43:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:44:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 04:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 04:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:45:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 04:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:50:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:54:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 04:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:57:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 04:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 04:59:56 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-24 05:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:06:48 --> 404 Page Not Found: Login/index
ERROR - 2021-07-24 05:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 05:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:11:08 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-24 05:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:14:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:16:58 --> 404 Page Not Found: Html-en/new-products-xnQJxLxEQmzH-3-0-1-1.html
ERROR - 2021-07-24 05:17:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:18:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:18:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 05:19:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 05:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:20:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:23:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 05:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:27:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:34:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:34:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:39:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 05:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:41:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:50:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:51:25 --> 404 Page Not Found: Rgsmng/index
ERROR - 2021-07-24 05:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:53:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 05:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:55:44 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-24 05:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:57:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 05:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 05:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:00:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:02:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:03:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:08:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:15:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:18:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 06:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:22:00 --> 404 Page Not Found: Sitemap81819html/index
ERROR - 2021-07-24 06:22:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:35:28 --> 404 Page Not Found: Previewdo/index
ERROR - 2021-07-24 06:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:35:59 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-24 06:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:38:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 06:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:50:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:56:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 06:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 06:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:05:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 07:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:07:22 --> 404 Page Not Found: Down/android
ERROR - 2021-07-24 07:07:30 --> 404 Page Not Found: 3976316html/index
ERROR - 2021-07-24 07:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 07:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 07:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:14:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 07:14:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 07:15:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 07:16:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 07:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:32:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 07:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:36:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 07:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:39:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 07:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:42:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 07:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:50:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 07:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:50:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 07:50:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 07:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:56:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 07:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 07:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:03:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 08:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:14:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 08:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:18:44 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-24 08:19:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 08:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:25:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 08:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:27:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 08:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:37:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 08:37:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 08:37:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-24 08:37:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 08:37:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 08:37:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-24 08:37:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-24 08:37:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-24 08:37:10 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-24 08:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:40:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 08:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:41:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 08:42:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 08:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:50:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 08:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 08:58:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 08:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:01:57 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-24 09:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 09:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 09:23:49 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-24 09:23:49 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-24 09:24:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 09:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:30:08 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-24 09:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 09:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:37:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 09:37:57 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-24 09:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:53:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 09:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:55:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 09:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:55:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 09:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 09:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:02:56 --> 404 Page Not Found: English/index
ERROR - 2021-07-24 10:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 10:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:12:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 10:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:13:57 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-24 10:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 10:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 10:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 10:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:37:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 10:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:40:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 10:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:42:59 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-24 10:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:46:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 10:47:14 --> 404 Page Not Found: Rongame_beta/rgfate
ERROR - 2021-07-24 10:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 10:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:12:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:12:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:19:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 11:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:23:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:23:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:23:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:23:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:23:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:24:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:24:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:24:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:24:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:25:24 --> 404 Page Not Found: City/1
ERROR - 2021-07-24 11:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:27:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 11:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:30:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 11:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:32:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 11:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:34:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 11:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:35:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 11:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:36:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 11:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 11:37:15 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 11:37:16 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-24 11:37:17 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-24 11:37:17 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-24 11:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:38:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 11:38:57 --> 404 Page Not Found: Env/index
ERROR - 2021-07-24 11:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 11:39:36 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-24 11:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:40:56 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-24 11:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:42:15 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-24 11:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:50:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 11:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:53:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:53:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:53:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:53:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:54:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 11:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 11:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:03:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 12:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:13:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 12:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:16:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 12:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:24:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 12:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:24:34 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-24 12:24:50 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-24 12:25:09 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-24 12:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:25:28 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-24 12:25:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 12:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:25:48 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-24 12:26:08 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-24 12:26:26 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-24 12:27:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 12:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:28:10 --> 404 Page Not Found: City/10
ERROR - 2021-07-24 12:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:29:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 12:31:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 12:31:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 12:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 12:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:38:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 12:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:39:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-24 12:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:40:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 12:40:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 12:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:49:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 12:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:54:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 12:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 12:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:04:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 13:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:06:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 13:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:10:00 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-07-24 13:10:39 --> 404 Page Not Found: City/1
ERROR - 2021-07-24 13:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:17:15 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-24 13:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:18:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 13:18:33 --> 404 Page Not Found: Rongame_beta/rgfate
ERROR - 2021-07-24 13:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:25:50 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-07-24 13:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:27:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 13:27:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 13:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:28:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 13:28:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 13:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:31:07 --> 404 Page Not Found: Vod-read-id-2808html/index
ERROR - 2021-07-24 13:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:35:34 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-24 13:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:40:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 13:41:10 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-24 13:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:46:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 13:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:48:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 13:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:58:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 13:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 13:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:19:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 14:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:22:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 14:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:30:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 14:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:31:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 14:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:32:16 --> 404 Page Not Found: City/2
ERROR - 2021-07-24 14:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:37:29 --> 404 Page Not Found: English/index
ERROR - 2021-07-24 14:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:51:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 14:51:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 14:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 14:51:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 14:51:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 14:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 14:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:52:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 14:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 14:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 14:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 14:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:04:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:08:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 15:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:28:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:31:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:34:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 15:35:22 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 15:35:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 15:35:22 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-24 15:35:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 15:35:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-24 15:35:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-24 15:35:24 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-24 15:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:36:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:39:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:39:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 15:39:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:44:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 15:46:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:50:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:51:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 15:51:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:54:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:55:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 15:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:56:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:58:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 15:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 15:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 16:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 16:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 16:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:04:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 16:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:08:24 --> 404 Page Not Found: City/10
ERROR - 2021-07-24 16:08:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 16:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:11:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 16:11:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 16:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:13:17 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-24 16:13:17 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-24 16:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 16:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:15:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 16:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:26:42 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-24 16:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:26:49 --> 404 Page Not Found: City/1
ERROR - 2021-07-24 16:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:29:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 16:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:30:45 --> 404 Page Not Found: Html-en/hot-products-xnQJxLxEQmzH-1--1-1.html
ERROR - 2021-07-24 16:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:33:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 16:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-24 16:35:14 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-24 16:35:15 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-24 16:35:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-24 16:35:16 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-24 16:35:16 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-24 16:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:45:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 16:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:46:10 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-24 16:46:44 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-24 16:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:47:14 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-24 16:47:45 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-24 16:48:14 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-24 16:48:45 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-24 16:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:48:59 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-24 16:49:10 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-24 16:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:51:49 --> 404 Page Not Found: 10/10000
ERROR - 2021-07-24 16:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:57:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 16:57:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 16:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 16:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:00:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:01:58 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2021-07-24 17:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:04:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:04:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:10:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 17:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:12:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 17:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:18:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 17:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 17:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:24:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 17:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:30:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:44:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 17:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:47:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:47:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:47:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:47:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 17:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:51:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:55:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:56:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 17:59:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 17:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:01:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:02:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 18:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:05:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:05:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:05:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:05:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:06:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:08:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:08:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:09:10 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-07-24 18:09:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:09:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:13:15 --> 404 Page Not Found: Servers/index
ERROR - 2021-07-24 18:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:17:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:22:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:26:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:26:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:27:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:27:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 18:28:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:29:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:32:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:32:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:32:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:32:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:32:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 18:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:33:18 --> 404 Page Not Found: 10/10000
ERROR - 2021-07-24 18:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:35:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 18:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:36:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 18:36:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:44:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 18:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:51:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 18:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 18:59:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 18:59:54 --> 404 Page Not Found: English/index
ERROR - 2021-07-24 19:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:04:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 19:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:05:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:06:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:07:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:07:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:21:25 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-24 19:21:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 19:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:25:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:35:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:35:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:35:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:35:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:36:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:37:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 19:37:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:39:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:39:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:39:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:40:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:43:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:44:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:46:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:47:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 19:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:52:12 --> 404 Page Not Found: 1/10000
ERROR - 2021-07-24 19:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:54:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 19:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 19:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:55:32 --> 404 Page Not Found: City/index
ERROR - 2021-07-24 19:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 19:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:00:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:03:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 20:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:12:28 --> 404 Page Not Found: Sitemap50606html/index
ERROR - 2021-07-24 20:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:13:42 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2021-07-24 20:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:27:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 20:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:28:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 20:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:35:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 20:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:44:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:45:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 20:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:46:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:48:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 20:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 20:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:49:19 --> 404 Page Not Found: Sitemap35488html/index
ERROR - 2021-07-24 20:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:50:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 20:50:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 20:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:55:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 20:57:11 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2021-07-24 20:57:13 --> 404 Page Not Found: Phpinfo/index
ERROR - 2021-07-24 20:57:14 --> 404 Page Not Found: Awsyml/index
ERROR - 2021-07-24 20:57:15 --> 404 Page Not Found: Envbak/index
ERROR - 2021-07-24 20:57:17 --> 404 Page Not Found: Aws/credentials
ERROR - 2021-07-24 20:57:22 --> 404 Page Not Found: Config/aws.yml
ERROR - 2021-07-24 20:58:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 20:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 20:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:00:34 --> 404 Page Not Found: Cn/Productsa.asp
ERROR - 2021-07-24 21:00:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:11:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:11:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 21:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:20:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:21:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 21:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:26:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-24 21:26:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:26:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:26:29 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-24 21:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:28:29 --> 404 Page Not Found: Sitemap69337html/index
ERROR - 2021-07-24 21:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 21:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:31:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:32:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:32:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:32:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:33:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:34:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 21:34:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:34:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-24 21:34:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 21:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:36:30 --> 404 Page Not Found: Sitemap59663html/index
ERROR - 2021-07-24 21:37:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:38:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 21:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:42:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:42:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:43:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 21:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:43:40 --> 404 Page Not Found: City/1
ERROR - 2021-07-24 21:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:45:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 21:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:46:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 21:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:54:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 21:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:57:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 21:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 21:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:08:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 22:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:10:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:13:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:14:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:15:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:17:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:17:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 22:18:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 22:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:19:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:22:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:23:00 --> 404 Page Not Found: Sitemap19327html/index
ERROR - 2021-07-24 22:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:24:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:25:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 22:26:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:26:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:28:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 22:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:30:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:34:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 22:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:37:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 22:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:39:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 22:39:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:39:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 22:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 22:50:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 22:50:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 22:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:51:46 --> 404 Page Not Found: Script/index
ERROR - 2021-07-24 22:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:52:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-24 22:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:55:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 22:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:58:30 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-24 22:58:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 22:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 22:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:04:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:06:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 23:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:12:22 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-24 23:12:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:13:50 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-24 23:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:14:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:15:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:18:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:18:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:20:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:24:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:25:02 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-24 23:25:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:26:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:26:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:32:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:35:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-24 23:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:40:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-24 23:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:42:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:44:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:46:05 --> 404 Page Not Found: City/16
ERROR - 2021-07-24 23:46:05 --> 404 Page Not Found: City/16
ERROR - 2021-07-24 23:46:05 --> 404 Page Not Found: City/16
ERROR - 2021-07-24 23:46:13 --> 404 Page Not Found: City/16
ERROR - 2021-07-24 23:46:21 --> 404 Page Not Found: City/16
ERROR - 2021-07-24 23:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:47:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:49:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 23:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:52:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 23:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:54:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-24 23:54:44 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-24 23:54:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-24 23:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-24 23:59:36 --> 404 Page Not Found: Robotstxt/index
