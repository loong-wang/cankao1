<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-05 00:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:02:10 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-05 00:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:06:32 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-08-05 00:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:08:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 00:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:13:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 00:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:17:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:18:42 --> 404 Page Not Found: English/index
ERROR - 2021-08-05 00:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:25:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:26:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:27:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:28:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:28:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:28:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:29:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:32:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 00:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:50:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:52:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:54:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:55:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 00:55:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 00:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:56:36 --> 404 Page Not Found: Nmaplowercheck1628096186/index
ERROR - 2021-08-05 00:56:37 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-08-05 00:56:37 --> 404 Page Not Found: Evox/about
ERROR - 2021-08-05 00:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 00:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:08:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:08:38 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-05 01:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-05 01:12:38 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 01:12:39 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-05 01:12:40 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-05 01:12:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:17:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 01:17:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:18:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:22:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:26:20 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-05 01:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:29:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:32:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:32:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:42:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:45:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:50:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:52:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:52:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 01:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 01:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 01:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:57:52 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-05 01:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 01:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:02:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:03:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:06:17 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-05 02:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:12:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:12:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:13:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:13:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:15:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:19:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 02:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:20:01 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-05 02:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:23:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:23:17 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-05 02:23:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:23:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:27:18 --> 404 Page Not Found: City/1
ERROR - 2021-08-05 02:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:36:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:42:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:43:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:51:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 02:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:53:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 02:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:57:50 --> 404 Page Not Found: City/15
ERROR - 2021-08-05 02:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 02:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:03:13 --> 404 Page Not Found: City/15
ERROR - 2021-08-05 03:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:13:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:14:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:23:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:25:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:36:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:42:10 --> 404 Page Not Found: 1/10000
ERROR - 2021-08-05 03:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:42:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:55:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:55:54 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-05 03:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 03:57:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 03:58:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:01:02 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-05 04:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:01:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:04:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:04:47 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-05 04:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:13:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:19:42 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-05 04:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:21:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:21:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 04:21:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 04:21:44 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-05 04:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:26:13 --> 404 Page Not Found: City/1
ERROR - 2021-08-05 04:26:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:27:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:28:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:32:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:37:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:43:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:46:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:46:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:48:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:57:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 04:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 04:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:00:20 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-05 05:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:03:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:12:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:16:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:18:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 05:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:31:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:32:54 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-05 05:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:33:09 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-05 05:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:33:28 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-05 05:33:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:33:48 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-05 05:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:41:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:51:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 05:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:57:35 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-05 05:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 05:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:00:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:01:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:01:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:01:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:02:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:06:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 06:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 06:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:28:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:33:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:34:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:37:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:41:08 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-05 06:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:46:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 06:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:48:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 06:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:48:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:48:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 06:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 06:59:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 06:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:03:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 07:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:07:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 07:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:10:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 07:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:18:01 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 07:18:21 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-05 07:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:21:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 07:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 07:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:31:23 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 07:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:42:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 07:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 07:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:06:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 08:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:11:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 08:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:16:41 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-05 08:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 08:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 08:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:21:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 08:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 08:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:34:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 08:35:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 08:35:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 08:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 08:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:36:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 08:36:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 08:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:42:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 08:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 08:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 08:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:42:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 08:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:45:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 08:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:46:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 08:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:55:39 --> 404 Page Not Found: City/2
ERROR - 2021-08-05 08:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 08:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-05 09:05:32 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 09:05:33 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-05 09:05:34 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-05 09:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:06:32 --> 404 Page Not Found: CurrentTime/index
ERROR - 2021-08-05 09:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:07:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:09:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 09:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:12:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:13:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:20:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 09:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:21:52 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-05 09:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 09:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:29:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 09:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:37:24 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-08-05 09:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:44:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 09:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:48:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 09:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 09:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:03:28 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-08-05 10:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:03:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:05:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:06:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:07:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 10:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:09:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 10:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:12:22 --> 404 Page Not Found: English/index
ERROR - 2021-08-05 10:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:18:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 10:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:22:14 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-05 10:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:31:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:31:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 10:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:34:25 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-08-05 10:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:39:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 10:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:42:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 10:42:38 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 10:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:47:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 10:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:55:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 10:55:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 10:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 10:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:02:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:02:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:03:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:03:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:03:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:03:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:03:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:03:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:03:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:03:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:10:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:10:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:10:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:10:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:10:30 --> 404 Page Not Found: City/16
ERROR - 2021-08-05 11:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:10:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:11:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 11:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:13:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:13:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:13:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:13:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:15:54 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-05 11:16:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:16:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:16:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:16:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:17:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 11:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:19:18 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-05 11:19:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 11:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:26:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 11:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:30:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:32:28 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-05 11:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:32:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 11:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:33:36 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-05 11:34:04 --> 404 Page Not Found: City/17
ERROR - 2021-08-05 11:34:08 --> 404 Page Not Found: City/17
ERROR - 2021-08-05 11:34:08 --> 404 Page Not Found: City/17
ERROR - 2021-08-05 11:34:11 --> 404 Page Not Found: City/17
ERROR - 2021-08-05 11:34:15 --> 404 Page Not Found: City/17
ERROR - 2021-08-05 11:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:34:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 11:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:40:53 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 11:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:44:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:45:49 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-05 11:46:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:48:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:48:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 11:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:52:17 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-05 11:52:18 --> 404 Page Not Found: Administrator/index
ERROR - 2021-08-05 11:52:19 --> 404 Page Not Found: User/index
ERROR - 2021-08-05 11:52:19 --> 404 Page Not Found: admin//index
ERROR - 2021-08-05 11:52:24 --> 404 Page Not Found: admin/Users/login_do
ERROR - 2021-08-05 11:52:25 --> 404 Page Not Found: Manager/index
ERROR - 2021-08-05 11:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:57:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 11:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:59:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:59:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 11:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:01:10 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-05 12:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:04:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:06:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:06:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:06:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:07:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 12:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:07:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:10:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:11:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:12:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:12:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:12:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:13:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:14:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:20:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 12:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:27:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 12:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:30:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:44:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:47:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:51:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 12:51:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 12:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:52:01 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 12:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:54:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 12:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 12:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:00:45 --> 404 Page Not Found: 404/index.html
ERROR - 2021-08-05 13:00:45 --> 404 Page Not Found: 404/index.html
ERROR - 2021-08-05 13:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:04:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 13:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 13:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 13:07:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 13:07:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 13:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:12:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 13:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:18:28 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-05 13:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:19:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:19:54 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2021-08-05 13:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:24:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:25:09 --> 404 Page Not Found: 1/all
ERROR - 2021-08-05 13:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:28:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:35:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 13:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:39:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:39:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:45:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:45:27 --> 404 Page Not Found: Company/view
ERROR - 2021-08-05 13:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:46:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:52:24 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-05 13:52:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:59:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 13:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 13:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:01:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 14:02:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 14:04:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 14:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:06:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 14:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:09:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 14:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:12:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 14:12:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 14:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:19:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 14:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:23:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 14:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:28:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 14:29:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 14:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:32:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 14:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:33:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 14:34:12 --> 404 Page Not Found: City/2
ERROR - 2021-08-05 14:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:37:07 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 14:37:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 14:38:05 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 14:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:38:18 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 14:38:20 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 14:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:40:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:56:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 14:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 14:58:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 15:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:01:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 15:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:07:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 15:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:10:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:12:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:13:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:19:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:32:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:35:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:40:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 15:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:44:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 15:46:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:49:33 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-05 15:50:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 15:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:56:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 15:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:56:27 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-05 15:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 15:58:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 16:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:01:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 16:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:04:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 16:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:06:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 16:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:09:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 16:09:07 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-05 16:09:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 16:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:14:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 16:14:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 16:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:19:11 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 16:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:20:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 16:20:42 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-05 16:22:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-05 16:22:06 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-05 16:23:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 16:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:24:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:24:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:24:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:26:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:27:07 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 16:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:30:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:30:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 16:30:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:31:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:31:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:31:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:32:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:33:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:33:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:34:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:38:47 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-05 16:39:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 16:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:45:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 16:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:49:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 16:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:53:59 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-05 16:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 16:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:12:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 17:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:14:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 17:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:15:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:17:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:18:58 --> 404 Page Not Found: App/views
ERROR - 2021-08-05 17:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:19:13 --> 404 Page Not Found: App/views
ERROR - 2021-08-05 17:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:19:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:20:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:24:37 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-05 17:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:26:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 17:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:29:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:30:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:33:47 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-08-05 17:35:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:36:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:38:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 17:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:40:28 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-05 17:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:40:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:42:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:44:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:44:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:45:40 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 17:45:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 17:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:46:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:46:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:46:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:47:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 17:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:58:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 17:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 17:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:01:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:01:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:02:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:02:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 18:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:02:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:15:38 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 18:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:15:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:15:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:15:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:15:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:16:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:17:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:18:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 18:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:19:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:24:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:39 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-05 18:24:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:24:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 18:25:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:25:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:26:47 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-05 18:26:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:26:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:27:59 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-05 18:28:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:28:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 18:29:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 18:29:28 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-05 18:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:29:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:30:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:31:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 18:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:31:50 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-05 18:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:32:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:33:02 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-05 18:33:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:37:27 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-05 18:37:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 18:39:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:39:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:43:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:43:31 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-05 18:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:45:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:45:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 18:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:53:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 18:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:54:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 18:54:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 18:54:50 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-05 18:54:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-05 18:54:50 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 18:54:50 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-05 18:54:51 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-05 18:54:52 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-05 18:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:56:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 18:57:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 18:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 18:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:00:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:01:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:01:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:02:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:08:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:12:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:17:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:17:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:17:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:20:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:21:13 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-05 19:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:24:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:28:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:29:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 19:29:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:29:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:29:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:30:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:30:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:33:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:35:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:36:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:36:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:40:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:40:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:40:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:40:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:40:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:40:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:40:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:40:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:41:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:42:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:42:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:42:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:42:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-05 19:45:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:47:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:56:29 --> 404 Page Not Found: City/1
ERROR - 2021-08-05 19:58:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 19:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 19:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 19:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:00:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:04:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:07:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:07:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:11:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:12:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 20:16:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 20:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:25:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 20:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:28:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:30:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:30:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:33:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:34:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:43:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 20:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 20:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:47:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:49:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 20:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 20:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:01:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 21:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:03:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:08:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:12:26 --> 404 Page Not Found: Env/index
ERROR - 2021-08-05 21:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:13:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 21:13:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:14:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:18:51 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-08-05 21:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:24:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:29:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:30:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:33:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:33:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 21:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:35:37 --> 404 Page Not Found: Vod-read-id-2758html/index
ERROR - 2021-08-05 21:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:36:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 21:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:37:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:40:01 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-08-05 21:40:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:42:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:43:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:43:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:44:06 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-05 21:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:51:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:57:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 21:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 21:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:09:43 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-08-05 22:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:10:10 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-05 22:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:15:42 --> 404 Page Not Found: 1/10000
ERROR - 2021-08-05 22:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:21:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 22:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:23:59 --> 404 Page Not Found: City/1
ERROR - 2021-08-05 22:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:26:07 --> 404 Page Not Found: English/index
ERROR - 2021-08-05 22:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:26:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-05 22:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:29:51 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-08-05 22:29:52 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-08-05 22:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:29:54 --> 404 Page Not Found: Haoma/index
ERROR - 2021-08-05 22:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:31:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 22:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:35:35 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-05 22:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 22:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:42:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 22:43:37 --> 404 Page Not Found: Vod-search-wd-WWW3JPAV3COM-p-1html/index
ERROR - 2021-08-05 22:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:49:04 --> 404 Page Not Found: Vod-show-id-13-p-1html/index
ERROR - 2021-08-05 22:49:42 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-05 22:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:56:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 22:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 22:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:02:07 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-05 23:02:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:05:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 23:05:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 23:05:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 23:05:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 23:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-05 23:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:09:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:13:33 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-08-05 23:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:18:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:28:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 23:28:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-05 23:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:35:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-05 23:35:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:40:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:45:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:45:40 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-05 23:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:53:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:53:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-05 23:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-05 23:59:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
