<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-25 00:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:05:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:05:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:05:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:05:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:06:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 00:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 00:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 00:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 00:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:24:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 00:24:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 00:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 00:28:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 00:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:31:44 --> 404 Page Not Found: Env/index
ERROR - 2021-09-25 00:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:39:45 --> 404 Page Not Found: Xy/index
ERROR - 2021-09-25 00:39:45 --> 404 Page Not Found: M/index
ERROR - 2021-09-25 00:39:45 --> 404 Page Not Found: Otc/index
ERROR - 2021-09-25 00:39:45 --> 404 Page Not Found: Loan/index
ERROR - 2021-09-25 00:39:49 --> 404 Page Not Found: Homes/index
ERROR - 2021-09-25 00:39:50 --> 404 Page Not Found: H5/index
ERROR - 2021-09-25 00:39:55 --> 404 Page Not Found: Im/h5
ERROR - 2021-09-25 00:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:40:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:40:13 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-09-25 00:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:40:26 --> 404 Page Not Found: Api/v1
ERROR - 2021-09-25 00:40:26 --> 404 Page Not Found: Im/App
ERROR - 2021-09-25 00:40:27 --> 404 Page Not Found: Apis/api
ERROR - 2021-09-25 00:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:40:31 --> 404 Page Not Found: M/ticker
ERROR - 2021-09-25 00:40:47 --> 404 Page Not Found: Home/Bind
ERROR - 2021-09-25 00:40:52 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-09-25 00:40:52 --> 404 Page Not Found: Home/Get
ERROR - 2021-09-25 00:40:59 --> 404 Page Not Found: Legal/currency
ERROR - 2021-09-25 00:40:59 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-09-25 00:41:03 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-09-25 00:41:03 --> 404 Page Not Found: Api/v1
ERROR - 2021-09-25 00:41:04 --> 404 Page Not Found: Mytio/config
ERROR - 2021-09-25 00:41:11 --> 404 Page Not Found: Api/index
ERROR - 2021-09-25 00:41:20 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-09-25 00:41:22 --> 404 Page Not Found: Api/Index
ERROR - 2021-09-25 00:41:23 --> 404 Page Not Found: Api/index
ERROR - 2021-09-25 00:41:23 --> 404 Page Not Found: Api/common
ERROR - 2021-09-25 00:41:49 --> 404 Page Not Found: Ajax/index
ERROR - 2021-09-25 00:41:54 --> 404 Page Not Found: Api/customerServiceLink
ERROR - 2021-09-25 00:41:55 --> 404 Page Not Found: Api/user
ERROR - 2021-09-25 00:41:56 --> 404 Page Not Found: Static/mobile
ERROR - 2021-09-25 00:42:05 --> 404 Page Not Found: Assets/app-manifest.json
ERROR - 2021-09-25 00:42:05 --> 404 Page Not Found: App/common
ERROR - 2021-09-25 00:42:06 --> 404 Page Not Found: S_api/basic
ERROR - 2021-09-25 00:42:07 --> 404 Page Not Found: Api/currency
ERROR - 2021-09-25 00:42:12 --> 404 Page Not Found: Home/login
ERROR - 2021-09-25 00:42:14 --> 404 Page Not Found: Wap/Api
ERROR - 2021-09-25 00:42:14 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-09-25 00:42:18 --> 404 Page Not Found: Static/data
ERROR - 2021-09-25 00:42:27 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-25 00:42:30 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-09-25 00:42:32 --> 404 Page Not Found: Infe/rest
ERROR - 2021-09-25 00:42:37 --> 404 Page Not Found: V1/management
ERROR - 2021-09-25 00:42:38 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-09-25 00:42:39 --> 404 Page Not Found: Api/exclude
ERROR - 2021-09-25 00:42:43 --> 404 Page Not Found: Api/public
ERROR - 2021-09-25 00:42:43 --> 404 Page Not Found: Wap/Api
ERROR - 2021-09-25 00:42:47 --> 404 Page Not Found: Wap/trading
ERROR - 2021-09-25 00:42:49 --> 404 Page Not Found: Service/index
ERROR - 2021-09-25 00:42:55 --> 404 Page Not Found: Infe/rest
ERROR - 2021-09-25 00:42:55 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-09-25 00:42:56 --> 404 Page Not Found: S_api/basic
ERROR - 2021-09-25 00:43:01 --> 404 Page Not Found: Api/uploads
ERROR - 2021-09-25 00:43:02 --> 404 Page Not Found: Api/wallet
ERROR - 2021-09-25 00:43:02 --> 404 Page Not Found: Api/v1
ERROR - 2021-09-25 00:43:02 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-09-25 00:43:05 --> 404 Page Not Found: Api/v
ERROR - 2021-09-25 00:43:07 --> 404 Page Not Found: Api/config-init
ERROR - 2021-09-25 00:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:55:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-25 00:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 00:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 00:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:05:11 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-25 01:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:05:46 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 01:05:47 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-25 01:05:48 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-25 01:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:09:21 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-25 01:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:26:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 01:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:32:29 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-09-25 01:32:29 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-09-25 01:32:30 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-25 01:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:45:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 01:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 01:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:07:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 02:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:11:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 02:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:14:42 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-25 02:14:42 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-25 02:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:16:08 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-25 02:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:16:24 --> 404 Page Not Found: City/2
ERROR - 2021-09-25 02:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:20:20 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-25 02:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:30:49 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-25 02:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:38:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 02:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:42:59 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-25 02:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:54:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 02:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:57:10 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-25 02:59:11 --> 404 Page Not Found: City/index
ERROR - 2021-09-25 02:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 02:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:01:40 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-25 03:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:02:31 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-25 03:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:08:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 03:08:38 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-25 03:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:17:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-25 03:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:24:57 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-25 03:24:58 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-25 03:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:30:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:30:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:35:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:36:31 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-25 03:36:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:38:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:38:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:44:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 03:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:56:55 --> 404 Page Not Found: English/index
ERROR - 2021-09-25 03:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 03:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:01:02 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-09-25 04:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:14:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 04:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 04:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:35:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 04:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:35:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 04:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 04:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:04:33 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-09-25 05:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:17:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 05:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:25:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 05:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:33:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 05:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:43:53 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-25 05:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:49:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 05:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 05:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:21:51 --> 404 Page Not Found: City/1
ERROR - 2021-09-25 06:21:55 --> 404 Page Not Found: City/1
ERROR - 2021-09-25 06:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:32:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 06:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:38:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 06:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:40:16 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-25 06:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:41:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 06:41:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-25 06:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:58:39 --> 404 Page Not Found: Login/index
ERROR - 2021-09-25 06:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 06:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:03:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-25 07:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:14:48 --> 404 Page Not Found: City/1
ERROR - 2021-09-25 07:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 07:25:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 07:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:27:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 07:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:46:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-25 07:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:49:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 07:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:52:12 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-25 07:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:55:01 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-25 07:55:15 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-25 07:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 07:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:08:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:08:55 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-09-25 08:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:17:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:19:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:20:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:20:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:20:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:20:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:20:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:21:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:21:36 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-25 08:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:29:03 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-25 08:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:29:34 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-25 08:29:36 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-25 08:29:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-25 08:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:31:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:31:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 08:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:35:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-25 08:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:44:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:44:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 08:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:47:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:48:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 08:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:52:31 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-25 08:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 08:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:09:50 --> 404 Page Not Found: English/index
ERROR - 2021-09-25 09:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:13:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 09:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:17:30 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-25 09:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:31:21 --> 404 Page Not Found: Searchasp/index
ERROR - 2021-09-25 09:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:46:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 09:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 09:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 09:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:06:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:09:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 10:09:01 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 10:09:01 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-25 10:09:01 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 10:09:01 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 10:09:01 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-25 10:09:02 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 10:09:03 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-25 10:09:04 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-25 10:09:04 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-25 10:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:12:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 10:12:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:12:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 10:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:12:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 10:12:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 10:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:19:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:20:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:28:24 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-25 10:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:30:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:32:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:32:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 10:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:39:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 10:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:46:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 10:48:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 10:48:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 10:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 10:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:00:03 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-25 11:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:02:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 11:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:04:08 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-25 11:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:14:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:17:53 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-09-25 11:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:23:50 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-25 11:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:25:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 11:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:25:58 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-25 11:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:26:59 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-25 11:28:06 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-25 11:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:28:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 11:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:32:05 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-25 11:33:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:33:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:34:05 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-25 11:34:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:34:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 11:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:35:53 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-25 11:35:56 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-25 11:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:40:27 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-09-25 11:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 11:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:53:47 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-25 11:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 11:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:09:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 12:10:30 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-25 12:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 12:13:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 12:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:14:10 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-25 12:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:17:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 12:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 12:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:19:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 12:19:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 12:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:22:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 12:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:24:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 12:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:26:16 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-25 12:26:59 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-25 12:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:27:39 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-25 12:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:28:54 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-25 12:29:32 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-25 12:30:44 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-25 12:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:30:51 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-25 12:31:11 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-25 12:31:23 --> 404 Page Not Found: admin/Controller/extension
ERROR - 2021-09-25 12:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:32:53 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-25 12:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:33:34 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-25 12:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:34:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:40:51 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-25 12:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:53:07 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-25 12:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:55:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 12:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 12:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:06:26 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-25 13:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:08:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 13:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:09:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 13:09:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:21:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 13:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:23:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-25 13:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:29:45 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-25 13:29:46 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-25 13:30:15 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-25 13:30:18 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-25 13:30:22 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-25 13:31:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:32:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:32:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:33:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:34:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 13:34:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:35:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:35:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:35:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 13:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:41:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 13:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:46:16 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-25 13:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:51:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:53:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 13:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:54:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 13:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 13:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:09:37 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-25 14:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:12:43 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-25 14:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:16:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 14:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:17:53 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-25 14:18:11 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-25 14:18:12 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-25 14:18:13 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-25 14:19:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 14:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:23:39 --> 404 Page Not Found: City/1
ERROR - 2021-09-25 14:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:46:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 14:47:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 14:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:48:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 14:49:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 14:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 14:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 14:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:52:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 14:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:56:04 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-09-25 14:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 14:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:20:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 15:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:22:57 --> 404 Page Not Found: Shell/index
ERROR - 2021-09-25 15:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:25:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:27:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:31:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:32:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:32:46 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-25 15:32:47 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-25 15:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:36:59 --> 404 Page Not Found: English/index
ERROR - 2021-09-25 15:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:41:58 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-09-25 15:41:58 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-25 15:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:42:45 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-25 15:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:45:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 15:45:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 15:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:49:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:50:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:51:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:51:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:52:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:54:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:55:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:56:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 15:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 15:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:03:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:06:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:06:56 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-25 16:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:07:50 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-25 16:08:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:08:47 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-25 16:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:09:39 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-25 16:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:09:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:10:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:10:36 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-25 16:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:12:28 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-25 16:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:14:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:16:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 16:16:02 --> 404 Page Not Found: Order/index
ERROR - 2021-09-25 16:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:23:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 16:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:25:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:29:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 16:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:36:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 16:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:38:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 16:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:40:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:41:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:41:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:50:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:50:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:51:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:57:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 16:57:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:58:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 16:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 16:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:04:28 --> 404 Page Not Found: City/19
ERROR - 2021-09-25 17:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:05:50 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-25 17:05:51 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-25 17:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:13:02 --> 404 Page Not Found: City/2
ERROR - 2021-09-25 17:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:17:46 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2021-09-25 17:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:22:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:26:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:28:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:28:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 17:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:29:11 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 17:29:11 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 17:29:11 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-25 17:29:11 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 17:29:11 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 17:29:12 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 17:29:13 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 17:29:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-25 17:29:15 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-25 17:29:15 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-25 17:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:30:02 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-25 17:30:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:31:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:32:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:34:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:35:10 --> 404 Page Not Found: City/16
ERROR - 2021-09-25 17:35:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 17:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:42:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:45:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:47:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:49:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 17:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:51:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 17:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:52:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:52:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:53:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 17:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:58:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 17:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:00:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 18:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:01:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:05:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:05:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:09:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:11:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:12:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:16:24 --> 404 Page Not Found: Env/index
ERROR - 2021-09-25 18:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:26:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:31:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 18:32:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 18:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:44:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 18:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:49:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 18:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:49:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 18:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 18:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:01:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:03:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:06:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 19:06:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:08:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 19:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:09:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 19:09:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 19:09:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-25 19:09:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-25 19:09:52 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-25 19:09:53 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-25 19:09:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-25 19:09:53 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-25 19:09:53 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-25 19:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:13:05 --> 404 Page Not Found: English/index
ERROR - 2021-09-25 19:13:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 19:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:15:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:17:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 19:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:25:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:25:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:34:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:36:10 --> 404 Page Not Found: Env/index
ERROR - 2021-09-25 19:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:38:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 19:38:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 19:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:48:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 19:48:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 19:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:56:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 19:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 19:59:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 20:01:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 20:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:14:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 20:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:21:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 20:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:26:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 20:26:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 20:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:33:21 --> 404 Page Not Found: Env/index
ERROR - 2021-09-25 20:33:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 20:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:33:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 20:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:35:19 --> 404 Page Not Found: City/1
ERROR - 2021-09-25 20:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:41:10 --> 404 Page Not Found: Sitemap59599html/index
ERROR - 2021-09-25 20:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:44:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 20:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:47:33 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-25 20:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:51:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 20:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:54:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 20:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:58:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 20:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 20:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:01:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 21:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:02:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 21:03:14 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-25 21:03:15 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-25 21:03:16 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-25 21:03:17 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-25 21:03:18 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-09-25 21:03:20 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-25 21:03:20 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-25 21:03:21 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-25 21:03:21 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-09-25 21:03:22 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-25 21:03:22 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-25 21:03:23 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-25 21:03:23 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-25 21:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:04:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 21:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 21:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 21:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:24:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 21:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:31:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 21:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:34:21 --> 404 Page Not Found: English/index
ERROR - 2021-09-25 21:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 21:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:22:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 22:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:23:38 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-25 22:23:38 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-25 22:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:28:21 --> 404 Page Not Found: Manager/html
ERROR - 2021-09-25 22:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:43:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-25 22:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 22:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 22:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 22:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:00:54 --> 404 Page Not Found: City/1
ERROR - 2021-09-25 23:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:23:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 23:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:31:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-25 23:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:40:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:43:10 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-25 23:43:49 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-25 23:44:13 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-25 23:44:35 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-25 23:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:45:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:47:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 23:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:49:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-25 23:51:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-25 23:51:15 --> 404 Page Not Found: City/index
ERROR - 2021-09-25 23:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:51:59 --> 404 Page Not Found: City/1
ERROR - 2021-09-25 23:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:52:48 --> 404 Page Not Found: City/10
ERROR - 2021-09-25 23:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:53:32 --> 404 Page Not Found: City/15
ERROR - 2021-09-25 23:54:01 --> 404 Page Not Found: City/16
ERROR - 2021-09-25 23:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:54:05 --> 404 Page Not Found: City/2
ERROR - 2021-09-25 23:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-25 23:59:41 --> 404 Page Not Found: Robotstxt/index
