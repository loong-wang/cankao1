<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-04 00:01:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 00:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 00:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 00:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 00:02:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 00:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 00:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:12:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 00:12:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 00:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:14:30 --> 404 Page Not Found: City/15
ERROR - 2021-08-04 00:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:21:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 00:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:27:45 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-04 00:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:35:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:35:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:35:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:35:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:35:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:35:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:35:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:35:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:36:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:36:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 00:36:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 00:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 00:36:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:36:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:37:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:37:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:38:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:38:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:38:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:38:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 00:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:39:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 00:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:40:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 00:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:42:30 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-04 00:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:53:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 00:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:54:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 00:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:55:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 00:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 00:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-04 01:01:10 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-04 01:01:11 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-04 01:01:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 01:01:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 01:01:12 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 01:01:12 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-04 01:01:12 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-04 01:01:12 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-04 01:01:18 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 01:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:03:23 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-04 01:04:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:07:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:14:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:19:28 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-04 01:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:20:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:24:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:24:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 01:25:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 01:25:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 01:26:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:26:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:28:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 01:28:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 01:29:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 01:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:29:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:29:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:29:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:29:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:29:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:29:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:30:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:30:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:31:45 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-04 01:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:32:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:32:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:33:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:21 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:21 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:31 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:31 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:36 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:36 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:33:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:01 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:01 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:34:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:34:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:35:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:35:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 01:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:39:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:41:29 --> 404 Page Not Found: All/index
ERROR - 2021-08-04 01:42:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:42:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 01:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 01:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:08:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:10:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:10:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:13:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 02:13:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:14:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 02:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 02:15:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 02:16:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:16:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 02:16:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 02:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 02:17:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:17:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:18:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:21:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:26:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:27:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:28:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:29:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:36:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 02:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:43:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:44:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 02:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:49:27 --> 404 Page Not Found: Old/index
ERROR - 2021-08-04 02:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:52:27 --> 404 Page Not Found: City/15
ERROR - 2021-08-04 02:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 02:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:00:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:00:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:00:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:02:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:03:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:07:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:07:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:53 --> 404 Page Not Found: Wp/index
ERROR - 2021-08-04 03:07:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:07:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:08:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:08:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:08:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:13:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:15:40 --> 404 Page Not Found: City/15
ERROR - 2021-08-04 03:16:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:20:49 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-04 03:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:21:22 --> 404 Page Not Found: City/index
ERROR - 2021-08-04 03:21:24 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 03:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 03:24:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:26:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:26:36 --> 404 Page Not Found: English/index
ERROR - 2021-08-04 03:26:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:27:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:33:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:41:02 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-04 03:41:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:43:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:44:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 03:44:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:45:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:46:06 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-04 03:46:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 03:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 03:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 03:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 03:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 03:47:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 03:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:48:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:49:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 03:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:50:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:54:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:57:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:58:43 --> 404 Page Not Found: City/2
ERROR - 2021-08-04 03:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 03:59:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 03:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-04 04:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:03:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:13:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:13:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:14:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:24:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 04:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:25:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:26:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:26:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:27:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:27:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:28:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:35:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:36:17 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-04 04:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:41:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:44:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:46:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:56:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:56:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 04:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:58:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:58:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:58:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 04:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 04:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:00:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:02:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:13:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 05:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:16:16 --> 404 Page Not Found: Env/index
ERROR - 2021-08-04 05:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:19:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:22:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 05:23:23 --> 404 Page Not Found: Env/index
ERROR - 2021-08-04 05:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:26:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:33:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 05:33:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 05:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:38:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:40:04 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-04 05:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:42:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:45:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:45:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:46:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:47:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:48:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:48:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:49:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:50:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:50:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:50:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:51:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:52:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:52:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:53:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:53:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:54:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:55:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:57:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:58:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 05:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 05:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:02:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:03:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:04:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:07:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:09:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:11:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:14:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 06:14:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 06:14:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 06:14:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:15:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:17:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:17:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:17:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:19:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:19:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:20:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:20:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:22:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:22:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:23:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:24:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:24:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:24:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:26:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 06:27:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:29:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:29:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:34:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:35:28 --> 404 Page Not Found: Vod-play-id-2597-sid-0-pid-121html/index
ERROR - 2021-08-04 06:35:28 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-51html/index
ERROR - 2021-08-04 06:35:29 --> 404 Page Not Found: Vod-play-id-2793-sid-0-pid-4html/index
ERROR - 2021-08-04 06:35:31 --> 404 Page Not Found: Vod-play-id-2669-sid-0-pid-149html/index
ERROR - 2021-08-04 06:35:47 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-08-04 06:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:36:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:38:55 --> 404 Page Not Found: English/index
ERROR - 2021-08-04 06:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:40:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:41:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:42:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:42:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:42:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:45:22 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-04 06:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:52:27 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-08-04 06:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 06:58:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 06:59:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:01:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:01:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:01:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:02:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:04:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:06:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:06:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:07:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:08:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:08:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:10:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:11:56 --> 404 Page Not Found: Gqnei/index
ERROR - 2021-08-04 07:12:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:13:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:16:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:24:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:27:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:29:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:30:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:32:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:33:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:34:58 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-04 07:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:41:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:44:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 07:44:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 07:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:46:36 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-04 07:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:54:55 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-04 07:55:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:55:15 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-08-04 07:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:56:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:57:24 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-04 07:57:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 07:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 07:59:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:00:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:01:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:01:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:02:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:02:22 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-04 08:03:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:03:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:04:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:04:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:05:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:05:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:07:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:08:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:08:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:13:38 --> 404 Page Not Found: Atomxml/index
ERROR - 2021-08-04 08:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 08:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:17:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:20:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 08:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:22:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:25:48 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-04 08:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:28:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:35:17 --> 404 Page Not Found: Sitemapsxml/index
ERROR - 2021-08-04 08:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:36:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:41:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:44:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 08:44:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 08:44:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 08:44:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 08:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:48:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 08:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:50:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:52:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 08:52:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-04 08:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 08:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:58:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 08:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 08:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-04 09:07:13 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-04 09:07:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-04 09:07:14 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-04 09:07:15 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-04 09:07:15 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 09:07:15 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 09:07:15 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 09:07:15 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-04 09:07:15 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-04 09:07:15 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-04 09:07:25 --> 404 Page Not Found: English/index
ERROR - 2021-08-04 09:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:18:58 --> 404 Page Not Found: Sitemaptxt/index
ERROR - 2021-08-04 09:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:19:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 09:19:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 09:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:21:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 09:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:26:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 09:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:27:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 09:28:06 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-04 09:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:34:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 09:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:39:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 09:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 09:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:42:01 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-04 09:42:02 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-08-04 09:42:03 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-08-04 09:42:03 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-08-04 09:42:04 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-08-04 09:42:04 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-08-04 09:42:05 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-08-04 09:42:05 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-08-04 09:42:06 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-08-04 09:42:06 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-08-04 09:42:06 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-08-04 09:42:07 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-08-04 09:42:07 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-08-04 09:42:08 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-08-04 09:42:08 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-08-04 09:42:09 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-08-04 09:42:09 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-08-04 09:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:48:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 09:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:50:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 09:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:58:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 09:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 09:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:07:02 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-04 10:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:12:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:19:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 10:19:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:24:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:25:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:26:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:27:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:27:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:29:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:30:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 10:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:34:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:35:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:36:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:39:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:41:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:42:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:44:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:44:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:51:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:56:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 10:57:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 10:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 10:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:04:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 11:06:13 --> 404 Page Not Found: Env/index
ERROR - 2021-08-04 11:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:07:43 --> 404 Page Not Found: Hudson/index
ERROR - 2021-08-04 11:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:11:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 11:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:12:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 11:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:15:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 11:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:16:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 11:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:20:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 11:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:23:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 11:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:26:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:27:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 11:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:28:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:29:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:46:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:53:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 11:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:54:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:54:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:55:04 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-04 11:55:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:58:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 11:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 11:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:15:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 12:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 12:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:19:24 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2021-08-04 12:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:21:20 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2021-08-04 12:21:21 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2021-08-04 12:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:22:41 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2021-08-04 12:23:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 12:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:25:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 12:25:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 12:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:28:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 12:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:40:02 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-08-04 12:40:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 12:41:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 12:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:42:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 12:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:43:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 12:43:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 12:43:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 12:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:44:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 12:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:48:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 12:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:50:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 12:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:57:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 12:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 12:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:02:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 13:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:04:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 13:05:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 13:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:09:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 13:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:10:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 13:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 13:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:36:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 13:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:42:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 13:42:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 13:42:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 13:42:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 13:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:49:59 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-08-04 13:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:51:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 13:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:54:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 13:54:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 13:54:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 13:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 13:59:11 --> 404 Page Not Found: Backup/index
ERROR - 2021-08-04 13:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:12:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 14:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:16:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 14:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:20:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:20:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:28:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:30:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 14:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:30:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:33:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 14:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:38:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 14:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:41:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 14:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:44:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 14:44:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 14:44:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 14:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:46:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 14:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:49:42 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-04 14:50:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 14:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 14:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:01:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:03:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:06:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:11:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:11:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:17:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:20:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:22:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:28:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 15:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:30:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:30:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:30:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:31:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:32:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:33:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:33:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:39:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-04 15:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 15:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:41:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 15:41:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 15:41:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:43:55 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-04 15:44:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:47:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:53:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:55:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:56:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:56:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:56:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 15:57:01 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-04 15:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 15:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:00:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:01:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:01:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:03:34 --> 404 Page Not Found: City/16
ERROR - 2021-08-04 16:03:34 --> 404 Page Not Found: City/16
ERROR - 2021-08-04 16:03:34 --> 404 Page Not Found: City/16
ERROR - 2021-08-04 16:03:34 --> 404 Page Not Found: City/16
ERROR - 2021-08-04 16:03:34 --> 404 Page Not Found: City/16
ERROR - 2021-08-04 16:03:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 16:03:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 16:05:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:05:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:09:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 16:10:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 16:10:03 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-04 16:10:04 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-04 16:10:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 16:11:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:14:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:22:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:30:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:30:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:33:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:34:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 16:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:38:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 16:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:43:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:43:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:44:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 16:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:48:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 16:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:49:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:50:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:55:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 16:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:59:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:59:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 16:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:59:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 16:59:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:02:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:03:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:04:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:06:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:09:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 17:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:12:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 17:16:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-08-04 17:16:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 17:16:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 17:16:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 17:16:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-04 17:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:17:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 17:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:21:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:25:42 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-08-04 17:25:44 --> 404 Page Not Found: Issmall/index
ERROR - 2021-08-04 17:25:47 --> 404 Page Not Found: Test_for_404/index
ERROR - 2021-08-04 17:25:47 --> 404 Page Not Found: Web-console/index
ERROR - 2021-08-04 17:25:49 --> 404 Page Not Found: Admin-console/index
ERROR - 2021-08-04 17:25:50 --> 404 Page Not Found: Manager/status
ERROR - 2021-08-04 17:25:51 --> 404 Page Not Found: Manager/html
ERROR - 2021-08-04 17:25:51 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-04 17:25:52 --> 404 Page Not Found: Weblog/index
ERROR - 2021-08-04 17:26:01 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-04 17:26:08 --> 404 Page Not Found: Forum/index
ERROR - 2021-08-04 17:26:17 --> 404 Page Not Found: Bbs/index
ERROR - 2021-08-04 17:26:32 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-04 17:26:35 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-08-04 17:26:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 17:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:28:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 17:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:34:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 17:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:37:13 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-08-04 17:37:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 17:37:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 17:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:38:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 17:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 17:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:50:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 17:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:54:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 17:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 17:59:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 17:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 17:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:00:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:00:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:10:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:19:11 --> 404 Page Not Found: City/16
ERROR - 2021-08-04 18:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:20:51 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-04 18:22:01 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-04 18:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:25:03 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 18:25:03 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 18:25:07 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 18:25:10 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 18:25:12 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 18:26:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:26:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:28:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:30:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:30:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:31:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:33:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:34:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 18:36:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:36:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:38:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:38:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:39:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:41:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 18:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:53:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 18:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:55:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 18:55:16 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 18:55:17 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-04 18:55:18 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-04 18:55:19 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-04 18:55:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-04 18:55:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-04 18:55:19 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-04 18:55:19 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-04 18:55:19 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-04 18:56:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:57:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:58:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 18:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 18:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:00:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 19:00:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:03:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 19:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:09:38 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-04 19:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:15:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 19:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:24:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:26:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:28:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:32:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:33:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:44:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 19:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:50:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 19:51:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 19:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:52:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 19:52:54 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-04 19:53:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 19:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:57:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:58:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 19:58:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 19:58:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 19:58:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 19:58:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 19:59:04 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-04 19:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 19:59:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 19:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:02:29 --> 404 Page Not Found: Luci-static/top-iot
ERROR - 2021-08-04 20:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:13:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 20:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:16:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 20:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:18:09 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-04 20:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:26:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 20:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:28:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 20:29:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:29:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:30:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:30:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:30:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:32:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 20:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:35:19 --> 404 Page Not Found: City/1
ERROR - 2021-08-04 20:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:38:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 20:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:41:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 20:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:44:30 --> 404 Page Not Found: English/index
ERROR - 2021-08-04 20:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:47:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 20:47:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 20:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:49:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 20:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:51:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 20:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:52:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 20:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 20:58:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 20:59:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 20:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:00:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:02:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:03:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:06:42 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-04 21:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:09:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:10:09 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-04 21:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:10:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:13:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:16:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 21:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:21:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:22:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 21:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:23:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-04 21:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 21:43:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:50:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-04 21:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:55:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:55:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 21:57:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 21:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 21:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:05:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 22:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:06:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 22:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 22:12:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 22:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:15:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 22:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:15:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 22:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:18:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 22:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:36:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 22:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 22:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:41:58 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-08-04 22:42:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 22:42:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 22:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 22:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:00:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 23:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:04:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 23:05:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 23:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:13:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 23:13:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:13:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:13:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:13:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-04 23:14:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:15:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:18:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 23:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:30:29 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-04 23:31:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:31:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:31:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:38:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 23:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:47:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 23:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:48:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 23:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:56:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:56:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:56:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:56:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:57:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:57:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:57:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-04 23:57:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-04 23:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-04 23:58:30 --> 404 Page Not Found: Robotstxt/index
