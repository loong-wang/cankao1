<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-26 00:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 00:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 00:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 00:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 00:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 00:10:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 00:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 00:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 00:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 00:25:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 00:30:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 00:31:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 00:34:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 00:38:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:03:47 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-11-26 01:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 01:17:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:21:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:25:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:29:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:32:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-26 01:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 01:33:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 01:33:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:37:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 01:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 01:44:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 01:45:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 01:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 01:47:29 --> 404 Page Not Found: Sitemap16912html/index
ERROR - 2021-11-26 01:48:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:52:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 01:56:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 02:00:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 02:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 02:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 02:04:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 02:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 02:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 02:34:45 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-11-26 02:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 02:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 02:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 02:44:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 03:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 03:10:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 03:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 03:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 03:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 03:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 03:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 03:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 03:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 03:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 03:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 03:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 03:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 03:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 04:00:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 04:00:44 --> 404 Page Not Found: City/1
ERROR - 2021-11-26 04:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 04:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 04:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 04:28:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 05:01:03 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 277
ERROR - 2021-11-26 05:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 05:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 05:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 06:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 06:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:28:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 06:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 06:56:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:12:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:17:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:18:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:38:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 07:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 07:45:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:00:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:01:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:01:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 08:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 08:30:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 08:30:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 08:48:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 08:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 08:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 08:56:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 08:57:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:57:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:58:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 08:58:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:59:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 08:59:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:00:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 09:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 09:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:15:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 09:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 09:33:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 09:34:21 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-11-26 09:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 09:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 09:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 09:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 09:49:53 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-11-26 09:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 09:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:01:05 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-26 10:02:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:36:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 10:39:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:40:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:40:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:42:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:42:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:42:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:42:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:43:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:43:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:43:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:43:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:43:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:43:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:44:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:44:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:44:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:44:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:45:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 10:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 10:53:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-26 10:55:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:55:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 10:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 11:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 11:06:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:06:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 11:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 11:06:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:14:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:14:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:14:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:14:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 11:24:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:37:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 11:38:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:42:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:42:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:43:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 11:46:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:46:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:46:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:46:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:46:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:46:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:46:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 11:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 11:50:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 11:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:03:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 12:06:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 12:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 12:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 12:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 12:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 12:31:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:36:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:39:14 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php 191
ERROR - 2021-11-26 12:39:46 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 12:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:50:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 12:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:51:35 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 12:52:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 12:55:20 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 12:55:47 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 12:55:47 --> Severity: error --> null wxpay 1
ERROR - 2021-11-26 12:56:23 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 12:56:23 --> Severity: error --> false wxpay 1
ERROR - 2021-11-26 12:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 13:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 13:07:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 13:07:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 13:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 13:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 13:16:42 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:16:42 --> Severity: error -->  wxpay 1
ERROR - 2021-11-26 13:16:42 --> Severity: error -->  wxpay 1
ERROR - 2021-11-26 13:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 13:22:18 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:22:18 --> Severity: error -->  wxpay 1
ERROR - 2021-11-26 13:22:18 --> Severity: error --> a=1 wxpay 1
ERROR - 2021-11-26 13:23:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 13:23:35 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:23:35 --> Severity: error --> 















 wxpay 1
ERROR - 2021-11-26 13:23:35 --> Severity: error --> <xml><appid><![CDATA[wx7eac32fb2fa78872]]></appid>
<bank_type><![CDATA[OTHERS]]></bank_type>
<cash_fee><![CDATA[1]]></cash_fee>
<fee_type><![CDATA[CNY]]></fee_type>
<is_subscribe><![CDATA[N]]></is_subscribe>
<mch_id><![CDATA[1250172401]]></mch_id>
<nonce_str><![CDATA[reyip4gqlh0qft1d3coojri0wxwb6j2a]]></nonce_str>
<openid><![CDATA[okbQFj2-gUeIEfSd7K-MbBEPRu1w]]></openid>
<out_trade_no><![CDATA[2018229639781]]></out_trade_no>
<result_code><![CDATA[SUCCESS]]></result_code>
<return_code><![CDATA[SUCCESS]]></return_code>
<sign><![CDATA[1628F762D6B3127D5E096EC83990983C]]></sign>
<time_end><![CDATA[20211126132334]]></time_end>
<total_fee>1</total_fee>
<trade_type><![CDATA[MWEB]]></trade_type>
<transaction_id><![CDATA[4200001194202111267070831878]]></transaction_id>
</xml> wxpay 1
ERROR - 2021-11-26 13:24:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:25:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:27:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:27:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:27:58 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:27:58 --> Severity: error --> 















 wxpay 1
ERROR - 2021-11-26 13:27:58 --> Severity: error --> <xml><appid><![CDATA[wx7eac32fb2fa78872]]></appid>
<bank_type><![CDATA[OTHERS]]></bank_type>
<cash_fee><![CDATA[1]]></cash_fee>
<fee_type><![CDATA[CNY]]></fee_type>
<is_subscribe><![CDATA[N]]></is_subscribe>
<mch_id><![CDATA[1250172401]]></mch_id>
<nonce_str><![CDATA[arm06zd5a585yv8bb0szdxxoswtpx8qk]]></nonce_str>
<openid><![CDATA[okbQFj2-gUeIEfSd7K-MbBEPRu1w]]></openid>
<out_trade_no><![CDATA[2018229609425]]></out_trade_no>
<result_code><![CDATA[SUCCESS]]></result_code>
<return_code><![CDATA[SUCCESS]]></return_code>
<sign><![CDATA[ECEF4458CA2B094D75A6BC7298CBBD78]]></sign>
<time_end><![CDATA[20211126131355]]></time_end>
<total_fee>1</total_fee>
<trade_type><![CDATA[MWEB]]></trade_type>
<transaction_id><![CDATA[4200001150202111265525046733]]></transaction_id>
</xml> wxpay 1
ERROR - 2021-11-26 13:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 13:28:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 13:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:29:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:29:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:29:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:30:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:31:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:33:57 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-11-26 13:34:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 13:36:17 --> Severity: Error --> Call to undefined method CI_DB_mysql_driver::row_array() /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php 180
ERROR - 2021-11-26 13:36:19 --> Severity: Error --> Call to undefined method CI_DB_mysql_driver::row_array() /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php 180
ERROR - 2021-11-26 13:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:40:50 --> Severity: Error --> Call to a member function result_array() on a non-object /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php 185
ERROR - 2021-11-26 13:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 13:46:04 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:46:07 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:06 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:07 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:08 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:08 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:09 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:09 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:10 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:11 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:12 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:12 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:13 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:13 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:23 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:24 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:29 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:29 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:39 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:39 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:44 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:48:44 --> Severity: error --> 支付金额不一致：398-1 dan_shoujia 1
ERROR - 2021-11-26 13:48:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:49:09 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:49:10 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 13:49:15 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:49:15 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 13:49:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-26 13:49:51 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-26 13:50:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:52:10 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:52:11 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 13:52:15 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:52:15 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 13:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 13:58:48 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 13:59:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:01:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:02:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 14:02:12 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:02:12 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:02:16 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:02:16 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:04:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:05:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:06:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 14:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:11:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:12:02 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:12:03 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:12:04 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:12:05 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:14:52 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-26 14:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:16:06 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:16:06 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:16:07 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:16:08 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:16:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 14:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:20:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-11-26 14:22:13 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:22:13 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:22:16 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:22:16 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:24:44 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 14:24:44 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 14:24:44 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 14:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:26:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:26:58 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-11-26 14:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:27:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:34:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:35:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:39:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 14:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 14:42:04 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:42:04 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:42:05 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:42:05 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:42:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 14:43:20 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:21 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:21 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:22 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:22 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:22 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:23 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:24 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:25 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:25 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:26 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:27 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:28 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:28 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:37 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:37 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:43 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:43 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:53 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:53 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:43:56 --> 404 Page Not Found: SqlInasp/index
ERROR - 2021-11-26 14:43:59 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:43:59 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:44:24 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:44:24 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:44:29 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:44:29 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:46:08 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:46:08 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:47:08 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:47:24 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:47:25 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:47:30 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:47:30 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:49:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 14:52:14 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:52:14 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:52:17 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:52:17 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 14:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 14:57:25 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:57:26 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 14:57:30 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 14:57:30 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 15:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:12:05 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:12:06 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 15:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:13:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:14:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:15:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:15:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:16:07 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:16:07 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 15:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:17:27 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:17:27 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 15:17:31 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:17:31 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 15:22:15 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:22:16 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 15:22:17 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:22:17 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 15:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:29:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:29:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:29:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:30:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 15:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:41:21 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-26 15:42:05 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:42:05 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 15:46:08 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:46:09 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 15:47:28 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:47:29 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 15:47:31 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:47:31 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 15:49:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 15:50:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 15:51:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 15:52:18 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 15:52:18 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 15:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 15:59:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 16:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 16:07:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 16:11:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 16:12:06 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 16:12:06 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 16:12:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 16:13:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 16:17:30 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 16:17:30 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 16:17:32 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 16:17:32 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 16:18:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 16:20:08 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 16:20:09 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 16:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 16:22:16 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 16:22:17 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 16:23:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:23:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:23:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:23:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 16:29:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:34:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 16:41:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 16:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 16:47:32 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 16:47:32 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 16:48:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 16:52:18 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 16:52:19 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 16:52:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 17:02:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 17:04:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 17:05:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 17:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 17:07:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-26 17:17:31 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 17:17:31 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 17:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 17:19:42 --> 404 Page Not Found: Sitemap25296html/index
ERROR - 2021-11-26 17:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 17:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 17:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 17:23:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 17:24:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 17:24:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 17:27:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 17:27:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 17:29:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 17:34:19 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 17:34:20 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 17:34:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 17:38:03 --> 404 Page Not Found: UploadFile/root.aspx
ERROR - 2021-11-26 17:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 17:45:40 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 17:45:40 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 17:47:33 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 17:47:33 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 17:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 17:54:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:02:06 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 18:02:06 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 18:02:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:05:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:05:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:16:08 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 18:16:08 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 18:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:18:39 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 18:18:39 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 18:18:39 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 18:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:22:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:24:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:25:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:28:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:29:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 18:31:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:35:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:38:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 18:39:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 18:42:07 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 18:42:07 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 18:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:42:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:45:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:46:09 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 18:46:09 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 18:47:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:48:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 18:56:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 18:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 18:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:02:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 19:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 19:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:12:06 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 19:12:07 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 19:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:22:17 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 19:22:18 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 19:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:34:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 19:34:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 19:39:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 19:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 19:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:52:19 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 19:52:19 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 19:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 19:54:34 --> 404 Page Not Found: Sitemap36220html/index
ERROR - 2021-11-26 20:04:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 20:13:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 20:17:32 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 20:17:32 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 20:22:20 --> 404 Page Not Found: City/index
ERROR - 2021-11-26 20:28:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-26 20:33:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 20:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 20:43:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 20:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 20:47:33 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 20:47:33 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 20:48:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 20:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 20:49:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 20:50:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 20:50:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 20:55:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 20:56:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 20:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 20:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:07:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:14:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:14:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:15:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:15:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:16:10 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 21:16:10 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 21:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:23:02 --> 404 Page Not Found: Sitemap48655html/index
ERROR - 2021-11-26 21:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 21:30:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 21:34:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 21:37:51 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-26 21:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:41:17 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-11-26 21:42:09 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 21:42:09 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 21:43:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-26 21:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:46:10 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 21:46:10 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 21:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-26 21:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 21:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:02:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 22:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 22:02:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 22:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:12:07 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 22:12:07 --> Severity: error --> 支付金额不一致：199-0.01 dan_shoujia 1
ERROR - 2021-11-26 22:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:22:18 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 22:22:19 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 22:24:34 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 22:24:34 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-26 22:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 22:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 22:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 22:27:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 22:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 22:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 22:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:32:30 --> 404 Page Not Found: Cssasp/index
ERROR - 2021-11-26 22:32:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 22:32:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 22:32:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 22:37:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 22:50:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 22:52:19 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 22:52:20 --> Severity: error --> 支付金额不一致：398-0.01 dan_shoujia 1
ERROR - 2021-11-26 22:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 22:53:16 --> 404 Page Not Found: Sitemap97701html/index
ERROR - 2021-11-26 23:01:09 --> 404 Page Not Found: Web/index
ERROR - 2021-11-26 23:01:22 --> 404 Page Not Found: Web/index
ERROR - 2021-11-26 23:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 23:03:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 23:03:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 23:03:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 23:12:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 23:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 23:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 23:14:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-26 23:17:33 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 23:17:33 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 23:21:13 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-11-26 23:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-26 23:26:46 --> 404 Page Not Found: Article/view
ERROR - 2021-11-26 23:32:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 23:32:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 23:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-26 23:47:34 --> Severity: error --> 11111 test 1
ERROR - 2021-11-26 23:47:34 --> Severity: error --> 支付金额不一致：2-0.02 dan_shoujia 1
ERROR - 2021-11-26 23:57:43 --> 404 Page Not Found: Robotstxt/index
