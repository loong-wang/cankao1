<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-27 00:01:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-27 00:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 00:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 00:12:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-27 00:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 00:23:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-27 00:33:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-27 00:47:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-27 00:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:50:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 00:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 00:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:53:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:55:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:55:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 00:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 00:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 00:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 00:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 01:01:58 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 01:05:46 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 01:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 01:16:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 01:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 01:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 01:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 01:21:44 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 01:22:01 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-09-27 01:22:17 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-27 01:22:20 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 01:25:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 01:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 01:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 01:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 01:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 01:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 01:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 01:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 01:50:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 02:10:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 02:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 02:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 02:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 02:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 02:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:07:49 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 03:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:12:04 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-27 03:12:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 03:14:08 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-09-27 03:14:24 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 03:14:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 03:14:28 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 03:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 03:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 03:26:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:29:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:29:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:33:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:33:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:33:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:33:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:33:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:39:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:39:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:43:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:43:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 03:43:23 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 03:43:25 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 03:43:30 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-27 03:44:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 03:44:29 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-09-27 03:45:14 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-27 03:45:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 03:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:54:20 --> 404 Page Not Found: Text4041632686060/index
ERROR - 2021-09-27 03:54:20 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-27 03:54:21 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-27 03:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 03:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 04:01:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-09-27 04:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 04:19:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:19:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:19:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:19:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:19:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:23:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:23:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:23:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:23:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:23:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:26:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:26:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 04:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 04:47:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 05:04:25 --> 404 Page Not Found: 404/index.html
ERROR - 2021-09-27 05:04:25 --> 404 Page Not Found: 404/index.html
ERROR - 2021-09-27 05:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 05:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 05:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 05:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 05:18:01 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-27 05:18:36 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 05:18:44 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-09-27 05:18:56 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 05:19:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 05:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 05:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 05:43:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 05:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 05:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 06:03:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 06:03:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 06:03:17 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 06:03:46 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 06:03:50 --> 404 Page Not Found: Login/index
ERROR - 2021-09-27 06:04:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 06:04:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 06:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 06:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 06:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 06:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 06:38:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 06:38:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 06:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 06:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 06:57:35 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 07:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 07:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 07:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 07:34:28 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-09-27 07:34:28 --> 404 Page Not Found: admin//index
ERROR - 2021-09-27 07:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 07:34:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 07:34:29 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-09-27 07:34:29 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-09-27 07:34:29 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-09-27 07:34:30 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-09-27 07:34:31 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-09-27 07:34:31 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-09-27 07:34:31 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-09-27 07:34:31 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-09-27 07:34:31 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-09-27 07:34:31 --> 404 Page Not Found: Wcm/index
ERROR - 2021-09-27 07:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 07:50:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 07:51:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 07:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 07:52:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 07:52:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 07:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 07:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 08:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:18:00 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-09-27 08:18:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:20:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:21:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:22:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 08:26:15 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-27 08:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 08:30:55 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-27 08:32:29 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-09-27 08:35:36 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-27 08:36:47 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-27 08:37:10 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-27 08:37:57 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-27 08:39:30 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-27 08:39:54 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-27 08:42:14 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-27 08:43:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 08:44:58 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-27 08:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 08:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 08:57:48 --> 404 Page Not Found: Bk/wiki
ERROR - 2021-09-27 08:57:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 08:58:26 --> 404 Page Not Found: Downinfo/86259.html
ERROR - 2021-09-27 08:58:44 --> 404 Page Not Found: Stockguba/603236.htm
ERROR - 2021-09-27 08:59:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:03:42 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-27 09:08:23 --> Severity: Warning --> Missing argument 1 for Zifei::show() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 277
ERROR - 2021-09-27 09:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:08:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 09:09:09 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-27 09:12:40 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-27 09:14:14 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-27 09:15:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:16:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:17:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:18:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:20:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:20:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:21:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:23:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:24:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:25:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:27:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 09:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 09:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:46:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-27 09:46:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-27 09:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:50:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 09:52:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 09:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 09:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 10:00:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 10:00:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:01:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 10:13:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 10:17:18 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 10:18:17 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 10:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 10:43:05 --> 404 Page Not Found: City/15
ERROR - 2021-09-27 10:45:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-27 10:46:44 --> 404 Page Not Found: admin//index
ERROR - 2021-09-27 10:46:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 10:47:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 10:52:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 10:53:51 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-27 10:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:57:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 10:57:44 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-09-27 10:58:08 --> 404 Page Not Found: City/1
ERROR - 2021-09-27 10:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:10:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:14:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:15:57 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:15:59 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:16:07 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:16:09 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:16:15 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:16:49 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:16:58 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:16:59 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:17:04 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 11:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 11:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 11:25:39 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:25:41 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:25:47 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:25:53 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:27:02 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:27:06 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:27:18 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:29:09 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:29:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:29:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:34:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:35:26 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:35:49 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:35:49 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:35:53 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:36:06 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:36:09 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:36:10 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:36:30 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:38:19 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 11:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:41:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-27 11:43:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:43:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:43:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:43:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:43:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:43:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:44:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:44:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:44:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:44:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:44:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 11:44:48 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:44:50 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:50 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:50 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:50 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:51 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:51 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:51 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:44:52 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:45:05 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:45:18 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:46:04 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:46:46 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:46:48 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:46:48 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:46:48 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:46:49 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:47:55 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:48:35 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:49:55 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 11:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 150
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 151
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 152
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:29 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:54:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:30 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:54:31 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:31 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:31 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:31 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:32 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:32 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:32 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:32 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:33 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:33 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:33 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:33 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:33 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:33 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:34 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:34 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:34 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:34 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:35 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:54:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:36 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:36 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:54:37 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:39 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:41 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:41 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:41 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:41 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:43 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:44 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:44 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:44 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:46 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:46 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:46 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:48 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:50 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:50 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:50 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:50 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: 1010 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2004
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2009
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: haoma_loves /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2152
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: 5 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:56 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:56 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:56 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:56 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:57 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:57 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:57 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:57 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:57 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:57 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: 1010 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 11:54:59 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:55:00 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:00 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:00 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:02 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:02 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:02 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:02 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:02 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:02 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:03 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:07 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined index: 6 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1411
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:09 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:10 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:12 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:12 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:12 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:12 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: 10 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1406
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: 25 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1411
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 150
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 151
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 152
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:19 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:21 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:22 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:22 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:22 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:22 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:23 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:25 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:30 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:30 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:30 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:30 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:31 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:32 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:33 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:33 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:33 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:34 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: 5 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:40 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2009
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:43 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: 7 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1411
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:44 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:46 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:47 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:49 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:55:50 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:50 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:50 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:50 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 151
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 152
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 153
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:54 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:56 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:57 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:55:59 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:55:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:00 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:56:01 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:02 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:03 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:03 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:03 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:03 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:03 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:03 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:04 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:05 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:05 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:05 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:05 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:05 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:05 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:05 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:06 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:07 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:08 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:11 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:11 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:11 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:12 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:13 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:14 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:18 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 151
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 152
ERROR - 2021-09-27 11:56:19 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 153
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:20 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:21 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1712
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 150
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 151
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 152
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:22 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:23 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:23 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:23 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:23 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:26 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 11:56:27 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:27 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:27 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:29 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:30 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:31 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:31 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:31 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:31 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:32 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:34 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:34 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:34 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:34 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:35 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 150
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 151
ERROR - 2021-09-27 11:56:36 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/default/haoma_list.php 152
ERROR - 2021-09-27 11:56:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:37 --> 404 Page Not Found: System/core
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:37 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 151
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 152
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 153
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:38 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:40 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 11:56:42 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 11:56:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:02:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 12:04:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-27 12:05:15 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:05:16 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:05:52 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:06:11 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 12:06:28 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:06:34 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:07:41 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:07:42 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:07:43 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:07:43 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:08:03 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:08:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 12:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 12:13:04 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:13:05 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:13:20 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:20 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:20 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:20 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:20 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:20 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:21 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 239
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:21 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: 5 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1411
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: 17 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:22 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:23 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:24 --> Severity: Notice --> Undefined index: haoma_loves /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2152
ERROR - 2021-09-27 12:13:25 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:25 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined index: 6 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:26 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 540
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 695
ERROR - 2021-09-27 12:13:27 --> Severity: Notice --> Undefined variable: where /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 758
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:28 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:30 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:31 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:32 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:32 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:32 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:32 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:32 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:33 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:33 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:33 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:33 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:33 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:33 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:33 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 12:13:34 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 12:13:35 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:35 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:35 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:35 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:35 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:37 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:37 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:37 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:40 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 12:13:40 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 12:13:40 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 12:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1411
ERROR - 2021-09-27 12:13:41 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:42 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:48 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:48 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:48 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 12:13:48 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 12:13:49 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:49 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:49 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:49 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:50 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:51 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 12:13:52 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 257
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 265
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: pages_title /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/home.php 273
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:54 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:54 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:54 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:13:55 --> Severity: Notice --> Undefined index: haoma_loves /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2152
ERROR - 2021-09-27 12:13:56 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:56 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:56 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:56 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:56 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:58 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:13:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:13:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:13:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1115
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: 5 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1120
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:14:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:14:01 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:16:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:09 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 540
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 695
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined variable: where /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 758
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: 10 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1406
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: 6 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1411
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:10 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:11 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: b /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 512
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 540
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 695
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: 10 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1393
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: 18 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1406
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1411
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 1416
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:11 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 12:17:12 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:13 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:13 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:14 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:15 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:16 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:17 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:17 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:17:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:17:18 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:17:19 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:17:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:17:19 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:17:20 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:17:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 12:19:27 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:20:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:20:34 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:20:35 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:21:41 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:21:42 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:21:42 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:21:42 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:21:55 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:03 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:05 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:05 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:06 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:06 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:06 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:12 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:22:13 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:13 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:13 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:27 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting T_FUNCTION /www/wwwroot/www.xuanhao.net/app/controllers/admin/Question.php 235
ERROR - 2021-09-27 12:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:24:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:25:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:36 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 151
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 152
ERROR - 2021-09-27 12:27:37 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lista.php 153
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:38 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:39 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:40 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:41 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:43 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:44 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: 1010 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2004
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined index: 100 /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2009
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 130
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 131
ERROR - 2021-09-27 12:27:45 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_lists.php 132
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:46 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:47 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:48 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:49 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:50 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:50 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:50 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:50 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:50 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:50 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:51 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:52 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined variable: haoma_list_a /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 161
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined variable: haoma_list_c /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 162
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined variable: haoma_list_b /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 163
ERROR - 2021-09-27 12:27:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 793
ERROR - 2021-09-27 12:27:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 794
ERROR - 2021-09-27 12:27:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 795
ERROR - 2021-09-27 12:27:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/system/core/Output.php 796
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:53 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:54 --> Severity: Notice --> Undefined index: haoma_loves /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2152
ERROR - 2021-09-27 12:27:54 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:54 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:27:54 --> Severity: Notice --> Undefined variable: b /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 512
ERROR - 2021-09-27 12:27:54 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 540
ERROR - 2021-09-27 12:27:54 --> Severity: Notice --> Undefined variable: hao_types /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 695
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:55 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:57 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 12:27:58 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:58 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:58 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:58 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:58 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:58 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:27:58 --> Severity: Notice --> Undefined index: pin_shuxing /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/cart_list.php 74
ERROR - 2021-09-27 12:27:59 --> Severity: Notice --> Undefined index: host /www/wwwroot/www.xuanhao.net/app/config/config.php 5
ERROR - 2021-09-27 12:27:59 --> Severity: Notice --> Undefined offset: 0 /www/wwwroot/www.xuanhao.net/app/config/config.php 7
ERROR - 2021-09-27 12:27:59 --> Severity: Notice --> Undefined index: fox_session /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 3
ERROR - 2021-09-27 12:27:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 5
ERROR - 2021-09-27 12:27:59 --> Severity: Notice --> Undefined index: scid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 7
ERROR - 2021-09-27 12:27:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 11
ERROR - 2021-09-27 12:27:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php:272) /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 12
ERROR - 2021-09-27 12:27:59 --> Severity: Notice --> Undefined index: scheid /www/wwwroot/www.xuanhao.net/app/helpers/function_helper.php 13
ERROR - 2021-09-27 12:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:28:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 12:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 12:30:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 12:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 12:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 12:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 12:58:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 12:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 13:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:13:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 13:19:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 13:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 13:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:19:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:20:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 13:21:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 13:27:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 13:29:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:31:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:32:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:33:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:34:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:38:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 13:42:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:44:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 13:49:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 13:49:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:49:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:50:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:51:47 --> 404 Page Not Found: Web/index
ERROR - 2021-09-27 13:54:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 13:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 14:09:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-27 14:10:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 14:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:10:30 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 14:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 14:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:14:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:19:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:22:05 --> Severity: Parsing Error --> syntax error, unexpected $end, expecting ',' or ';' /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/haoma_list.php 35
ERROR - 2021-09-27 14:27:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:27:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:27:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 14:28:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:28:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:29:06 --> 404 Page Not Found: Haoma/othera
ERROR - 2021-09-27 14:29:06 --> 404 Page Not Found: Haoma/liantong
ERROR - 2021-09-27 14:29:07 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 222
ERROR - 2021-09-27 14:29:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:30:14 --> 404 Page Not Found: Haoma/liantong
ERROR - 2021-09-27 14:30:14 --> Severity: Parsing Error --> syntax error, unexpected $end /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 770
ERROR - 2021-09-27 14:30:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:30:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:30:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:30:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 14:31:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:31:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:31:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:32:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:32:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:33:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:33:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:33:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:33:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:33:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:33:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:33:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:34:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:34:53 --> 404 Page Not Found: Haoma/yidong
ERROR - 2021-09-27 14:37:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:37:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:37:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:38:00 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-27 14:38:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:38:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:38:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:38:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-27 14:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 14:41:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 14:42:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 14:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 14:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 14:48:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 14:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 14:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 14:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 14:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 14:58:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 15:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 15:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 15:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 15:15:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 15:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 15:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 15:36:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-27 15:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 15:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 15:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 16:03:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 16:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:08:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 16:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 16:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 16:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:15:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:25:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:26:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:26:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:27:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:27:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:27:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:29:08 --> 404 Page Not Found: Index/login
ERROR - 2021-09-27 16:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:33:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:38:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 16:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:45:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 16:45:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:45:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:46:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:47:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:47:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:48:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:50:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:51:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:56:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:57:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:57:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:57:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:58:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:58:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:58:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:58:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:58:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 16:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:01:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 17:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:01:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:02:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:03:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:03:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:04:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 17:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 17:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 17:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 17:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 17:32:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 17:32:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 17:33:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 17:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 17:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 17:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 18:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 18:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 18:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 18:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 18:18:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 18:32:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 18:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 18:38:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 18:38:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 18:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 18:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 19:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 19:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 19:11:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 19:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 19:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 19:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 19:28:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 19:34:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 19:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 19:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 19:40:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 19:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 19:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 20:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 20:25:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 20:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 20:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 20:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:50:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:50:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:50:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:50:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:50:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 20:52:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 20:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 21:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 21:10:49 --> 404 Page Not Found: City/10
ERROR - 2021-09-27 21:10:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:11:28 --> 404 Page Not Found: City/10
ERROR - 2021-09-27 21:11:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:12:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:12:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:13:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:13:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:14:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:14:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:15:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:15:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:16:22 --> 404 Page Not Found: City/10
ERROR - 2021-09-27 21:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 21:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:29:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 21:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 21:42:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 21:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:16:03 --> 404 Page Not Found: Tagasp/index
ERROR - 2021-09-27 22:16:03 --> 404 Page Not Found: Data21293/NYIKUGY5434231.mdb
ERROR - 2021-09-27 22:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:20:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:20:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-27 22:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:25:15 --> 404 Page Not Found: Sitemap13326html/index
ERROR - 2021-09-27 22:26:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-27 22:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 22:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:13:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 23:14:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 23:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:15:29 --> 404 Page Not Found: City/16
ERROR - 2021-09-27 23:20:05 --> 404 Page Not Found: City/16
ERROR - 2021-09-27 23:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:26:20 --> 404 Page Not Found: City/16
ERROR - 2021-09-27 23:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:29:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-27 23:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:30:44 --> 404 Page Not Found: City/16
ERROR - 2021-09-27 23:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-27 23:54:47 --> 404 Page Not Found: Robotstxt/index
