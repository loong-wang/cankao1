<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-26 00:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 00:03:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 00:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 00:08:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 00:10:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 00:10:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 00:10:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 00:11:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 00:27:20 --> 404 Page Not Found: City/1
ERROR - 2022-02-26 00:30:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:35:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:37:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:37:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:38:12 --> 404 Page Not Found: Cdn-cgi/trace
ERROR - 2022-02-26 00:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 00:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 00:43:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:44:45 --> 404 Page Not Found: Ask/22
ERROR - 2022-02-26 00:44:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:47:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:47:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 00:54:58 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-02-26 00:56:00 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-26 00:56:38 --> 404 Page Not Found: 16/all
ERROR - 2022-02-26 00:57:53 --> 404 Page Not Found: 1/all
ERROR - 2022-02-26 00:59:55 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-02-26 01:00:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:03:30 --> 404 Page Not Found: 16/10000
ERROR - 2022-02-26 01:07:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:12:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 01:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 01:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 01:26:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:29:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:31:41 --> 404 Page Not Found: Html-en/products-BExJnSQdumvP-1-1-2-1.html
ERROR - 2022-02-26 01:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 01:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 01:35:42 --> 404 Page Not Found: 16/10000
ERROR - 2022-02-26 01:37:15 --> 404 Page Not Found: 16/10000
ERROR - 2022-02-26 01:50:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-26 01:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:55:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 01:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:00:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 02:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 02:03:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 02:03:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 02:03:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 02:03:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 02:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:08:55 --> 404 Page Not Found: 16/10000
ERROR - 2022-02-26 02:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:16:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 02:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:19:45 --> 404 Page Not Found: Sitemap15476html/index
ERROR - 2022-02-26 02:20:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 02:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 02:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 02:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 02:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 02:57:47 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-02-26 03:03:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 03:04:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 03:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-26 03:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 03:11:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 03:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 03:14:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 03:14:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 03:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 03:37:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 03:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 03:38:09 --> 404 Page Not Found: Sitemap50959html/index
ERROR - 2022-02-26 03:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 03:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 03:55:52 --> 404 Page Not Found: Webdav/index
ERROR - 2022-02-26 04:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:52:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 04:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 04:57:08 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-26 05:01:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 05:01:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 05:08:22 --> 404 Page Not Found: City/16
ERROR - 2022-02-26 05:08:27 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-02-26 05:09:12 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-02-26 05:10:32 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-26 05:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:24:51 --> 404 Page Not Found: City/15
ERROR - 2022-02-26 05:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:46:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-26 05:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 05:54:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 05:54:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 06:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 06:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 06:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:24:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 06:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:32:27 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-02-26 06:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:42:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 06:42:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 06:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 06:59:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 07:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 07:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 07:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 07:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 07:18:09 --> 404 Page Not Found: Shouji/game
ERROR - 2022-02-26 07:18:31 --> 404 Page Not Found: Gaokao/208553.html
ERROR - 2022-02-26 07:18:37 --> 404 Page Not Found: Special/jtblgajgrhcl
ERROR - 2022-02-26 07:19:06 --> 404 Page Not Found: Index/index
ERROR - 2022-02-26 07:19:25 --> 404 Page Not Found: S/monijiashilei
ERROR - 2022-02-26 07:19:45 --> 404 Page Not Found: Baike/qiuhundinghun
ERROR - 2022-02-26 07:19:47 --> 404 Page Not Found: Article/CGMGBUVF0517A54O.html
ERROR - 2022-02-26 07:20:29 --> 404 Page Not Found: Detail/43
ERROR - 2022-02-26 07:20:53 --> 404 Page Not Found: Question/51905.html
ERROR - 2022-02-26 07:21:27 --> 404 Page Not Found: Duel/index
ERROR - 2022-02-26 07:28:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 07:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 07:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 07:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 07:31:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 07:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 07:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 07:58:57 --> 404 Page Not Found: Sitemap16600html/index
ERROR - 2022-02-26 08:01:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 08:14:01 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2022-02-26 08:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 08:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 08:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 08:43:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 08:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 08:45:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 08:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 08:59:27 --> 404 Page Not Found: M/d
ERROR - 2022-02-26 09:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 09:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 09:06:03 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-26 09:06:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:06:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:06:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:07:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 09:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 09:08:52 --> 404 Page Not Found: 16/10000
ERROR - 2022-02-26 09:13:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:17:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:25:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 09:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 09:30:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:42:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:44:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:45:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:54:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:55:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 09:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:55:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 09:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 10:01:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 10:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 10:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 10:24:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:24:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:24:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:24:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:24:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:25:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:26:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:27:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 10:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:34:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:34:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 10:41:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:41:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:44:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 10:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 10:48:12 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-26 10:49:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:52:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 10:52:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-26 10:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 11:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 11:11:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 11:15:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:15:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 11:21:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 11:33:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 11:38:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 11:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:40:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:40:53 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-26 11:40:56 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-26 11:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:43:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:43:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:44:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 11:56:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 11:58:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 11:58:20 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-02-26 12:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 12:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 12:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 12:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 12:21:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:24:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:25:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:25:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:30:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 12:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:41:05 --> 404 Page Not Found: All/index
ERROR - 2022-02-26 12:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 12:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 12:51:07 --> 404 Page Not Found: Sitemap90408html/index
ERROR - 2022-02-26 12:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:57:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 12:59:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 12:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:59:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 12:59:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 12:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 12:59:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 13:07:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 13:07:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 13:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 13:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 13:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 13:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 13:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 13:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 13:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 13:33:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 13:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 13:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 13:50:50 --> 404 Page Not Found: 10/10000
ERROR - 2022-02-26 13:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:00:22 --> 404 Page Not Found: 10/10000
ERROR - 2022-02-26 14:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:11:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 14:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:23:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 14:23:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 14:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:25:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:25:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:30:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 14:31:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:31:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 14:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:34:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:34:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:35:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:36:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:36:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 14:36:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:37:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:40:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 14:52:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 15:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 15:09:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 15:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 15:17:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 15:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 15:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:23:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:24:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 15:26:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:40:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:40:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 15:41:55 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-26 15:43:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-26 15:44:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:44:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 15:44:44 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-26 15:44:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:44:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 15:45:08 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-26 15:45:24 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-26 15:45:26 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-26 15:46:14 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-26 15:49:59 --> 404 Page Not Found: Ask/4
ERROR - 2022-02-26 15:50:00 --> 404 Page Not Found: Ask/5
ERROR - 2022-02-26 15:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 15:56:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:57:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 15:58:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 15:58:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 15:58:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:00:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:03:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:07:27 --> 404 Page Not Found: Ask/18
ERROR - 2022-02-26 16:08:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 16:16:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-26 16:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:23:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:27:47 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 16:27:48 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-26 16:27:50 --> 404 Page Not Found: Member/space
ERROR - 2022-02-26 16:27:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:27:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:27:54 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-26 16:27:56 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-26 16:28:01 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:28:01 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-26 16:28:01 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:28:01 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:28:01 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-26 16:28:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 16:28:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:28:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 16:30:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 16:30:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:44:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 16:52:53 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2022-02-26 16:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 17:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 17:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 17:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 17:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 17:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 17:13:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 17:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 17:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 17:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 17:25:20 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-02-26 17:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 17:26:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 17:31:06 --> 404 Page Not Found: Ask/102
ERROR - 2022-02-26 17:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 17:39:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 17:42:29 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-26 17:42:29 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-26 17:42:29 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-26 17:42:29 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-26 17:42:29 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-26 17:42:30 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-02-26 17:42:30 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-02-26 17:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 18:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 18:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 18:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:23:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 18:23:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 18:23:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 18:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 18:24:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:24:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 18:24:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:31:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 18:36:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 18:36:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 18:38:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:51:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:52:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:53:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 18:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 18:54:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 18:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 18:59:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 19:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 19:02:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 19:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 19:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 19:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 19:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 19:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 19:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 19:23:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 19:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 19:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 19:34:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 19:58:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 19:58:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 19:58:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 19:59:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 20:00:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 20:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 20:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 20:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 20:20:43 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-26 20:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 20:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 20:42:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 20:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 20:45:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 20:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 20:48:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 20:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 20:51:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 20:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 20:53:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 20:57:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 20:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 21:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 21:05:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 21:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 21:15:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 21:15:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 21:15:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 21:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 21:16:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 21:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 21:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 21:40:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 21:40:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 21:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 21:56:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-26 21:59:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-26 22:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:06:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 22:10:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 22:11:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 22:11:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:11:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:12:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 22:13:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 22:15:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:15:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:15:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 22:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:20:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 22:26:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-26 22:28:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 22:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 22:54:14 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-26 22:54:16 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-26 22:54:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 22:56:22 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-02-26 22:58:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 22:58:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:03:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 23:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 23:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:15:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 23:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:17:59 --> 404 Page Not Found: WEB_VMS/LEVEL15
ERROR - 2022-02-26 23:31:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:31:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 23:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 23:35:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-26 23:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-26 23:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:36:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:37:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:39:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:43:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:44:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-26 23:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-26 23:57:21 --> 404 Page Not Found: Robotstxt/index
