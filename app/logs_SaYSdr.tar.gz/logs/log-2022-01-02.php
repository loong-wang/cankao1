<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-02 00:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 00:05:35 --> 404 Page Not Found: City/index
ERROR - 2022-01-02 00:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:10:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 00:10:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 00:16:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:16:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:16:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:17:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:17:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:17:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:18:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:19:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 00:21:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:21:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 00:21:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:21:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:21:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:21:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:22:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 00:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:22:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:22:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:22:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:22:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:23:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:23:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:23:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:23:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:24:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:25:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:26:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:27:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 00:27:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 00:52:28 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-02 01:20:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 01:22:02 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 01:24:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 01:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 01:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 01:44:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 01:45:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 01:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 01:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 01:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 01:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 02:03:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 02:03:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 02:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 02:21:51 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 02:21:51 --> 404 Page Not Found: admin//index
ERROR - 2022-01-02 02:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 02:21:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 02:21:52 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 02:21:52 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-01-02 02:21:52 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-01-02 02:21:53 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-01-02 02:21:54 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-01-02 02:21:54 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-01-02 02:21:54 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 02:21:54 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-02 02:21:54 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-02 02:21:54 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-02 02:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 02:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 03:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:26:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 03:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:28:24 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-02 03:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 03:54:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 03:54:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 03:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:09:53 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-01-02 04:11:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 04:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 04:56:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 05:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 05:53:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 05:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:08:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 06:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 06:11:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 06:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 06:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:41:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 06:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 06:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:02:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:04:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 07:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 07:58:39 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-02 08:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 08:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 08:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 08:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 08:43:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 08:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 08:55:01 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-02 08:56:11 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-02 08:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:09:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:16:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 09:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:27:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 09:27:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 09:34:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:35:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:44:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 09:48:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 09:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:54:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:56:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 09:59:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 09:59:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:00:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:02:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:03:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:06:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:07:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:07:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 10:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:11:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 10:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:13:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:16:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:16:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:16:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 10:28:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 10:28:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 10:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:37:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 10:40:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:40:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 10:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 10:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:10:21 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 11:10:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 11:10:22 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 11:10:22 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-02 11:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:11:22 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 11:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:11:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 11:11:23 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 11:11:23 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-02 11:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:34:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:37:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:49:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 11:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 11:56:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:57:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:57:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:57:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 11:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:20:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 12:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 12:28:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 12:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:28:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 12:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:28:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 12:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 12:54:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 13:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:15:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:37:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:44:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:46:51 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 13:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:46:52 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 13:46:52 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-02 13:46:52 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-02 13:47:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:47:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:47:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:47:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:48:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 13:50:24 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 13:50:24 --> 404 Page Not Found: admin//index
ERROR - 2022-01-02 13:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:50:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 13:50:24 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 13:50:24 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-02 13:50:24 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-02 13:50:25 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-02 13:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 13:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 14:02:24 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 14:02:24 --> 404 Page Not Found: admin//index
ERROR - 2022-01-02 14:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 14:02:25 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 14:02:25 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-01-02 14:02:25 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-01-02 14:02:26 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-01-02 14:02:26 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-01-02 14:02:27 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-01-02 14:02:27 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 14:02:27 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-02 14:02:27 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-02 14:02:27 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-02 14:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:16:03 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:16:04 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-02 14:16:05 --> 404 Page Not Found: Member/space
ERROR - 2022-01-02 14:16:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 14:16:05 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-02 14:16:05 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-02 14:16:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:06 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-02 14:16:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:16:06 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-02 14:16:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 14:20:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 14:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:23:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 14:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:30:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 14:30:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 14:30:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 14:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 14:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 15:05:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 15:05:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 15:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:27:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 15:28:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 15:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:33:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 15:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:47:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 15:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 15:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 16:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:11:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 16:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 16:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 16:30:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:37:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 16:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 16:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 16:50:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 16:51:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 16:51:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 16:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:11:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 17:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:39:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:39:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 17:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:57:57 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 17:57:57 --> 404 Page Not Found: admin//index
ERROR - 2022-01-02 17:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 17:57:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 17:57:58 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 17:57:58 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-01-02 17:57:58 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-01-02 17:57:59 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-01-02 17:57:59 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-01-02 17:58:00 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-01-02 17:58:00 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 17:58:00 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-02 17:58:00 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-02 17:58:00 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-02 17:59:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 17:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 18:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 18:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 18:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 18:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 18:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 18:25:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 18:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 18:57:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 18:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:09:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 19:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:26:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 19:27:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 19:28:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 19:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:32:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 19:32:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 19:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 19:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:36:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 19:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 19:55:06 --> 404 Page Not Found: Shell/index
ERROR - 2022-01-02 20:07:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 20:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 20:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 20:18:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:18:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 20:18:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:18:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:18:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:19:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:19:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:19:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:19:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:20:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 20:25:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 20:32:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 20:32:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 20:33:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 20:55:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 20:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 20:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 20:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:16:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 21:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:18:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 21:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 21:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 21:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:21:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 21:22:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 21:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:43:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 21:49:16 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-02 21:49:17 --> 404 Page Not Found: admin//index
ERROR - 2022-01-02 21:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 21:49:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 21:49:17 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-02 21:49:17 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-02 21:49:17 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-02 21:49:18 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-02 21:50:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 21:51:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 21:57:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 21:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 22:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 22:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 22:39:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 22:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 22:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 22:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 22:45:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 22:45:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 22:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 22:48:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 22:52:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 22:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 22:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 23:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 23:03:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-02 23:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 23:05:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-02 23:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-02 23:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 23:33:23 --> 404 Page Not Found: App/views
ERROR - 2022-01-02 23:43:31 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2022-01-02 23:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-02 23:55:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-02 23:59:16 --> 404 Page Not Found: Robotstxt/index
