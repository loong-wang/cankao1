<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-23 00:00:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:00:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:03:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 00:07:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:07:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:08:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:12:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 00:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 00:14:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 00:17:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:19:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:20:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:20:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:21:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:21:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 00:22:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 00:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:25:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:25:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 00:26:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:28:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:30:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 00:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:41:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 00:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:47:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:48:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 00:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:48:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:48:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:49:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:49:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:54:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:54:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 00:58:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:20:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 01:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 01:22:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 01:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:25:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 01:31:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:33:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:34:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 01:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 01:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:43:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 01:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 01:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 01:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 02:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 02:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 02:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 02:10:37 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 02:42:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 02:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 02:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 02:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 03:15:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 03:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 03:33:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 03:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 03:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 03:50:51 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 04:16:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 04:28:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 04:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 04:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 04:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 04:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 04:54:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 05:07:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 05:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 05:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 05:37:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 05:37:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 05:43:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 05:45:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 05:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 06:00:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 06:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 06:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 06:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 06:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 06:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 06:41:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 06:41:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 06:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 06:50:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 06:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 07:11:43 --> 404 Page Not Found: Changshi/1056188.html
ERROR - 2022-01-23 07:11:45 --> 404 Page Not Found: F/shiyi
ERROR - 2022-01-23 07:12:47 --> 404 Page Not Found: CenterSummarized/index
ERROR - 2022-01-23 07:13:40 --> 404 Page Not Found: Fangjia/jieri
ERROR - 2022-01-23 07:14:36 --> 404 Page Not Found: Haocihaoju/a19433.html
ERROR - 2022-01-23 07:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 07:15:14 --> 404 Page Not Found: Azsoft/77156.html
ERROR - 2022-01-23 07:16:01 --> 404 Page Not Found: Pic/201603_38586.html
ERROR - 2022-01-23 07:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 07:38:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 07:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 07:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 07:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 07:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 07:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 08:12:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 08:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:25:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 08:26:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 08:31:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:33:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 08:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:36:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:37:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 08:37:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 08:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 08:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:50:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 08:52:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:56:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:58:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 08:59:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 08:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:03:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:08:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 09:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:13:01 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-23 09:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:22:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:26:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:30:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:31:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:31:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:35:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:36:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:43:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 09:44:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:46:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:46:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:48:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:48:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 09:55:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:57:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 09:57:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 10:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:11:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 10:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 10:16:56 --> 404 Page Not Found: Text4041642904216/index
ERROR - 2022-01-23 10:16:56 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-23 10:16:56 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-23 10:16:57 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-23 10:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 10:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:25:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 10:33:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:35:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 10:35:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:36:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:40:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:41:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 10:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:41:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:41:20 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2022-01-23 10:41:35 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2022-01-23 10:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:43:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:43:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:43:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:44:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 10:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 10:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:58:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 10:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 11:00:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 11:01:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 11:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 11:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:04:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:04:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 11:14:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 11:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 11:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:26:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 11:27:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:28:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:28:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:31:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 11:42:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:44:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 11:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 11:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 11:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 12:04:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:05:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:06:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 12:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 12:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 12:18:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 12:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:19:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:30:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:31:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:33:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:33:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:34:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 12:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:40:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:40:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:42:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:42:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:43:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:43:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:44:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 12:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:45:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:45:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:46:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 12:47:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:47:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:52:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:53:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:54:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:54:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:55:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:55:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 12:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 13:01:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:02:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:03:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 13:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:08:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:11:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 13:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:16:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:17:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 13:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 13:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 13:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:35:25 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-23 13:38:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:40:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 13:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 13:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:45:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 13:46:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 13:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:48:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 13:48:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:49:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:50:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 13:57:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 14:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 14:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 14:12:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 14:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 14:18:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 14:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 14:21:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 14:21:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 14:25:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 14:25:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 14:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 14:48:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 14:49:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 14:53:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 14:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 14:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:10:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 15:10:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 15:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:29:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 15:35:20 --> 404 Page Not Found: App/views
ERROR - 2022-01-23 15:38:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 15:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:43:11 --> 404 Page Not Found: City/1
ERROR - 2022-01-23 15:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:46:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 15:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 15:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 15:51:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 15:53:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 15:53:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 16:30:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 16:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 16:34:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:35:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:35:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 16:36:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 16:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 16:49:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:49:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:49:54 --> 404 Page Not Found: City/1
ERROR - 2022-01-23 16:50:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:50:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:51:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:52:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 16:53:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:54:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:54:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:56:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 16:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 17:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:11:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 17:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 17:20:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 17:32:28 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-01-23 17:32:39 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-01-23 17:43:11 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-01-23 17:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 17:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 17:53:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:53:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 17:55:55 --> 404 Page Not Found: Index/index
ERROR - 2022-01-23 18:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 18:03:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:17:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 18:21:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:21:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:22:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:28:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:31:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 18:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 18:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 18:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 18:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 18:40:21 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2022-01-23 18:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 18:42:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 18:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 18:49:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 18:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 19:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 19:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 19:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 19:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 19:21:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 19:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 19:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 19:23:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 19:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 19:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 19:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 19:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 19:50:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 19:51:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 19:57:01 --> 404 Page Not Found: Shell/index
ERROR - 2022-01-23 20:03:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 20:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 20:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 20:12:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 20:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 20:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 20:44:45 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 20:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 20:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 20:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:15:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 21:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:38:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:40:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:47:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 21:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:49:07 --> 404 Page Not Found: Wwwlianghaocncomrar/index
ERROR - 2022-01-23 21:49:07 --> 404 Page Not Found: Wwwlianghaocncomzip/index
ERROR - 2022-01-23 21:49:07 --> 404 Page Not Found: Wwwlianghaocncomtargz/index
ERROR - 2022-01-23 21:49:07 --> 404 Page Not Found: Wwwlianghaocncom7z/index
ERROR - 2022-01-23 21:49:07 --> 404 Page Not Found: Www_lianghaocn_comrar/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Www_lianghaocn_comzip/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Www_lianghaocn_comtargz/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Www_lianghaocn_com7z/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Wwwlianghaocncomrar/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Wwwlianghaocncomzip/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Wwwlianghaocncomtargz/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Wwwlianghaocncom7z/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocncomtargz/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocncom7z/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnrar/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnzip/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocntargz/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocn7z/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnwwwzip/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnwwwrar/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnwwwtargz/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnwww7z/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnwebrar/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnwebzip/index
ERROR - 2022-01-23 21:49:08 --> 404 Page Not Found: Lianghaocnwebtargz/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Lianghaocnweb7z/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Lianghaocnwwwrootzip/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Lianghaocnwwwrootrar/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Lianghaocnwwwroottargz/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Lianghaocnwwwroot7z/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Www7z/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Webrar/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Webzip/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Webtargz/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Webtar7z/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Wwwroot7z/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Websiterar/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Websitezip/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Websitetargz/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Website17z/index
ERROR - 2022-01-23 21:49:09 --> 404 Page Not Found: Website1rar/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Website1zip/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Website1targz/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Website17z/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Yuanmazip/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Yuanmarar/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Yuanmatargz/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Yuanma7z/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Beifenrar/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Beifenzip/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Beifentargz/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Beifen7z/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Backuprar/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Backupzip/index
ERROR - 2022-01-23 21:49:10 --> 404 Page Not Found: Backuptargz/index
ERROR - 2022-01-23 21:49:11 --> 404 Page Not Found: Backup7z/index
ERROR - 2022-01-23 21:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 21:52:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:53:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:53:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:55:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 21:59:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 22:02:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 22:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 22:10:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 22:16:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 22:17:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:26:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-23 22:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 22:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 22:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 22:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 22:40:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 22:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 22:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 23:01:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-23 23:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 23:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 23:21:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 23:26:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 23:29:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-23 23:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 23:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-23 23:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-23 23:41:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
