<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-17 00:00:36 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-02-17 00:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:06:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 00:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 00:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:11:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:12:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:13:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 00:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 00:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 00:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:39:23 --> Severity: error --> 11111 test 1
ERROR - 2022-02-17 00:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 00:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 01:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:09:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 01:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 01:29:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 01:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:51:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 01:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 01:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:16:46 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 02:16:46 --> 404 Page Not Found: admin//index
ERROR - 2022-02-17 02:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:16:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 02:16:47 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 02:16:48 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-02-17 02:16:48 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-02-17 02:16:49 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-02-17 02:16:49 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-02-17 02:16:49 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-02-17 02:16:49 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-17 02:16:49 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 02:16:49 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-17 02:16:50 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 02:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:26:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 02:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:31:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 02:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 02:37:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 02:37:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 02:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:43:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 02:45:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 02:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 02:56:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 03:00:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 03:01:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 03:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 03:02:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 03:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 03:07:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 03:07:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 03:07:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 03:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:21:55 --> 404 Page Not Found: Login/index
ERROR - 2022-02-17 03:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:34:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 03:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 03:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 03:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 03:59:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 04:02:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 04:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 04:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:10:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 04:10:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 04:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:11:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 04:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 04:54:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 04:58:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 05:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:02:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 05:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:19:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 05:19:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 05:24:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 05:28:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 05:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:44:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 05:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 05:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 06:02:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 06:04:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 06:09:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 06:10:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 06:10:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 06:14:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 06:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 06:20:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 06:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 06:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 06:23:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 06:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 06:34:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 06:36:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 06:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 06:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 06:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 06:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:07:52 --> 404 Page Not Found: Jwglxt/xtgl
ERROR - 2022-02-17 07:08:33 --> 404 Page Not Found: Special/djsb
ERROR - 2022-02-17 07:08:53 --> 404 Page Not Found: Content/rw
ERROR - 2022-02-17 07:09:08 --> 404 Page Not Found: Sdjs/xww
ERROR - 2022-02-17 07:09:20 --> 404 Page Not Found: Zh-CN/aboutus.html
ERROR - 2022-02-17 07:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: admin//index
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-17 07:44:43 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 07:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:52:39 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 07:52:39 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 07:57:16 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 07:57:16 --> 404 Page Not Found: admin//index
ERROR - 2022-02-17 07:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 07:57:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 07:57:17 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 07:57:17 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-02-17 07:57:17 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-02-17 07:57:19 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-02-17 07:57:19 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-02-17 07:57:19 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-02-17 07:57:19 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-17 07:57:19 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 07:57:19 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-17 07:57:19 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 08:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 08:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 08:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 08:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 08:45:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 08:50:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 08:50:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 09:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 09:15:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 09:19:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:26:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:29:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 09:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:30:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:32:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:33:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 09:37:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 09:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 09:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 09:40:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 09:41:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 09:43:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 09:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 09:52:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 09:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:03:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 10:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:25:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:25:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:32:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:37:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:46:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 10:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 10:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 10:52:12 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-02-17 10:59:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 11:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:00:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 11:02:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:06:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:11:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 11:11:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 11:18:57 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 11:18:57 --> 404 Page Not Found: admin//index
ERROR - 2022-02-17 11:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:18:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 11:18:58 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-17 11:18:58 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 11:18:58 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-17 11:18:58 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 11:22:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:28:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:35:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:37:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:38:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:39:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:39:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:40:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:40:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:41:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:41:26 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 11:41:26 --> 404 Page Not Found: admin//index
ERROR - 2022-02-17 11:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:41:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 11:41:28 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 11:41:28 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-02-17 11:41:28 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-02-17 11:41:29 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-02-17 11:41:29 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-02-17 11:41:29 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-02-17 11:41:29 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-17 11:41:29 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 11:41:29 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-17 11:41:29 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 11:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:42:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:44:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:44:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:47:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:47:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:51:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:51:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:52:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:52:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:53:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:55:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 11:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:57:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 11:59:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 11:59:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:59:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 11:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:00:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:02:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:03:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:03:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:03:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:05:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:05:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:06:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:08:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:10:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:16:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:23:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 12:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:34:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:36:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:36:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 12:38:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:39:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:41:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:41:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 12:43:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 12:50:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 12:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 12:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:56:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:57:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:57:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: admin//index
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-17 12:59:16 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 12:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:00:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:00:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:01:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 13:02:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:06:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:09:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 13:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 13:12:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:13:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 13:14:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 13:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:17:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:18:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 13:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:19:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:21:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:25:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:27:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:29:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 13:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 13:29:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:30:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:31:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:35:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:36:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:37:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:43:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:46:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:47:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:47:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 13:50:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:53:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 13:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 13:53:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:55:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 13:55:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 13:56:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:56:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:58:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:58:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:58:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:58:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 13:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:00:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 14:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:01:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:01:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:02:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:03:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 14:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:16:57 --> 404 Page Not Found: Nmaplowercheck1645078616/index
ERROR - 2022-02-17 14:16:57 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-02-17 14:16:59 --> 404 Page Not Found: Sdk/index
ERROR - 2022-02-17 14:17:17 --> 404 Page Not Found: Evox/about
ERROR - 2022-02-17 14:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 14:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:24:35 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 14:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 14:31:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:31:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:31:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:31:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 14:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 14:39:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 14:40:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:40:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:41:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:41:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 14:43:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:44:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:45:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:46:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:46:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 14:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 14:52:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 15:09:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 15:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:11:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 15:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 15:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 15:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:27:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 15:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:33:32 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2022-02-17 15:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 15:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 15:38:35 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2022-02-17 15:39:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:40:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:44:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 15:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 15:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 15:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 15:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 15:59:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 16:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 16:07:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 16:08:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 16:13:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 16:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:16:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:16:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 16:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:17:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:17:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:18:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 16:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:22:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 16:34:00 --> 404 Page Not Found: City/16
ERROR - 2022-02-17 16:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:35:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:36:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 16:38:24 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2022-02-17 16:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:47:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:47:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 16:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 16:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 16:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 16:54:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 17:08:07 --> 404 Page Not Found: City/15
ERROR - 2022-02-17 17:08:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:11:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:12:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:12:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:12:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 17:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 17:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 17:34:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:35:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:35:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:35:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:36:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:36:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:36:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:36:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:36:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:36:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 17:37:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:37:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:37:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:37:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:37:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:38:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:38:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:38:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:39:03 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-17 17:40:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:40:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:40:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:40:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:40:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:41:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:41:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:41:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:41:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:41:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:41:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:41:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:41:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:42:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:42:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:42:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:43:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:43:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 17:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:43:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:43:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:43:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:44:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:44:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:44:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 17:46:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:46:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:46:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 17:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 17:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 17:57:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 18:04:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 18:04:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 18:05:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 18:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 18:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 18:11:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 18:28:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 18:33:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 18:35:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 18:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 18:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 18:38:59 --> 404 Page Not Found: City/2
ERROR - 2022-02-17 18:39:34 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2022-02-17 18:40:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 18:40:58 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2022-02-17 18:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 18:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 18:58:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:00:46 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2022-02-17 19:01:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:01:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 19:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 19:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 19:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 19:36:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:41:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 19:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 19:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 19:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 20:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 20:18:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 20:18:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:43 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-17 20:22:43 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Member/space
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 20:22:45 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 20:22:45 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 20:22:45 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:46 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-17 20:22:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:22:46 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 20:22:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:26:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 20:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 20:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 20:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 20:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 20:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 20:53:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 20:56:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 20:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 20:57:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 20:58:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 21:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 21:09:04 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-17 21:09:04 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-17 21:09:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 21:09:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Member/space
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 21:09:06 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 21:09:06 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 21:09:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:07 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-17 21:09:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:09:07 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 21:09:07 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 21:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:30:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:31:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:32:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:35:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:36:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:36:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:40:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:41:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:43:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:44:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:45:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:47:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:48:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:50:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 21:52:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:54:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:55:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 21:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 21:56:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 21:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 21:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:01:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:05:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:05:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:08:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:13:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 22:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:21:53 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-17 22:21:53 --> 404 Page Not Found: admin//index
ERROR - 2022-02-17 22:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:21:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 22:21:54 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-17 22:21:54 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-17 22:21:54 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-17 22:21:54 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-17 22:26:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 22:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:29:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:38:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 22:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:51:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 22:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 22:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:52:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 22:54:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:54:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 22:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:58:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 22:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 23:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-17 23:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 23:03:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-17 23:03:45 --> 404 Page Not Found: 16/all
ERROR - 2022-02-17 23:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 23:16:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:17:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:20:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 23:20:25 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-17 23:20:26 --> 404 Page Not Found: Member/space
ERROR - 2022-02-17 23:20:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:20:26 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 23:20:27 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 23:20:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:27 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-17 23:20:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:27 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-17 23:20:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-17 23:20:55 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-17 23:26:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 23:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-17 23:34:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-17 23:49:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-17 23:49:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
